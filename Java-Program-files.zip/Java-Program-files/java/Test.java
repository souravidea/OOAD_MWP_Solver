
import java.util.ArrayList;
import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sourav
 */
public class Test {
    public static void main(String[] args) {
     /*   int []a =  new int[2];
        a[0]=7;
        a[1]=8;
        for(int i=0;i<a.length;i++){
            System.out.println(a[i]);
        }
        for(int j:a){
             System.out.println(j);
        }
         ArrayList <String> k=new ArrayList();
         k.add("hello");
         k.add("jjj");
        // k.add(8);
         for(String i:k){
             System.out.println(i);
         }
         
         Stack st=new Stack();
         st.add(1);
         st.add(2);
         st.add(1);
         st.add(7);
         st.add(1);
         st.add(2);
         System.out.println(st);
         System.out.println(st.pop());
         System.out.println(st);
         st.push(22);
         System.out.println(st);
         PriorityQueue q=new PriorityQueue();
     */
     
     String s=new String("Hari");
        System.out.println(s.toUpperCase());
        s="Raviss";
         System.out.println(s.toUpperCase());
         System.out.println(s);
        
    }
   
    
}
