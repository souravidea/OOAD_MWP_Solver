/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import edu.stanford.nlp.simple.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

public class StanfordNameFinder {

    public static void main(String[] args) throws FileNotFoundException, Exception {
        // Connection conn = null;
        Statement stmt = null;
        Connection conn = DBconnect.getConnection();
        String entireFileText = new Scanner(new File("/home/sourav/ques.txt")).useDelimiter("\\A").next();
        System.out.println(entireFileText);
        Document doc = new Document(entireFileText);
        int i = 0;
        int sent_sl_no = 1;
        for (Sentence sent : doc.sentences()) {
            System.out.println("The parse of the sentence '" + sent + "' is " + sent.parse());
            // ...
            List<String> nerTags = sent.nerTags();
            // System.out.println("ner tags are" + nerTags);
            List<String> words = sent.words();
            List<String> lemmas = sent.lemmas();
            List<String> postags = sent.posTags();
            //List<String> dparses = sent.parse();

            System.out.println("word size" + words.size());

            try {
                //      Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Connecting to database...");
                conn = DBconnect.getConnection();
//              conn = DriverManager.getConnection(DB_URL, USER, PASS);
                System.out.println("Creating statement...");
                stmt = conn.createStatement();
                String sql;
                sql = "DELETE FROM MWP";
                stmt.executeUpdate(sql);

                for (i = 0; i < words.size(); i++) {
                    // System.out.println("i=" + i);
                    String wordname = words.get(i);
                    String nertag = nerTags.get(i);
                    String lemma = lemmas.get(i);
                    String postag = postags.get(i);

                  //  if (!nertag.equalsIgnoreCase("O")) {

                        sql = "INSERT INTO NERlist ( sent_sl_no, word,lemma,postag,ner ) VALUES (?, ?,?,?,?)";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, sent_sl_no);
                            ps.setString(2, wordname);
                            ps.setString(3, lemma);
                            ps.setString(4, postag);
                            ps.setString(5, nertag);
                            ps.executeUpdate();
                        }
                  //  }

                }
                sent_sl_no++;
                stmt.close();
                conn.close();
            } catch (SQLException se) {
                se.printStackTrace();

            } catch (Exception e) {
                //Handle errors for Class.forName
                e.printStackTrace();
            } finally {
                DBconnect.closeConnection(conn);

            }//end finally try
        }//end try
        System.out.println("Goodbye!");
    }
}
