
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Sourav
 */
public class MWProblem {

    /**
     * @param args
     * @throws java.io.IOException
     * @throws java.io.FileNotFoundException
     * @throws java.lang.ClassNotFoundException
     */
  //  public static void main(String[] args) throws IOException, FileNotFoundException, ClassCastException, ClassNotFoundException, Exception {
        public static void invoke() throws IOException, FileNotFoundException, ClassCastException, ClassNotFoundException, Exception {
        MWP d = new MWP();
        // processing_result();
        MWP question = new MWP();
        question.count_sentence();
        question.clearDBtables();
        question.answer_type();
        //question.NERText();
        //question.fill_SRLframes();//for SRL test;cd se '
        System.out.println("Loading SRL");
        LoadSRL.runScript("/home/sourav/MyResearch/srlsqls/ds1/10ds1.sql");
        System.out.println("processing result");
        question.processing_sentence();
        System.out.println("var name count is" + question.varcount);
        System.out.println("attribute specific count" + question.var_atr_count);
        System.out.println("variable name is" + question.variable_name);
        System.out.println("attribute is" + question.variable_attribute);
        System.out.println("#######################################");
        System.out.println("owner count" + question.own_count);
        question.update_sent_owner();
        if (question.own_count == 1) {
            System.out.println("search for update for owner");
            question.update_sent_owner();
        } else if (question.own_count == 2) {
            System.out.println("search for update for owner");
            question.update_sent_owner();
        }
        if (question.varcount == 1) {
            System.out.println("search for update for variable");
            question.update_sent_var();
        }
        if (question.var_atr_count == 1) {
            System.out.println("search for update for specific item attribute");
            question.update_sent_var_atr();
        }
        System.out.println("search for null variable with transfer verbs");
        question.update_var();

        question.fill_table();
        System.out.println("creating owner object and java prog");
        question.createOwnerItemObject();
        //  System.out.println("Displaying ");
        // question.display();

        question.evaluate_result(); // for java program
        // question.evaluateMulDiv();
    }

    /*  
    
    public synchronized static void processing_result() throws IOException, Exception{
        //wait(0);
        MWP question = new MWP();
        question.count_sentence();
        question.clearDBtables();
        question.answer_type();
        //question.NERText();
        //question.fill_SRLframes();//for SRL test;cd se '
        //System.out.println("Loading SRL");
        LoadSRL.runScript("/home/sourav/MyResearch/srlsqls/ds1/2ds1.sql");
        System.out.println("processing result");
        question.processing_sentence();
        System.out.println("var name count is" + question.varcount);
        System.out.println("attribute specific count" + question.var_atr_count);
        System.out.println("variable name is" + question.variable_name);
        System.out.println("attribute is" + question.variable_attribute);
        System.out.println("#######################################");
        System.out.println("owner count" + question.own_count);
        question.update_sent_owner();
        if (question.own_count == 1) {
            System.out.println("search for update for owner");
            question.update_sent_owner();
        } else if (question.own_count == 2) {
            System.out.println("search for update for owner");
            question.update_sent_owner();
        }
        if (question.varcount == 1) {
            System.out.println("search for update for variable");
            question.update_sent_var();
        }
        if (question.var_atr_count == 1) {
            System.out.println("search for update for specific item attribute");
            question.update_sent_var_atr();
        }
        System.out.println("search for null variable with transfer verbs");
        question.update_var();

        question.fill_table();
        System.out.println("creating owner object and java prog");
        question.createOwnerItemObject();
    }
     */
}
