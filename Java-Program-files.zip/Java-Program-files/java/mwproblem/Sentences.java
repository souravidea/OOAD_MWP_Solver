package mwproblem;

import edu.stanford.nlp.process.Morphology;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.StringTokenizer;


/**
 *
 * @author Sourav
 */
public class Sentences {

    public String sentenceline;
    public String sent_type;
    public int sent_sl_no;
    public int no_of_tokens;
    // public int no_of_name_entities;
    public String verb_name;
    public String verb_lemma;
    public String owner_name = null;
    public String second_owner = null;
    public String variable_name = null;
    public String variable_attribute = "NULL";
    public int variable_count;
    public String q_owner = null;
    public String pipeline_equation;
    public String taggedString;
    public String depString;
    //String tempOwner = null;
    //public String depWord1;
    // public static String[] depWord;
    //for databse
    private static final String[] pipelineOptions = new String[]{
        "eng", // language
        "-lemma", "/home/sourav/NetBeansProjects/models/CoNLL2009-ST-English-ALL.anna-3.3.lemmatizer.model", // lemmatization mdoel
        "-tagger", "/home/sourav/NetBeansProjects/test/src/models/CoNLL2009-ST-English-ALL.anna-3.3.postagger.model", // tagger model
        "-parser", "/home/sourav/NetBeansProjects/test/src/models/CoNLL2009-ST-English-ALL.anna-3.3.parser.model", // parsing model
        "-srl", "/home/sourav/NetBeansProjects/test/src/models/srl-TACL15-eng.model", // SRL model
        "-framenet", "/home/sourav/mateplus-master/scratch/framenet/fndata-1.5/", // location of FrameNet data
        "-semafor", "localhost 8043", // location of semafor server 
        "-mst", "localhost 12345", // location of mstparser server
        "-glove", "/home/sourav/mateplus-master/scratch/glove/",
        "-reranker", // turn on reranking
    };

    public void display_info() {

        System.out.println("sent_sl_no: " + sent_sl_no);
        System.out.println("sentenceline: " + sentenceline);
        System.out.println(sent_type + ": type sentence");
        System.out.println("no_of_tokens: " + no_of_tokens);
        System.out.println("verb_name (lemma):  " + verb_name);
        System.out.println("owner_name:  " + owner_name);
        System.out.println("Second owner: " + second_owner);
        System.out.println("variable_name:  " + variable_name);
        System.out.println("variable_count:  " + variable_count);
        System.out.println("taggedString: " + taggedString);
        System.out.println("depString: " + depString);

        System.out.println("done");

    }

    public void count_tokens() {
        StringTokenizer st = new StringTokenizer(sentenceline);

        // counting tokens
        no_of_tokens = st.countTokens();
    }

    public void tagging() {
        MaxentTagger tagger = new MaxentTagger("edu/stanford/nlp/models/pos-tagger/english-left3words/english-left3words-distsim.tagger");
        taggedString = tagger.tagString(sentenceline);

    }

    public String find_sentence_type() {

        //verify relevancy
        int sentlength = sentenceline.length();
        System.out.println("sent length:" + sentlength);
        if (sentenceline.charAt(sentlength - 1) == '?' || sentenceline.charAt(sentlength - 2) == '?') {
            System.out.println("the sentence type is question sentence");
            sent_type = "question";
        } else {
            System.out.println("not a question sentence");
            sent_type = "normal";
        }

        return sent_type;
    }

    public String[] dParsing(String tempOwner[]) {
        /*  System.out.println("dependency parsing is going on......");
        LexicalizedParser lp = LexicalizedParser
                .loadModel("edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz");
        lp.setOptionFlags(new String[]{"-maxLength", "80",
            "-retainTmpSubcategories"});

        TokenizerFactory<CoreLabel> tokenizerFactory = PTBTokenizer.factory(new CoreLabelTokenFactory(), "");
        List<CoreLabel> rawWords2 = tokenizerFactory.getTokenizer(new StringReader(sentenceline)).tokenize();
        Tree parse = lp.apply(rawWords2);

        // parse.pennPrint();
        System.out.println();
        TreebankLanguagePack tlp = new PennTreebankLanguagePack();
        GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
        GrammaticalStructure gs = gsf.newGrammaticalStructure(parse);
        // List<TypedDependency> tdl = gs.typedDependenciesCCprocessed();
        ArrayList sk = (ArrayList) gs.allTypedDependencies();
        depString = sk.toString();
        System.out.println(depString);
        Object depArray[] = sk.toArray();

        String[] depWord = Arrays.stream(depArray).map(Object::toString).toArray(String[]::new);
        String[] eachWord = new String[depWord.length];
        int i = 0;
        for (String depWord1 : depWord) {
            //System.out.print(depWord1);
            eachWord[i] = depWord1;
            i++;
        }

        int flagowner = 0;
        int flagvariable = 0;
        int flagattribute = 0;
        String[] tokens = taggedString.split(" ");
        for (i = 0; i < depWord.length; i++) {
            String str = eachWord[i];
            System.out.println("Sentence String is ==>" + str);

            for (String tok : tokens) {
                String[] taggedTokens = tok.split("_");
                /*  for (String taggedToken : taggedTokens) {
                    //  System.out.println(taggedToken);
                }*/
 /*
                String name = taggedTokens[0];
                System.out.println("@@@@@" + name);
                // System.out.println("the string  " + (i + 1) + " is " + str);
                //  System.out.println("the string starts with " + eachWord[i].substring(0, 5));
                if (!sentenceline.startsWith("There")) {
                    // System.out.println("The sentence is not starting with There");
                    if (sent_type.equals("normal")) {
                        //  System.out.println("The sentence type is normal");

                        if ((str.startsWith("nsubj") && !str.startsWith("nsubjpass") && !str.startsWith("nmod:poss")) && str.contains(name) && (taggedTokens[1].startsWith("NN") || taggedTokens[1].startsWith("PR")) && flagowner == 0) {
                            //String name = taggedTokens[0];
                            System.out.println("name=" + name);
                            if (str.contains(name)) {
                                owner_name = name;
                                System.out.println("the owner name is:" + owner_name);
                                flagowner = 1;
                            }

                        } else if ((str.startsWith("nsubj") && !str.startsWith("nsubjpass") && !str.startsWith("nmod:poss")) && str.contains(name) && (taggedTokens[1].startsWith("NN") || taggedTokens[1].startsWith("PR")) && flagowner == 0) {
                            //String name = taggedTokens[0];
                            System.out.println("name=" + name);
                            if (str.contains(name)) {
                                owner_name = name;
                                System.out.println("the owner name is:" + owner_name);
                                flagowner = 1;
                            }

                        } else if ((str.startsWith("case")) && str.contains(name) && str.contains(verb_name) && (taggedTokens[1].startsWith("NN") || taggedTokens[1].startsWith("PR")) && flagowner == 0) {
                            //String name = taggedTokens[0];
                            System.out.println("in CASE name=" + name);
                            if (str.contains(name)) {
                                owner_name = name;
                                System.out.println("the owner name is:" + owner_name);
                                flagowner = 1;
                            }

                        } else if ((str.startsWith("appos")) && str.contains(name) && str.contains(verb_name) && (taggedTokens[1].startsWith("NN") || taggedTokens[1].startsWith("PR")) && flagowner == 0) {
                            //String name = taggedTokens[0];
                            System.out.println("in CASE name=" + name);
                            if (str.contains(name)) {
                                owner_name = name;
                                System.out.println("the owner name is:" + owner_name);
                                flagowner = 1;
                            }

                        }

                        if (str.startsWith("amod") && !str.startsWith("nmod:tmod") && str.contains(name) && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagattribute == 0 && !name.equals("new") && !name.equals("old") && !name.equalsIgnoreCase("Last") && (!name.equalsIgnoreCase(owner_name) || owner_name == null)) {

                            variable_attribute = name;
                            System.out.println("amod-This sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        } else if (str.startsWith("dobj") && str.contains(name) && (taggedTokens[1].equals("JJ")) && flagattribute == 0 && !taggedTokens[1].equals("NNS") && (!name.equalsIgnoreCase(owner_name) || owner_name == null)) {

                            variable_attribute = name;
                            System.out.println("dobj-JJ This sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        } else if (str.startsWith("dobj") && str.contains(name) && taggedTokens[1].equals("NN") && flagattribute == 0 && !taggedTokens[1].equals("NNS") && !name.equals("football") && !name.equals("game") && (!name.equalsIgnoreCase(owner_name) || owner_name == null)) {

                            variable_attribute = name;
                            System.out.println("dobj-NNThis sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        } else if (str.startsWith("compound") && str.contains(name) && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagattribute == 0 && !name.equals("bank") && !name.equals("yard") && !name.equals("sale") && !name.equals("game") && (!name.equalsIgnoreCase(owner_name) || owner_name == null)) {//q-21 in DS1

                            variable_attribute = name;
                            System.out.println("compound yes, This sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        } else if (str.startsWith("compound") && str.contains(name) && taggedTokens[1].equals("NNP") && flagattribute == 0 && (!name.equalsIgnoreCase(owner_name) || owner_name == null) && !sentenceline.startsWith(name)) {//q-132 in DS1

                            variable_attribute = name;
                            System.out.println("sentence" + sentenceline);
                            System.out.println("owner name" + owner_name);
                            System.out.println("compound yes, This sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        }

                        if (str.startsWith("dobj") && str.contains(name) && taggedTokens[1].startsWith("NN") && flagvariable == 0 && !name.equals(variable_attribute) && !name.equalsIgnoreCase("cars")) {
                            {

                                System.out.println("string starts with dobj");
                                // String name = taggedTokens[0];
                                System.out.println("name=" + name);
                                if (str.contains(name) && !taggedTokens[1].startsWith("NNP")) {
                                    variable_name = name;
                                    System.out.println("the Item or Object or variable name is:" + variable_name);
                                    flagvariable = 1;
                                }

                            }
                        } else if (!str.startsWith("dobj") && str.startsWith("nmod:poss") && str.contains(name) && taggedTokens[1].startsWith("NN") && flagvariable == 0 && !name.equals(variable_attribute) && !name.equals("sister") && !name.equals("dog") && !name.equals("dad") && !name.equals("mother") && !name.equals("friend") && !name.equals("cat")) {
                            System.out.println("string starts with nmod:poss");
                            // String name = taggedTokens[0];
                            System.out.println("name=" + name);
                            if (str.contains(name) && !taggedTokens[1].startsWith("NNP")) {
                                variable_name = name;
                                System.out.println("the Item or Object or variable name is:" + variable_name);
                                flagvariable = 1;
                            }
                        } else if (!str.startsWith("dobj") && str.startsWith("nsubjpass") && str.contains(name) && taggedTokens[1].startsWith("NN") && flagvariable == 0 && !name.equals(variable_attribute)) {
                            System.out.println("string starts with nsubjpass");
                            // String name = taggedTokens[0];
                            System.out.println("name=" + name);
                            if (str.contains(name) && !taggedTokens[1].startsWith("NNP") && !sentenceline.startsWith("When")) {
                                variable_name = name;
                                System.out.println("the Item or Object or variable name is:" + variable_name);
                                flagvariable = 1;
                            }
                        } else if (!str.startsWith("dobj") && str.startsWith("nummod") && str.contains(name) && taggedTokens[1].startsWith("NN") && flagvariable == 0 && !name.equals(variable_attribute)) {
                            System.out.println("string starts with nummod");
                            // String name = taggedTokens[0];
                            System.out.println("name=" + name);
                            if (str.contains(name) && !taggedTokens[1].startsWith("NNP")) {
                                variable_name = name;
                                System.out.println("the Item or Object or variable name is:" + variable_name);
                                flagvariable = 1;
                            }
                        } else if (!str.startsWith("dobj") && str.startsWith("case") && str.contains(name) && taggedTokens[1].startsWith("NN") && flagvariable == 0 && !name.equals(variable_attribute) && !name.equalsIgnoreCase("weekend") && !name.equalsIgnoreCase("dinner")) {
                            System.out.println("string starts with case");
                            // String name = taggedTokens[0];
                            System.out.println("name=" + name);
                            if (str.contains(name) && !taggedTokens[1].startsWith("NNP")) {
                                variable_name = name;
                                System.out.println("the Item or Object or variable name is:" + variable_name);
                                flagvariable = 1;
                            }
                        }
                    } else if (sent_type.equals("question")) {
                        if (str.startsWith("amod") && str.contains(name) && !name.equals("many") && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagattribute == 0 && !taggedTokens[1].equals("NNS")) {

                            variable_attribute = name;
                            System.out.println("This sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        } else if (str.startsWith("dobj") && str.contains(name) && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagattribute == 0) {

                            variable_attribute = name;
                            System.out.println("This sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        } else if (str.startsWith("compound") && str.contains(name) && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagattribute == 0) {

                            variable_attribute = name;
                            System.out.println("This sentence variable attribute is -------->" + variable_attribute);
                            flagattribute = 1;

                        }
                        if ((str.startsWith("nsubj") || str.startsWith("amod") || str.startsWith("nmod")) && str.contains(name) && (taggedTokens[1].startsWith("NN") && !taggedTokens[1].equals("NNP")) && flagvariable == 0 && (variable_attribute == null || !variable_attribute.equals(name))) {
                            // String name = taggedTokens[0];
                            if (str.contains(name)) {
                                variable_name = name;
                                System.out.println("the variable name for qustion sentence is:" + variable_name);
                                flagvariable = 1;
                            }

                        }

                        if ((str.startsWith("nsubj") || str.startsWith("advmod") || str.startsWith("nmod")) && str.contains(name) && ((taggedTokens[1].startsWith("NNP"))) && flagowner == 0 && (variable_name == null || !name.startsWith(variable_name))) {
                            // String name = taggedTokens[0];
                            if (str.contains(name)) {
                                owner_name = name;
                                System.out.println("the owner name for qustion sentence is:" + owner_name);
                                flagowner = 1;
                            }

                        } else if ((str.startsWith("nsubj") || str.startsWith("advmod") || str.startsWith("nmod")) && str.contains(name) && ((taggedTokens[1].startsWith("NN"))) && flagowner == 0 && (variable_name == null || !name.startsWith(variable_name))) {
                            // String name = taggedTokens[0];
                            if (str.contains(name)) {
                                owner_name = name;
                                System.out.println("the owner name for qustion sentence is:" + owner_name);
                                System.out.println("var>>>" + variable_name);
                                flagowner = 1;
                            }

                        }

                    }

                } else {//end of not there
                    if (str.startsWith("nsubj") && str.contains(name) && (taggedTokens[1].startsWith("NN")) && sent_type.equals("normal") && !name.equals("total") && flagvariable == 0) {
                        // String name = taggedTokens[0];.equals
                        if (str.contains(name)) {
                            variable_name = name;
                            System.out.println("the variable name for sentence started with There:" + variable_name);
                            flagvariable = 1;
                        }
                    } else if (str.startsWith("case") && str.contains(name) && (taggedTokens[1].startsWith("NN")) && sent_type.equals("normal") && !name.equals("total") && flagvariable == 0) {
                        // String name = taggedTokens[0];.equals
                        if (str.contains(name)) {
                            variable_name = name;
                            System.out.println("the variable name for sentence started with There:" + variable_name);
                            flagvariable = 1;
                        }
                    }

                    if (!str.startsWith("nsubj") && str.startsWith("case") && str.contains(name) && (taggedTokens[1].startsWith("NN") || taggedTokens[1].startsWith("PR")) && sent_type.equals("normal") && flagowner == 0) {
                        // String name = taggedTokens[0];
                        if (str.contains(name)) {
                            owner_name = name;
                            System.out.println("the owner name for sentence started with There:" + owner_name);
                            flagowner = 1;
                        }
                    }
                    if (str.startsWith("amod") && str.contains(name) && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagattribute == 0) {

                        variable_attribute = name;
                        System.out.println("This sentence variable attribute is -------->" + variable_attribute);
                        flagattribute = 1;

                    } else if (str.startsWith("dobj") && str.contains(name) && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagowner == 0) {

                        variable_attribute = name;
                        System.out.println("This sentence variable attribute is -------->" + variable_attribute);
                        flagattribute = 1;

                    } else if (str.startsWith("compound") && str.contains(name) && (taggedTokens[1].equals("JJ") || taggedTokens[1].equals("NN")) && flagowner == 0) {

                        variable_attribute = name;
                        System.out.println("This sentence variable attribute is -------->" + variable_attribute);
                        flagattribute = 1;

                    }
                }//end of else

                if (flagvariable != 0) {
                    Morphology morphology = new Morphology();
                    variable_name = morphology.lemma(variable_name, taggedTokens[1]);
                    tempOwner[1] = variable_name;
                }
                if (flagowner != 0) {
                    Morphology morphology = new Morphology();
                    owner_name = morphology.lemma(owner_name, taggedTokens[1]);
                    tempOwner[0] = owner_name;
                    // System.out.println("no owner is found for this sentence");
                } else {
                    owner_name = "any";
                    if (sent_sl_no == 1) {
                        tempOwner[0] = owner_name;
                    }

                }
                if (flagattribute != 0) {
                    // Morphology morphology = new Morphology();
                    // variable_attribute = morphology.lemma(variable_attribute, taggedTokens[1]);
                    tempOwner[2] = variable_attribute;
                    // System.out.println("no owner is found for this sentence");
                } else {
                    // tempOwner[2] = "NULL";
                }

            }//end tok for

            // flag = 1;
            //return true;
        }
        if (flagowner == 0 && !sent_type.equals("question")) {
            System.out.println("no owner is found for this sentence");
            if (tempOwner != null) {
                owner_name = tempOwner[0];
            }

        }
        if (flagvariable == 0 && !sent_type.equals("question")) {
            System.out.println("no variable is found for this sentence");
            variable_name = tempOwner[1];

        }

        System.out.println("count is: " + variable_count);

        System.out.println();

        System.out.println();*/

 /* TreePrint tp = new TreePrint("penn");
        StringWriter stringWriter = new StringWriter();
        PrintWriter pw = new PrintWriter(stringWriter);
        tp.printTree(parse, pw);
        String output = stringWriter.toString();
        System.out.println(output);*/
 /* System.out.println("tempOwner:" + tempOwner);*/
        return tempOwner;

    }

    public String find_owner(int i) throws Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for finding owner ...");
        // Statement stmt = conn.createStatement();
        Morphology morphology = new Morphology();
        String predicate = null;
        int flagowner = 0;
        try {
            String sql = "select * from SRLdata where sent_sl_no=? and dependency !=\"P\"";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, i + 1);
            System.out.println("ps:" + ps.toString());
            // ps.setInt(1, sentcount);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String owner = rs.getString(3);
                // String ner = rs.getString(3);
                String POS = rs.getString(5);
                String dependency = rs.getString(6);
                predicate = rs.getString(8);
                String arg = rs.getString(9);
                //  System.out.println("owner name" + owner);
                //if(owner.equals(owner_name)){
                if (dependency.equals("SUB") || dependency.equals("PMOD") || dependency.equals("NMOD")) {
                    if (sentenceline.startsWith("There") && predicate.equals("Buildings")) {
                        flagowner = 0;
                    }
                    if (sent_type.equals("question") && predicate.equals("Buildings")) {
                        flagowner = 0;
                    }
                    if (dependency.equals("SUB") && POS.equals("NNP") && sent_type.equals("normal") && flagowner == 0) {
                        owner_name = owner;
                        System.out.println("Owner name : " + owner_name);
                        if (dependency.equals("SUB") || POS.equals("NNP")) {
                            flagowner = 1;
                        }

                    }
                    if (dependency.equals("SUB") && POS.equals("PRP") && sent_type.equals("normal") && flagowner == 0) {
                        owner_name = owner;
                        System.out.println("Owner name : " + owner_name);
                        if (dependency.equals("SUB") || POS.equals("NNP")) {
                            flagowner = 1;
                        }

                    } //else if (dependency.equals("SUB") && POS.startsWith("NN") && sent_type.equals("normal") && flagowner == 0 && !arg.equals("Item")) {
                    else if (dependency.equals("SUB") && POS.startsWith("NN") && sent_type.equals("normal") && flagowner == 0 && !arg.equals("Item")) {
                        owner_name = owner;
                        System.out.println("Owner name : " + owner_name);
                        if (dependency.equals("SUB") || POS.equals("NNP")) {
                            flagowner = 1;
                        }

                    } else if ((dependency.equals("PMOD")) && sent_type.equals("normal") && POS.equals("NN") && flagowner == 0 && !predicate.equals("Calendric_unit")) {
                        owner_name = owner;
                        System.out.println("Owner name : " + owner_name);

                        // break;
                    }
                    if ((dependency.equals("SUB") || dependency.equals("NMOD")) && POS.equals("NNP") && sent_type.equals("question")) {
                        owner_name = owner;
                        System.out.println("Owner name : " + owner_name);
                        flagowner = 1;

                    } else if ((dependency.equals("SUB")) && (POS.startsWith("NN") || POS.startsWith("PRP")) && !POS.equals("NNS") && sent_type.equals("question") && flagowner == 0 && !arg.equals("Item")) {
                        owner_name = owner;
                        System.out.println("Owner name : " + owner_name);
                        flagowner = 1;

                    } else if (dependency.equals("PMOD") && sent_type.equals("question") && POS.startsWith("NN") && flagowner == 0 && !owner.equals("total") && !owner.equals("lunch")) {
                        owner_name = owner;
                        System.out.println("Owner name : " + owner_name);

                    } else if (dependency.equals("SUB") && sent_type.equals("question") && POS.equals("EX") && flagowner == 0 && q_owner != null) {
                        owner_name = q_owner;
                        System.out.println("Owner name : " + owner_name);

                    }

                }

                if (owner_name != null) {

                    owner_name = morphology.stem(owner_name);
                    owner_name = morphology.lemma(owner_name, POS);
                    owner_name = owner_name.toLowerCase();

                }

            }// end of while
            if (sentenceline.startsWith("There") && (predicate.equals("Containers") || predicate.equals("Locale_by_use"))) {
                q_owner = owner_name;
                System.out.println("q owner" + q_owner);

            }
        }//end of try
        catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        if (owner_name == null && !sent_type.equals("question")) {
            owner_name = "any";
        }
        System.out.println("***********owner****************" + owner_name);
        return owner_name;
    }

    public void confirm_owner(int i) throws Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for confirming owner ...");
        // Statement stmt = conn.createStatement();

        try {
            String sql = "select distinct * from NERlist,SRLdata where NERlist.sent_sl_no=SRLdata.sent_sl_no and NERlist.word=SRLdata.word and NERlist.sent_sl_no=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, i + 1);
            System.out.println("ps:" + ps.toString());

            // ps.setInt(1, sentcount);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String owner = rs.getString(2);
                String ner = rs.getString(3);
                String POS = rs.getString(8);
                String dependency = rs.getString(9);
                //if(owner.equals(owner_name)){
                if (ner.equals("PERSON") || ner.equals("ORGANIZATION") || ner.equals("LOCATION") || dependency.equals("SUB") || dependency.equals("PMOD") || dependency.equals("NMOD")) {
                    if (dependency.equals("SUB") && POS.startsWith("NN")) {
                        if (owner_name.equals(owner)) {
                            System.out.println("owner confirmed");

                        }

                    } else if (dependency.equals("PMOD") && sent_type.equals("question") && POS.startsWith("NN")) {
                        if (owner_name.equals(owner)) {
                            System.out.println("owner confirmed");

                        }

                    }

                }

            }// end of while
        }//end of try
        catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public String find_second_owner(int i) throws Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for finidin second owner ...");
        try {
            String sql = "select * from SRLdata where sent_sl_no=? and dependency !=\"P\"";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, i + 1);
            System.out.println("ps:" + ps.toString());
            // ps.setInt(1, sentcount);
            ResultSet rs = ps.executeQuery();
            Morphology morphology = new Morphology();
            System.out.println("sentence type" + sent_type);
            while (rs.next()) {
                //String start=rs.getString(verb_name);
                String ownr = rs.getString(3);
                // String ner = rs.getString(3);
                String POS = rs.getString(5);
                String dependency = rs.getString(6);
                String pred = rs.getString(7);
                String predicate = rs.getString(8);
                String owner = morphology.lemma(ownr, POS).toLowerCase();
                //   System.out.println("word processing is---" + owner);
                if ((dependency.equals("OBJ")) && POS.startsWith("NNP") && sent_type.equals("normal") && !owner_name.equalsIgnoreCase(owner)) {
                    second_owner = owner;
                    System.out.println("This sentence may have second owner or gainer:" + second_owner);
                    break;
                } else if ((dependency.equals("NMOD")) && POS.startsWith("NNP") && sent_type.equals("normal") && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && !owner.equalsIgnoreCase("Batman") && !owner.equalsIgnoreCase("Superman")) {
                    second_owner = owner;
                    System.out.println("This sentence may have second owner or gainer:" + second_owner);
                    break;
                } else if ((dependency.equals("PMOD")) && sent_type.equals("normal") && POS.startsWith("NN") && !sentenceline.startsWith("There") && pred.equals("Y") && (variable_name == null || !variable_name.equals(owner)) && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && !owner.equals("today") && !owner.equals("tomorrow") && !owner.equals("orchard") && !owner.equals("garden") && !predicate.equals("Calendric_unit") && !predicate.equals("Clothing")) {//&& pred.equals("Y")
                    System.out.println("pmod , nn, etc 1");
                    if (!POS.equals("NNS")) {
                        second_owner = owner;
                    } else if (predicate.equals("Personal_relationship")) {
                        second_owner = owner;

                        System.out.println("This sentence has second owner or gainer:" + second_owner);
                        break;

                    }
                    System.out.println("This sentence has second owner or gainer:" + second_owner);
                    break;
                } else if ((dependency.equals("PMOD")) && sent_type.equals("normal") && POS.startsWith("NNP") && !sentenceline.startsWith("There") && (variable_name == null || !variable_name.equals(owner)) && (owner_name == null || !owner_name.equalsIgnoreCase(owner))) {
                    System.out.println("pmod , nn, etc 2");
                    second_owner = owner;
                    System.out.println("This sentence has second owner or gainer:" + second_owner);
                    break;
                } else if ((dependency.equals("PMOD")) && sent_type.equals("normal") && POS.startsWith("NN") && !sentenceline.startsWith("There") && (variable_name == null || !variable_name.equals(owner)) && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && !owner.equals("today") && !owner.equals("tomorrow") && !owner.equals("orchard") && !owner.equals("garden") && !owner.equals("lunch") && !owner.equals("toy") && !owner.equals("hotdog") && !owner.equals("salad") && !owner.equals("coupon") && !predicate.equals("Calendric_unit") && !predicate.equals("Clothing")) {
                    System.out.println("pmod , nn, etc 3");
                    if (!POS.equals("NNS")) {
                        second_owner = owner;

                        System.out.println("This sentence has second owner or gainer:" + second_owner);
                        break;
                    } else if (predicate.equals("Personal_relationship")) {
                        second_owner = owner;

                        System.out.println("This sentence has second owner or gainer:" + second_owner);
                        break;

                    }
                }

                if (second_owner != null) {
                    second_owner = morphology.stem(second_owner);
                    second_owner = morphology.lemma(second_owner, POS);
                    second_owner = second_owner.toLowerCase();
                }

            }// end of while

        }//end of try
        catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        if (second_owner == null) {
            System.out.println("no second owner found");
        }
        System.out.println("***********second owner****************");
        return second_owner;
    }

    public String find_var(int i) throws Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for finidin item name ...");
        try {
            String sql = "select * from SRLdata where sent_sl_no=? and dependency !=\"P\"";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, i + 1);
            System.out.println("ps:" + ps.toString());
            // ps.setInt(1, sentcount);
            ResultSet rs = ps.executeQuery();
            Morphology morphology = new Morphology();
            String POS = null;
            while (rs.next()) {
                //String start=rs.getString(verb_name);
                String ownr = rs.getString(3);
                // String ner = rs.getString(3);
                POS = rs.getString(5);
                String dependency = rs.getString(6);
                String pred = rs.getString(7);
                String predicate = rs.getString(8);
                String arg = rs.getString(9);

                String owner = morphology.lemma(ownr, POS).toLowerCase();
                if (dependency.equals("OBJ") && POS.startsWith("NN") && !predicate.equals("Vehicle") && !POS.equals("NNP")) {
                    variable_name = owner;
                    break;
                }

                if ((dependency.equals("OBJ")) && POS.startsWith("NNS") && !POS.equals("NNP") && !owner_name.equalsIgnoreCase(owner) && !sent_type.equals("question") && !arg.equals("Responsible_party") && !predicate.equals("Vehicle")) {
                    variable_name = owner;
                    System.out.println("This sentence may have variable name:" + variable_name);
                    break;
                } else if ((dependency.equals("PRD")) && POS.startsWith("NN") && !POS.equals("NNP") && !owner_name.equalsIgnoreCase(owner) && !sent_type.equals("question") && !predicate.equals("Completeness")) {// 2ds1
                    variable_name = owner;
                    System.out.println("This sentence may have variable_name:" + variable_name);

                    break;
                } else if ((dependency.equals("NMOD")) && POS.startsWith("NNS") && !POS.equals("NNP") && !owner_name.equalsIgnoreCase(owner) && !sent_type.equals("question")) {
                    variable_name = owner;
                    System.out.println("This sentence may have variable_name:" + variable_name);

                    // break;
                } else if ((dependency.equals("PMOD")) && POS.startsWith("NNS") && !POS.equals("NNP") && !owner_name.equalsIgnoreCase(owner) && !sent_type.equals("question") && !predicate.equals("Personal_relationship")) {
                    variable_name = owner;
                    System.out.println("This sentence may have variable_name:" + variable_name);

                    //  break;
                } else if ((dependency.equals("PMOD")) && POS.equals("NN") && !owner_name.equalsIgnoreCase(owner) && !sent_type.equals("question") && !predicate.equals("Personal_relationship") && !predicate.equals("Temporal_collocation") && !predicate.equals("Calendric_unit")) {

                    variable_name = owner;
                    /* if (predicate.equals("Clothing")) {
                        variable_name = "cloth";
                        System.out.println("This sentence may have variable_name:" + variable_name);
                        break;
                    }*/
                } else if ((dependency.equals("ROOT")) && POS.equals("NN") && !owner_name.equalsIgnoreCase(owner) && !sent_type.equals("question")) {

                    variable_name = owner;
                    System.out.println("This sentence may have variable_name:" + variable_name);
                    break;

                }
                if ((dependency.equals("OBJ")) && POS.equals("NN") && !POS.equals("NNP") && !owner_name.equalsIgnoreCase(owner) && !sent_type.equals("question") && !arg.equals("Responsible_party") && !arg.equals("Part") && !predicate.equals("Completeness")) {
                    variable_name = owner;
                    System.out.println("This sentence may have variable name:" + variable_name);
                    break;
                }

                if ((dependency.equals("SUB")) && (POS.startsWith("NN")) && (!POS.equals("NNP")) && sent_type.equals("question")) {
                    variable_name = owner;
                    System.out.println("This sentence may have variable_name:" + variable_name);

                    break;

                }
                if ((dependency.equals("NMOD")) && (POS.startsWith("NN")) && (!POS.equals("NNP")) && sent_type.equals("question") && !arg.equals("Individuals") && !predicate.equals("Money")) {
                    variable_name = owner;
                    System.out.println("This sentence may have variable_name:" + variable_name);

                    // break;
                } else if ((dependency.equals("PMOD")) && (POS.startsWith("NN")) && (!POS.equals("NNP")) && sent_type.equals("question")) {
                    variable_name = owner;
                    System.out.println("This sentence may have variable_name:" + variable_name);

                    // break;
                }

            }// end of while
            if (variable_name != null) {
                variable_name = morphology.stem(variable_name);
                variable_name = morphology.lemma(variable_name, POS);
                variable_name = variable_name.toLowerCase();
            } else {
                System.out.println("No variable is found");
            }
        }//end of try
        catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        System.out.println("***********item ****************" + variable_name);
        if (variable_name != null) {
            return variable_name;
        } else {
            return null;
        }

    }

    public String find_var_atr(int i) throws Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for finidin variable attribute ...");
        try {
            String sql = "select * from SRLdata where sent_sl_no=? and dependency !=\"P\"";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, i + 1);
            System.out.println("ps:" + ps.toString());
            // ps.setInt(1, sentcount);
            ResultSet rs = ps.executeQuery();
            Morphology morphology = new Morphology();
            //   System.out.println("owner name is" + owner_name);
            while (rs.next()) {
                //String start=rs.getString(verb_name);
                String ownr = rs.getString(3);
                // String ner = rs.getString(3);
                String POS = rs.getString(5);
                String dependency = rs.getString(6);
                String predicate = rs.getString(8);
                String arg = rs.getString(9);

                String owner = morphology.lemma(ownr, POS).toLowerCase();
                System.out.println("owner is" + owner);
                //System.out.println("inside loop chek for question sentence attribute");
                if ((dependency.equals("AMOD") || dependency.equals("NMOD")) && (POS.startsWith("JJ") && (!POS.equals("JJR"))) && !POS.equals("NNP") && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && sent_type.equals("normal") && !predicate.equals("Age") && !predicate.equals("Relative_time") && !predicate.equals("Locative_relation")) {
                    variable_attribute = owner;
                    System.out.println("This sentence may have variable_attribute:" + variable_attribute);

                    break;
                } else if ((dependency.equals("NMOD")) && POS.startsWith("NN") && !POS.equals("NNP") && !POS.equals("NNS") && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && sent_type.equals("normal") && !predicate.equals("Social_event")) {
                    variable_attribute = owner;
                    System.out.println("This sentence may have variable_attribute:" + variable_attribute);

                    break;
                } else if ((dependency.equals("OBJ")) && POS.equals("NN") && !POS.equals("NNP") && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && sent_type.equals("normal") && !arg.equals("Goods")) {
                    if (variable_name == null || !variable_name.equalsIgnoreCase(owner)) {
                        variable_attribute = owner;
                        System.out.println("This sentence may have variable_attribute:" + variable_attribute);
                        break;
                    }

                } else if ((dependency.equals("OBJ")) && POS.equals("JJ") && !POS.equals("NNP") && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && sent_type.equals("normal")) {
                    if (variable_name == null || !variable_name.equalsIgnoreCase(owner)) {
                        variable_attribute = owner;
                        System.out.println("This sentence may have variable_attribute:" + variable_attribute);
                        break;
                    }

                }

                if ((dependency.equals("NMOD")) && (POS.startsWith("JJ")) && !POS.equals("NNP") && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && sent_type.equals("question") && !owner.equals("many") && !owner.equals("unbroken") && !predicate.equals("Completeness") && !predicate.equals("Quantity")) {
                    variable_attribute = owner;
                    System.out.println("This sentence may have variable_attribute:" + variable_attribute);

                    break;
                } else if ((dependency.equals("NMOD")) && (POS.startsWith("NN")) && !POS.equals("NNP") & !POS.equals("NNS") && (owner_name == null || !owner_name.equalsIgnoreCase(owner)) && sent_type.equals("question") && !predicate.equals("Measure_linear_extent") && !predicate.equals("Money")) {
                    variable_attribute = owner;
                    System.out.println("This sentence may have variable_attribute:" + variable_attribute);

                    break;
                }
                //System.out.println("variable attribute for this cycle"+variable_attribute);
                //  System.out.println("end loop");
            }// end of while
            if (variable_attribute != null || !variable_attribute.equals("NULL")) {
                // variable_name = morphology.stem(variable_name);
                // variable_name = morphology.lemma(variable_name, POS);
                System.out.println("variable attribute for this cycle" + variable_attribute);
                variable_attribute = variable_attribute.toLowerCase();
            } else {
                System.out.println("No attribute found");
            }

        }//end of try
        catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        System.out.println("***********variable attribute****************");

        return variable_attribute;

    }

    public void find_verb() {
        int vb = 0;
        int to = 0;
        Morphology morphology = new Morphology();
        String[] tokens = taggedString.split(" ");
        for (String tok : tokens) {
            String[] taggedTokens = tok.split("_");
            System.out.println("token:" + taggedTokens[1]);
            if (verb_lemma != null && (verb_lemma.equalsIgnoreCase("have") || taggedTokens[1].startsWith("VB")) && (to == 1 || taggedTokens[1].equals("VBN")) && !verb_lemma.equals("pick")) {
                vb = 0;
                to = 0;

            }
            if (taggedTokens[1].startsWith("VB") && vb != 1 && to == 0) {

                verb_name = taggedTokens[0];
                String tag = taggedTokens[1];
                System.out.println("The verb is: " + verb_name);
                verb_lemma = morphology.lemma(verb_name, tag);
                if (sent_type.equals("question") & verb_lemma.equals("be")) {
                    System.out.println("verb is ques" + verb_lemma);
                    break;
                }
                /*
                if (verb_lemma.equals("clean")) {  //similaruty based selection
                    verb_lemma = "go";
                }*/
                System.out.println("lemmatized version :" + verb_lemma);
                // verb_name = vrlemma;
                if (!verb_lemma.equalsIgnoreCase("be") && !verb_lemma.equalsIgnoreCase("do")) {
                    vb++;
                }

            }
            if (taggedTokens[1].startsWith("TO")) {
                to = 1;
                System.out.println("the sentence has to");
                // verb_name = vrlemma;
            }

        }
        if (verb_lemma == null) {
            verb_lemma = "be";
        }
    }

    public void set_VerbClass() throws Exception {
        VerbClass v = new VerbClass();

        v.sent_sl_no = this.sent_sl_no;
        v.verb_name = this.verb_name;
        v.verb_lemma = this.verb_lemma;
        v.owner_name = this.owner_name;
        v.second_owner = this.second_owner;
        v.variable_name = this.variable_name;
        v.variable_count = this.variable_count;
        //v.display();
        v.fill_table();
        // v.select_fill_verbs(sent_sl_no);

    }

    public void fill_equation() throws Exception {
        EquationGenerator eq = new EquationGenerator();
        eq.generator(sent_sl_no);
    }

    public void find_value() {
        int flag = 0;
        String[] tokens = taggedString.split(" ");
        for (String tok : tokens) {
            String[] taggedTokens = tok.split("_");
            if (taggedTokens[1].startsWith("CD")) {
                if (taggedTokens[0].contains(".")) {
                    double count = Double.parseDouble(taggedTokens[0]);
                    variable_count = (int) count;
                } else {
                    variable_count = Integer.parseInt(taggedTokens[0]);
                }
                flag = 1;

            }
        }
        if (flag == 0) {
            System.out.println("no values or number in this sentence");

        }

    }

    public void fill_table() throws Exception {

        Connection conn = DBconnect.getConnection();
        System.out.println("connection made ");
        System.out.println("Creating statement for filling sentence table...");
        // Statement stmt = conn.createStatement();
        String sql;

        sql = "INSERT INTO sentence ( sent_sl_no, sent_type, sentenceline, no_of_tokens, verb_name, verb_lemma, owner_name,second_owner, variable_name, item_specific_attribute, variable_count ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sent_sl_no);
            ps.setString(2, sent_type);
            ps.setString(3, sentenceline);
            ps.setInt(4, no_of_tokens);
            ps.setString(5, verb_name);
            ps.setString(6, verb_lemma);
            if (owner_name == null) {
                ps.setString(7, "any");
            } else {
                ps.setString(7, owner_name);
            }
            ps.setString(8, second_owner);
            ps.setString(9, variable_name);
            ps.setString(10, variable_attribute);
            ps.setInt(11, variable_count);
            ps.executeUpdate();
            System.out.println("done in sentence table");

            // update_table();
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

}
