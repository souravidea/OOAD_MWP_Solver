/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

/**
 *
 * @author Sourav
 */
public class ObjectItem {
    public String variable_name;
    public String owner_name;
    public String item_specific_attribute="NULL";
    public String unit;
    public int variable_count;
    
     public void fill_table(){
        
    }
     public void display(){
         System.out.println("variable name for item object:::"+item_specific_attribute+" "+variable_name +", owner name:::"+owner_name+"");
         
     }
    
}
