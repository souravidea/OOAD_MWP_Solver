/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

/**
 *
 * @author sourav
 */
public class ExpNode {
    int state_no;
   // int var_count;
    public int x;
    public String operator;
    public String verb_lemma;
     
    public ExpNode(int s, int x, String op, String lemma){
        state_no=s;
        this.x=x;
        this.operator=op;
        this.verb_lemma=lemma;
    }
    
    public void display(){
        System.out.println("state no:"+state_no);
        System.out.println("value is:"+x);
        System.out.println("operator is:"+operator);
        System.out.println("verb lemma is"+verb_lemma);
    }
    

}
