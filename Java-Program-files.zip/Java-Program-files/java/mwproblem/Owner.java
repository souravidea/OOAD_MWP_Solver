/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

/**
 *
 * @author Sourav
 */
public class Owner {

    // public int sent_sl_no;
    public String owner_name;
    // public String owner_specific_attribute;
    // public String name_entity;
    // public String srl_args;
    public String variable_name;
    public String variable_attribute="NULL";
    public int variable_count = 0;
    /*
    public void setname(String name) {
        owner_name = name;
    }

    public String getname() {
        return owner_name;
    }
    public String getitem() {
        return owner_name;
    }
    public String getattribute() {
        return owner_name;
    }*/

    public void display() {
        System.out.println("Owner is:" + owner_name);
        System.out.println("Variable is:" + variable_name);
        System.out.println("Variable attribute is:" + variable_attribute);
        System.out.println("Count:" + variable_count);

    }

}
