 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import java.io.IOException;
import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;

/**
 *
 * @author sourav
 */
public class RunSRLscript {
int iExitValue;
    String sCommandString;

    public void executeScript(String command) throws IOException {
        System.out.println("I am running SRL script");
        sCommandString = command;
        CommandLine oCmdLine = CommandLine.parse(sCommandString);
        DefaultExecutor oDefaultExecutor = new DefaultExecutor();
        oDefaultExecutor.setExitValue(0);
        try {
            iExitValue = oDefaultExecutor.execute(oCmdLine);
        } catch (ExecuteException e) {
            System.err.println("Execution failed.");
        } catch (IOException e) {
            System.err.println("permission denied.");
        }
    }
   /* public static void main(String[] args) throws IOException {
        RunSRLscript r=new RunSRLscript();
        r.executeScript("sh /home/sourav/mateplus-master/scripts/parse-framenet.sh /home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt");
    }*/

}
