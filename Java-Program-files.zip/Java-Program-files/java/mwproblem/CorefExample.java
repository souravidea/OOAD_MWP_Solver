/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import edu.stanford.nlp.hcoref.CorefCoreAnnotations;
import edu.stanford.nlp.hcoref.data.CorefChain;
import edu.stanford.nlp.hcoref.data.Mention;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;
import java.io.File;
import java.util.Map;

import java.util.Properties;
import java.util.Scanner;

public class CorefExample {

    public static void main(String[] args) throws Exception {
        String entireFileText = new Scanner(new File("/home/sourav/ques.txt")).useDelimiter("\\A").next();
        System.out.println(entireFileText);

        Annotation document = new Annotation(entireFileText);
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize,ssplit,pos,lemma,ner,parse,mention,coref");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        pipeline.annotate(document);
        Map<Integer, CorefChain> corefChains = document.get(CorefCoreAnnotations.CorefChainAnnotation.class);
        System.out.println("---");
        System.out.println("coref chains");
        for (CorefChain cc : document.get(CorefCoreAnnotations.CorefChainAnnotation.class).values()) {
            System.out.println("\t" + cc);
        }
        for (CoreMap sentence : document.get(CoreAnnotations.SentencesAnnotation.class)) {
            System.out.println("---");
            System.out.println("mentions");
            for (Mention m : sentence.get(CorefCoreAnnotations.CorefMentionsAnnotation.class)) {
                System.out.println("\t" + m);
            }
        }
        if (corefChains != null) {
            for (CorefChain chain : corefChains.values()) {
                CorefChain.CorefMention representative = chain.getRepresentativeMention();
                for (CorefChain.CorefMention mention : chain.getMentionsInTextualOrder()) {
                    System.out.println(mention);
                    if (mention == representative) {
                        continue;
                    }
                    // all offsets start at 1!
                    System.out.println("\t"
                            + mention.mentionID + ": (Mention from sentence " + mention.sentNum + ", "
                            + "Head word = " + mention.headIndex
                            + ", (" + mention.startIndex + "," + mention.endIndex + ")"
                            + ")"
                            + " -> "
                            + "(Representative from sentence " + representative.sentNum + ", "
                            + "Head word = " + representative.headIndex
                            + ", (" + representative.startIndex + "," + representative.endIndex + ")"
                            + "), that is: \""
                            + mention.mentionSpan + "\" -> \""
                            + representative.mentionSpan + "\"");
                }
            }
        }
    }
}
