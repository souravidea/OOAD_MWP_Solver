/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import static mwproblem.MWP.SENTENCE;

/**
 *
 * @author sourav
 */
public class removeirrelevantsent {

    public void invoke() throws FileNotFoundException, IOException {
        String sentenceline = null;
        int no_of_sentences = 0;
        boolean isnumberexist = false;
        boolean hasDoller = false;
        String sent_type = null;
        StringBuilder newques = new StringBuilder();
        int lines;
        try (BufferedReader reader = new BufferedReader(new FileReader("/home/sourav/MyResearch/MathWordProbSolver/build/web/sentence.txt"))) {
            lines = 0;
            while (reader.readLine() != null) {
                lines++;
            }
        }
        no_of_sentences = lines;
        System.out.println("total no of sentence is:  " + no_of_sentences);
        //sentence type

        String entireFileText = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        System.out.println("full question:" + entireFileText);
        if (entireFileText.contains("$")) {
            hasDoller = true;
        }
        ArrayList<String> sentenceList;
        try (Scanner sentence = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"))) {
            sentenceList = new ArrayList<>();
            while (sentence.hasNextLine()) {

                sentenceList.add(sentence.nextLine());
            }
        }

        String[] sentenceArray = sentenceList.toArray(new String[0]);

        for (String sentenceArray1 : sentenceArray) {
            if (!entireFileText.contains("$")) {

                SENTENCE = sentenceArray1.split("(?<=[.!?])\\s*"); //split sentences and store in array 
            } else {
                // SENTENCE = sentenceArray1.split("(?<=\\s*[.!?])\\s*");
                SENTENCE = sentenceArray1.split("[\\s . ]\\s");

            }

        }
        MaxentTagger tagger = new MaxentTagger("edu/stanford/nlp/models/pos-tagger/english-left3words/english-left3words-distsim.tagger");
        for (int i = 0; i < no_of_sentences; i++) {
            System.out.println("Sentence " + (i + 1) + ": " + SENTENCE[i]);
            sentenceline = SENTENCE[i];
            int sentlength = sentenceline.length();
            System.out.println("sent length:" + sentlength);
            if (sentenceline.charAt(sentlength - 1) == '?' || sentenceline.charAt(sentlength - 2) == '?') {
                System.out.println("the sentence type is question sentence");
                sent_type = "question";
            } else {
                System.out.println("not a question sentence");
                sent_type = "normal";
            }

            String taggedString = tagger.tagString(sentenceline);

            String[] tokens = taggedString.split(" ");
            for (String tok : tokens) {
                String[] taggedTokens = tok.split("_");
                if (taggedTokens[1].startsWith("CD")) {
                    isnumberexist = true;
                    System.out.println("sent-->" + sentenceline);

                }
                if (hasDoller = false && (taggedTokens[0].contains("some") || taggedTokens[0].contains("had"))) {
                    isnumberexist = true;
                    System.out.println("sent-->" + sentenceline);

                }
            }

            System.out.println("isnumberexist" + isnumberexist);
            if (isnumberexist == true || sent_type.equals("question")) {

                System.out.println(sentenceline);
                if (sent_type.equals("question")) {
                    newques.append(sentenceline);

                } else if (entireFileText.contains("$")) {
                    newques.append(sentenceline).append(". ");
                } else {
                    newques.append(sentenceline).append(" ");
                }

            }
            isnumberexist = false;
        }
        String newquestion = newques.toString();
        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"); //Your file
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream ps = new PrintStream(fos);
        System.setOut(ps);
        System.out.println(newquestion);

    }

    public static boolean isnumberexist() throws IOException {
        String sentenceline = null;
        int no_of_sentences = 0;
        boolean isnumberexist = false;
        boolean onesent = false;
        boolean hasDoller = false;
        String sent_type = null;
        // StringBuilder newques = new StringBuilder();
        int lines;
        try (BufferedReader reader = new BufferedReader(new FileReader("/home/sourav/MyResearch/MathWordProbSolver/build/web/sentence.txt"))) {
            lines = 0;
            while (reader.readLine() != null) {
                lines++;
            }
        }
        no_of_sentences = lines;
        // System.out.println("total no of sentence is:  " + no_of_sentences);
        //sentence type

        String entireFileText = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        // System.out.println("full question:" + entireFileText);
        if (entireFileText.contains("$")) {
            hasDoller = true;
        }
        ArrayList<String> sentenceList;
        try (Scanner sentence = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"))) {
            sentenceList = new ArrayList<>();
            while (sentence.hasNextLine()) {

                sentenceList.add(sentence.nextLine());
            }
        }

        String[] sentenceArray = sentenceList.toArray(new String[0]);

        for (String sentenceArray1 : sentenceArray) {
            if (!entireFileText.contains("$")) {

                SENTENCE = sentenceArray1.split("(?<=[.!?])\\s*"); //split sentences and store in array 
            } else {
                // SENTENCE = sentenceArray1.split("(?<=\\s*[.!?])\\s*");
                SENTENCE = sentenceArray1.split("[\\s . ]\\s");

            }

        }
        MaxentTagger tagger = new MaxentTagger("edu/stanford/nlp/models/pos-tagger/english-left3words/english-left3words-distsim.tagger");
        for (int i = 0; i < no_of_sentences; i++) {
            //  System.out.println("Sentence " + (i + 1) + ": " + SENTENCE[i]);
            sentenceline = SENTENCE[i];
            int sentlength = sentenceline.length();
            System.out.println("sent length:" + sentlength);
            if (sentenceline.charAt(sentlength - 1) == '?' || sentenceline.charAt(sentlength - 2) == '?') {
                System.out.println("the sentence type is question sentence");
                sent_type = "question";
            } else {
                System.out.println("not a question sentence");
                sent_type = "normal";
            }

            String taggedString = tagger.tagString(sentenceline);
            System.out.println("sent-->" + sentenceline);
            String[] tokens = taggedString.split(" ");
            for (String tok : tokens) {
                String[] taggedTokens = tok.split("_");
                if (taggedTokens[1].startsWith("CD")) {
                    isnumberexist = true;
                    
                    break;

                }
                if (hasDoller = false && (taggedTokens[0].contains("some") || taggedTokens[0].contains("had"))) {
                    isnumberexist = true;
                    System.out.println("sent-->" + sentenceline);

                }
            }

            System.out.println("isnumberexist" + isnumberexist);
            if (isnumberexist == false && !sent_type.equals("question")) {
                //isnumberexist = false;
                onesent = true;
            }
            isnumberexist=false;
        }
        System.out.println("missing?"+onesent);
        return onesent;
    }

}
