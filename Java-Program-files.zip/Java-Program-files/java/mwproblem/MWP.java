package mwproblem;

import edu.stanford.nlp.process.Morphology;
import edu.stanford.nlp.simple.Document;
import edu.stanford.nlp.simple.Sentence;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import static java.lang.Math.abs;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 *
 * @author Sourav
 */
public class MWP {

    public int problem_id = 1;
    public int no_of_sentences;
    public String problem_category = "addition_substraction";
    public String variable_name;
    public String owner_name;
    public String variable_attribute;
    public String mwp_verb;
    public int result;
    public static String[] SENTENCE;
    Sentences sent[] = new Sentences[no_of_sentences];
    // Owner obj[] = new Owner[no_of_sentences];
    public int total_owner;
    public int total_variable;
    ArrayList equationlist = new ArrayList();
    boolean summing = false;
    boolean hasDoller = false;
    boolean hasPayment = false;
    boolean issumming = true;
    String issummingowner = null;
    boolean issinglesumming = false;
    int own_count = 0;
    int varcount = 0;
    int var_atr_count = 0;
    /// boolean sabtracting = false;

    public void clearDBtables() throws Exception {
        Connection conn = null;
        Statement stmt = null;
        conn = DBconnect.getConnection();
        System.out.println("connection made");
        System.out.println("Creating statement...");
        stmt = conn.createStatement();
        try {

            String sql;
            sql = "DELETE FROM MWP";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM sentence";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM owner";
            stmt.executeUpdate(sql);
            /* sql = "DELETE FROM NERlist";
            stmt.executeUpdate(sql);*/
            sql = "DELETE FROM SRLdata";
            stmt.executeUpdate(sql);
            sql = "ALTER TABLE SRLdata AUTO_INCREMENT = 1";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM verbstable";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM objectitem";
            stmt.executeUpdate(sql);
            /*
            sql = "DELETE FROM have";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM give";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM find";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM cut";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM be";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM plant";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM place";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM grow";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM serve";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM pick";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM go";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM buy";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM finish";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM receive";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM spend";

            sql = "DELETE FROM attend";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM wash";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM stack";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM store";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM lose";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM borrow";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM eat";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM make";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM take";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM decide";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM sell";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM purchase";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM get";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM pay";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM cost";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM break";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM play";
            stmt.executeUpdate(sql);
            sql = "DELETE FROM spend";
            stmt.executeUpdate(sql);
*/
        } catch (SQLException se) {
            System.out.println("not working");

        } catch (Exception e) {
            //Handle errors for Class.forName
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void answer_type() throws FileNotFoundException {
        String q = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        if (q.contains("alltogether") || q.contains("together") || q.contains("overall") || q.contains("total") || q.contains("in all") || q.contains("sum") || q.contains("more") || q.contains("longer") || q.contains("larger") || q.contains("taller") || q.contains("bigger") || q.contains("much")) {
            summing = true;
        } else if (q.contains("left") || q.contains("remain") || q.contains("difference") || q.contains("less")) {
            summing = true;
        }

        if (q.contains("$")) {
            hasDoller = true;
            System.out.println("the question contains $ or dollar");
        }
        if ((q.contains("spent") || q.contains("bought") || q.contains("purchase") || q.contains("cost")) && hasDoller == true) {
            hasPayment = true;
        }

    }

    public void isAddAll() throws Exception {
        Connection conn = DBconnect.getConnection();
        System.out.println(conn);
        // String op = null;
       // System.out.println("Creating statement for checking the suuming  operation will be applicable or not!!.");
        /// Statement stmt = conn.createStatement();
        //String sql2 = "select * from owner";
        // System.out.println("Here");
        String sql2 = "select distinct owner_name, variable_name, item_specific_attribute from owner";

        // System.out.println(sql);
        PreparedStatement ps2 = conn.prepareStatement(sql2);
        int countowner = 0;
        try {
            ResultSet rs2 = ps2.executeQuery(sql2);
            // ResultSet rs3=ps2.executeQuery();
           // System.out.println("ps=" + ps2.toString());
            // System.1out.println("rs=" + rs2.toString());
            //System.out.println(rs2.next());
            // System.out.println(rs3.next());
            String sql1 = null;
            ResultSet rs1 = null;

            while (rs2.next()) {
               // System.out.println("I am here");
                String owner = rs2.getString(1);
                String item = rs2.getString(2);
                String attribute = rs2.getString(3);
                System.out.println("onwer=" + owner + " item=" + item + " attribute=" + attribute);
                if (item == null) {
                    sql1 = "SELECT operator FROM owner where owner_name=? and variable_name is null and item_specific_attribute=?";
                    PreparedStatement ps3 = conn.prepareStatement(sql1);
                    ps3.setString(1, owner);
                    // ps3.setString(2, item);
                    ps3.setString(2, attribute);
                   // System.out.println(ps3.toString());
                    //rs1 = ps3.executeQuery();
                } else {
                    sql1 = "SELECT operator FROM owner where owner_name=? and variable_name=? and item_specific_attribute=?";
                    PreparedStatement ps3 = conn.prepareStatement(sql1);
                    ps3.setString(1, owner);
                    ps3.setString(2, item);
                    ps3.setString(3, attribute);
                 //   System.out.println(ps3.toString());
                    rs1 = ps3.executeQuery();
                }

                int ownercount = 0;
                String op1 = null;
                int opcount = 0;
                while (rs1.next()) {
                    op1 = rs1.getString(1);
                    ownercount++;
                    // if (ownercount == 1) {
                    countowner++;
                    // }
                    if (op1 != null) {
                        opcount++;
                    }

                }
              //  System.out.println("owner count==" + ownercount);
               // System.out.println("op count==" + opcount);
               // System.out.println("count owner==" + countowner);
                if (ownercount > 1 && opcount > 0) {
                    issumming = false;
                    issummingowner = owner;
                  //  System.out.println("issummingowner==" + issummingowner);

                }

            }
            if (countowner == total_owner) {
                issinglesumming = true;

            }
         //   System.out.println("issumming==>" + issumming);
          //  System.out.println("total owner==>" + total_owner);
          //  System.out.println("issinglesumming==>" + issinglesumming);

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void count_sentence() throws FileNotFoundException, IOException {
        int lines;
        try (BufferedReader reader = new BufferedReader(new FileReader("/home/sourav/MyResearch/MathWordProbSolver/build/web/sentence.txt"))) {
            lines = 0;
            while (reader.readLine() != null) {
                lines++;
            }
        }
        no_of_sentences = lines;
        System.out.println("total no of sentence is:  " + no_of_sentences);

    }

    public void NERText() throws Exception {

        Statement stmt = null;
        Connection conn = DBconnect.getConnection();
        String entireFileText = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        //System.out.println(entireFileText);
        Document doc = new Document(entireFileText);
        int i = 0;
        int sent_sl_no = 1;
        for (Sentence sent : doc.sentences()) {
            List<String> nerTags = sent.nerTags();
            List<String> words = sent.words();
            //  System.out.println("word size" + words.size());

            try {
                // System.out.println("Connecting to database...");
                conn = DBconnect.getConnection();
                // System.out.println("Creating statement...");
                stmt = conn.createStatement();
                String sql;

                for (i = 0; i < words.size(); i++) {
                    // System.out.println("i=" + i);
                    String wordname = words.get(i);
                    String nertag = nerTags.get(i);

                    if (!nertag.equalsIgnoreCase("O")) {

                        sql = "INSERT INTO NERlist ( sent_sl_no, word, ner ) VALUES (?, ?,?)";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, sent_sl_no);
                            ps.setString(2, wordname);
                            ps.setString(3, nertag);
                            ps.executeUpdate();
                        }
                    }

                }
                sent_sl_no++;
                stmt.close();
                conn.close();
            } catch (SQLException se) {
                se.printStackTrace();

            } catch (Exception e) {
                //Handle errors for Class.forName
                e.printStackTrace();
            } finally {
                DBconnect.closeConnection(conn);

            }//end finally try
        }//end try
        //  System.out.println("Goodbye!");

    }

    public void processing_sentence() throws FileNotFoundException, IOException, ClassCastException, ClassNotFoundException, Exception {

        int i = 0;
        Sentences sentc[] = new Sentences[no_of_sentences];
        String tempOwner[] = new String[3];
        String prev_var = null;
        String prev_var_atr = null;
        String prev_owner = null;
        String ownn = null;
        String var = null;
        String var_atr = null;

        String entireFileText = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        System.out.println("full question:" + entireFileText);
        ArrayList<String> sentenceList;
        try (Scanner sentence = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"))) {
            sentenceList = new ArrayList<>();
            while (sentence.hasNextLine()) {

                sentenceList.add(sentence.nextLine());
            }
        }

        String[] sentenceArray = sentenceList.toArray(new String[0]);

        for (String sentenceArray1 : sentenceArray) {
            if (!entireFileText.contains("$")) {

                SENTENCE = sentenceArray1.split("(?<=[.!?])\\s*"); //split sentences and store in array 
            } else {
                // SENTENCE = sentenceArray1.split("(?<=\\s*[.!?])\\s*");
                SENTENCE = sentenceArray1.split("[\\s . ]\\s");

            }

        }

        for (i = 0; i < no_of_sentences; i++) {
            System.out.println("Sentence " + (i + 1) + ": " + SENTENCE[i]);
            sentc[i] = new Sentences();
            if (!SENTENCE[i].endsWith(" ?")) {
                sentc[i].sentenceline = SENTENCE[i];
            } else {
                sentc[i].sentenceline = SENTENCE[i];
            }
            sentc[i].sent_sl_no = i + 1;
            sentc[i].count_tokens();
        }

        i = 0;
        while (i < no_of_sentences) {

            System.out.println("sentence " + (i + 1) + " : " + sentc[i].sentenceline);
            //  System.out.println("Sentence " + (i + 1) + "  :type: " + sent[i].find_sentence_type());
            String sent_type = sentc[i].find_sentence_type();

            // check relevancy of the sentence
            //   System.out.println("sentence  " + (i + 1) + "  :token count: " + sent[i].no_of_tokens);
            sentc[i].tagging();

            System.out.println("sentence  " + (i + 1) + " :tagged string:" + sentc[i].taggedString);
            sentc[i].find_verb();
            sentc[i].find_value();
            /*
            prev_var = var;
            prev_var_atr = var_atr;
            tempOwner = sentc[i].dParsing(tempOwner);
            System.out.println("TEMP OWNER:" + tempOwner[0] + "  and  " + tempOwner[1] + " and " + tempOwner[2]);
            var = tempOwner[1];
            var_atr = tempOwner[2];
           // sentc[i].confirm_owner(i);
            sentc[i].find_second_owner(i);
            if (sent_type.equals("question")) {
                this.owner_name = sentc[i].owner_name;
                this.variable_name = sentc[i].variable_name;
                this.variable_attribute = sentc[i].variable_attribute;
                System.out.println("Owner of the problem is " + owner_name);

            }

            if (var != null && (prev_var == null || !var.equals(prev_var)) && !sent_type.equals("question")) {
                varcount++;
            }
            if ((var_atr != null && !var_atr.equals("NULL")) && (prev_var_atr == null || !var_atr.equals(prev_var_atr)) && !sent_type.equals("question")) {

                var_atr_count++;
                System.out.println("sent type" + sent_type + "var_count" + var_atr_count);
            }
            //  System.out.println("NER procedure is started===>");
            System.out.println("proceesing sentences done---------------------------------");
            i++;
        }*/
            //new approach
            System.out.println("previous owner=" + prev_owner);
            ownn = sentc[i].find_owner(i);
            if (ownn == null) {
                ownn = "any";
            }
            if ((!ownn.equals("any")) && (prev_owner == null || !ownn.equals(prev_owner)) && !sent_type.equals("question")) {
                own_count++;
                //System.out.println("owwwwwwwwwnner"+ownn);
                prev_owner = ownn;
            }
            ownn = sentc[i].find_second_owner(i);
            if (ownn != null && (prev_owner == null || !ownn.equals(prev_owner)) && !sent_type.equals("question")) {

                own_count++;
                // System.out.println("owwwwwwwwwnner"+ownn);
                prev_owner = ownn;
            }
            var = sentc[i].find_var(i);
            var_atr = sentc[i].find_var_atr(i);
            System.out.println("previous Item was:" + prev_var);
            if (var != null && (prev_var == null || !var.equals(prev_var)) && !sent_type.equals("question")) {
                System.out.println("Item==>" + var);
                varcount++;
                prev_var = var;

            }
            if ((var_atr != null && !var_atr.equals("NULL") && !var_atr.equals("null")) && (prev_var_atr == null || !var_atr.equals(prev_var_atr)) && !sent_type.equals("question")) {
                System.out.println("Item attribute==>" + var_atr);
                var_atr_count++;
                System.out.println("sent type" + sent_type + "var_atrribute count" + var_atr_count);
                prev_var_atr = var_atr;
            }
            // System.out.println("sentence q_owner:"+sentc[i].q_owner);
            if (sentc[i].q_owner != null) {
                this.owner_name = sentc[i].q_owner;
                System.out.println("owner of MWP=" + owner_name);
            }
            System.out.println("proceesing sentences done---------------------------------");

            if (sent_type.equals("question")) {

                if (this.owner_name != null && (sentc[i].sentenceline.contains("there") || sentc[i].sentenceline.contains("many"))) {
                    System.out.println("fine");
                } else {
                    this.owner_name = sentc[i].owner_name;
                }
                this.variable_name = sentc[i].variable_name;
                this.variable_attribute = sentc[i].variable_attribute;
                System.out.println("question verb:" + sentc[i].verb_lemma);
                this.mwp_verb = sentc[i].verb_lemma;

                System.out.println("Owner of the problem is " + owner_name);
                System.out.println("variable attribute is" + this.variable_attribute);
                System.out.println("verb is---" + this.mwp_verb);
                //fill_table();
            }
            i++;
        }
        System.out.println("Total number of owners: " + own_count);
        System.out.println("Total number of variables are : " + varcount);
        System.out.println("Total number of variable attributes are : " + var_atr_count);
        i = 0;
        while (i < no_of_sentences - 1) {
            // sent[i].display_info();
            sentc[i].set_VerbClass();
            sentc[i].fill_table();
            sentc[i].fill_equation();
            i++;
            System.out.println("********************************");

        }

    }

    public void fill_table() throws Exception {

        Connection conn = DBconnect.getConnection();
        //  System.out.println("connection made");
        System.out.println("Creating statement for MWP table...");
        //Statement stmt = conn.createStatement();
        String sql;
        System.out.println("mwp_verb" + mwp_verb);
        System.out.println("variable name" + variable_name);
        if (mwp_verb != null && variable_name == null) {
            this.variable_name = find_var_mwp();
            System.out.println("variable name" + variable_name);
        }
        sql = "INSERT INTO MWP ( problem_id, no_of_sentences, problem_category, owner_name, variable_name, item_specific_attribute, verb) VALUES (?, ?, ?, ?, ?, ?, ?)";
        // try (PreparedStatement ps = conn.prepareStatement(sql)) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            System.out.println(ps.toString());
            ps.setInt(1, problem_id);
            ps.setInt(2, no_of_sentences);
            ps.setString(3, problem_category);
            ps.setString(4, owner_name);
            ps.setString(5, variable_name);
            ps.setString(6, variable_attribute);
            ps.setString(7, mwp_verb);
            // ps.setInt(8,result);
            ps.executeUpdate();
            System.out.println("salman");
            // ps.executeQuery();
            System.out.println("sql:" + ps.toString());
            System.out.println("done in MWP table");

        } catch (SQLException se) {
            System.out.println("not working");

        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void fill_SRLframes() throws Exception {
        //done for finding SRL for one time
        RunSRLscript r = new RunSRLscript();
        r.executeScript("sh /home/sourav/mateplus-master/scripts/parse-framenet.sh /home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt");
        System.out.println("SRL done");
        Connection conn = null;
        Statement stmt = null;
        conn = DBconnect.getConnection();
        //  System.out.println("connection made for SRL process");
        //  System.out.println("Creating statement...");

        FileReader file = new FileReader("/home/sourav/MyResearch/MathWordProbSolver/out.txt");

        //BufferedReader reader = new BufferedReader(file);
        // String line;
        int sentcount = 0;
        stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        String sql;
        try {
            sql = "load data local infile '/home/sourav/MyResearch/MathWordProbSolver/out.txt' into table SRLdata columns terminated by '\\t' lines terminated by '\\n' (sent_sl_no,word,@dummy,lemma,@dummy,POS,@dummy,@dummy,@dummy,@dummy,@dummy,dependency,ispred,pred,Args1,Args2,Args3,Args4,Args5,Args6)";
            stmt.executeUpdate(sql);

            String sql1 = "select * from SRLdata";
            PreparedStatement ps = conn.prepareStatement(sql1);
            // ps.setInt(1, sentcount);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                int sentid = rs.getInt(2);
                if (sentid == 1) {
                    sentcount++;

                }
                if (sentid != 0) {
                    String sql2 = "update SRLdata set sent_sl_no=? where id=?";
                    PreparedStatement ps2 = conn.prepareStatement(sql2);
                    ps2.setInt(1, sentcount);
                    ps2.setInt(2, id);
                    ps2.executeUpdate();

                } else {
                    String sql2 = "delete from SRLdata where id=?";
                    PreparedStatement ps2 = conn.prepareStatement(sql2);
                    ps2.setInt(1, id);
                    ps2.executeUpdate();
                }

            }

        } catch (SQLException se) {
            System.out.println("not done in srl" + se);

        } catch (Exception e) {
            System.out.println("SRL data entry exception");
        } finally {
            System.out.println("done for srl");
            DBconnect.closeConnection(conn);

        }

    }

    public void createOwnerItemObject() throws Exception {
        //select from NERLIST
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for creating owner object...");
        // Statement stmt = conn.createStatement();
        int i = 0;
        int k = 0;
        String V = null;
        Owner own[] = new Owner[15];
        ObjectItem var[] = new ObjectItem[15];
        try {
            // String sql = "select distinct SRLdata.word,SRLdata.dependency from SRLdata where ((SRLdata.dependency=\"SUB\" or SRLdata.dependency=\"OBJ\" or SRLdata.dependency=\"PMOD\") and not SRLdata.POS=\"NNS\") and (SRLdata.POS=\"NN\" or SRLdata.POS=\"NNP\" or SRLdata.POS=\"NNPS\" ) and not SRLdata.Args1=\"_\"";//use SRL here
            // String sql = "select distinct SRLdata.word,SRLdata.dependency from SRLdata where ((SRLdata.dependency=\"SUB\" or SRLdata.dependency=\"OBJ\" or SRLdata.dependency=\"PMOD\") and not SRLdata.POS=\"NNS\") and (SRLdata.POS=\"NN\" or SRLdata.POS=\"NNP\" or SRLdata.POS=\"NNPS\" ) and (not SRLdata.Args1=\"_\" or not SRLdata.Args2=\"_\" or not SRLdata.Args3=\"_\" or not SRLdata.Args4=\"_\" or not SRLdata.Args5=\"_\" or not SRLdata.Args6=\"_\")";
            // String sql = "select distinct SRLdata.word,SRLdata.dependency from SRLdata where (SRLdata.dependency=\"SUB\" or SRLdata.dependency=\"OBJ\" or SRLdata.dependency=\"PMOD\") and (SRLdata.POS=\"NN\" or SRLdata.POS=\"NNP\" or SRLdata.POS=\"NNPS\" or SRLdata.POS=\"NNS\" ) and (not SRLdata.Args1=\"_\" or not SRLdata.Args2=\"_\" or not SRLdata.Args3=\"_\" or not SRLdata.Args4=\"_\" or not SRLdata.Args5=\"_\" or not SRLdata.Args6=\"_\")";
            String sql = "select distinct SRLdata.word,SRLdata.POS, SRLdata.dependency from SRLdata where (SRLdata.dependency=\"SUB\" or SRLdata.dependency=\"OBJ\" or SRLdata.dependency=\"PMOD\" or SRLdata.dependency=\"NMOD\" or SRLdata.dependency=\"PRD\") and (SRLdata.POS=\"NN\" or SRLdata.POS=\"NNP\" or SRLdata.POS=\"NNPS\" or SRLdata.POS=\"NNS\" or SRLdata.POS=\"JJ\")";
            PreparedStatement ps = conn.prepareStatement(sql);
            // ps.setString(1, sent[i].owner_name);
            System.out.println("ps:" + ps.toString());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String word = rs.getString(1);
                Morphology morphology = new Morphology();
                word = morphology.stem(word);
                word = word.toLowerCase();
                // String pos=rs.getString(2);
                //word=morphology.lemma(word,pos);
                String dep = rs.getString(3);
                System.out.println("word:" + word);
                if (word.equals("scissors")) {
                    word = "scissor";
                }
                int flagowner = 0;
                int flagvariable1 = 0;
                int flagvariable2 = 0;
                //if(owner.equals(owner_name)){
                if (dep.equals("SUB") || dep.equals("OBJ") || dep.equals("PMOD") || dep.equals("NMOD") || dep.equals("PRD")) {
                    System.out.println("inside the loop and i=>" + i);

                    //----------------------------
                    String sql1 = "select sent_sl_no,owner_name,second_owner,variable_name,item_specific_attribute, variable_count from sentence where owner_name=? or second_owner=? or variable_name=? or item_specific_attribute=?";
                    PreparedStatement ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, word);
                    ps1.setString(2, word);
                    ps1.setString(3, word);
                    ps1.setString(4, word);
                    System.out.println("ps1:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        System.out.println("&&&&&>>>>>Object Creations>>>>>>>>>>>>");

                        int sent_no = rs1.getInt(1);
                        String o_name = rs1.getString(2).toLowerCase();
                        String s_name = rs1.getString(3);
                        String v_name = rs1.getString(4);
                        String v_a_name = rs1.getString(5);
                        int v_count = rs1.getInt(6);
                        System.out.println("O_name=>" + o_name);
                        System.out.println("s_name==>" + s_name);
                        System.out.println("V_name==>" + v_name);

                        System.out.println("V_atribut_name==>" + v_a_name);
                        if (o_name == null) {
                            o_name = "any";
                        }

                        if ((word.equalsIgnoreCase(o_name) || word.equalsIgnoreCase(s_name) || o_name.equals("any")) && (V == null || !o_name.equals(V))) {//q-84 of DS2

                            //---------------------------
                            if (i == 0) {
                                own[i] = new Owner();
                                if (o_name.equals("any")) {
                                    own[i].owner_name = "any";
                                    word = "any";
                                } else {
                                    own[i].owner_name = word;
                                }
                                own[i].variable_name = v_name;
                                own[i].variable_attribute = v_a_name;
                                System.out.println(i + " index " + "object created for the " + own[i].owner_name);
                                own[i].display();
                                String replaceString = "obj[" + i + "]";
                                //if(o)
                                evaluate_equation(word, v_name, v_a_name, replaceString);
                                i++;
                            } else {
                                System.out.println("word is" + word);
                                System.out.println("flagownr" + flagowner);
                                for (int j = 0; j < i; j++) {
                                    System.out.println("owners specifications are  " + own[j].owner_name + ":::" + own[j].variable_name + ":::" + own[j].variable_attribute);
                                    System.out.println("variable name=>" + own[j].variable_name);
                                    if (own[j].owner_name.equalsIgnoreCase(word) && (own[j].variable_name == null || own[j].variable_name.equalsIgnoreCase(v_name)) && own[j].variable_attribute.equalsIgnoreCase(v_a_name)) {
                                        if (own[j].variable_name == null && v_name != null && j != i) {
                                            System.out.println("the owner object are to be created");
                                        } else {
                                            flagowner = 1;
                                            System.out.println("Already the owner object is created");
                                            break;
                                        }

                                    }
                                }
                                System.out.println("flagownr--->" + flagowner);
                                if (flagowner == 0) {
                                    System.out.println("llllllllllll");
                                    own[i] = new Owner();
                                    own[i].owner_name = word;
                                    own[i].variable_name = v_name;

                                    own[i].variable_attribute = v_a_name;
                                    System.out.println(i + " index " + "object created for the " + own[i].owner_name);
                                    own[i].display();
                                    String replaceString = "obj[" + i + "]";

                                    evaluate_equation(word, v_name, v_a_name, replaceString);
                                    i++;
                                }
                                flagowner = 0;

                            }
                            System.out.println("owner objects with specific item and attributes are completed !!!!!!!");
                            //-------------------------------------------  
                        } //end owner object creation
                        else if (word.equalsIgnoreCase(v_name) || word.equalsIgnoreCase(v_a_name)) {
                            String ownr = null;
                            System.out.println("k=" + k);
                            if (k == 0) {
                                var[k] = new ObjectItem();
                                System.out.println("k=" + k);
                                var[k].variable_name = v_name;
                                var[k].item_specific_attribute = v_a_name;
                                if (o_name != null && s_name != null) {
                                    var[k].owner_name = o_name;
                                    ownr = o_name;
                                }
                                if (o_name != null && s_name == null) {
                                    var[k].owner_name = o_name;
                                    ownr = o_name;
                                } else {
                                    var[k].owner_name = s_name;
                                    ownr = s_name;
                                }
                                System.out.println("variable object created for the " + var[k].item_specific_attribute + " " + var[k].variable_name + "of owner" + var[k].owner_name);
                                var[k].display();
                                fill_Item_table(sent_no, v_name, v_a_name, ownr, v_count);//fill the variable table
                                ownr = null;
                                k++;
                            } else {
                                System.out.println("k==" + k);
                                for (int j = 0; j < k; j++) {
                                    if ((var[j].variable_name == null || var[j].variable_name.equals(v_name)) && (var[j].owner_name == null || var[j].owner_name.equals(o_name)) && (var[j].item_specific_attribute == null || var[j].item_specific_attribute.equals(v_a_name))) {
                                        flagvariable1 = 1;
                                        break;

                                    }
                                }
                                for (int j = 0; j < k; j++) {
                                    if ((var[j].variable_name == null || var[j].variable_name.equals(v_name)) && (var[j].owner_name == null || var[j].owner_name.equals(s_name) || s_name == null) && (var[j].item_specific_attribute == null || var[j].item_specific_attribute.equals(v_a_name))) {
                                        flagvariable2 = 1;
                                        // System.out.println("Already the variable object is created");
                                        break;
                                    }

                                }

                                //
                                System.out.println("flagvar1=>" + flagvariable1 + "flagvar2==>" + flagvariable2);
                                if ((flagvariable1 == 0 && flagvariable2 != 0) || (flagvariable1 != 0 && flagvariable2 == 0) || (flagvariable1 == 0 && flagvariable2 == 0)) {
                                    var[k] = new ObjectItem();
                                    var[k].variable_name = v_name;
                                    var[k].owner_name = o_name;
                                    var[k].item_specific_attribute = v_a_name;
                                    if (o_name != null && s_name == null) {
                                        var[k].owner_name = o_name;
                                        ownr = o_name;
                                    } else if (o_name != null && s_name != null) {
                                        var[k].owner_name = o_name;
                                        for (int j = 0; j < k; j++) {
                                            if ((var[j].variable_name == null || var[j].variable_name.equals(v_name)) && var[j].owner_name.equals(o_name)) {
                                                var[k].owner_name = s_name;
                                                ownr = s_name;
                                                break;
                                            } else {
                                                var[k].owner_name = o_name;
                                                ownr = o_name;
                                            }
                                        }
                                    } else if (o_name == null && s_name != null) {
                                        var[k].owner_name = s_name;
                                        ownr = s_name;
                                    }
                                    System.out.println("variable object created for the " + var[k].item_specific_attribute + " " + var[k].variable_name + "of owner" + var[k].owner_name);
                                    // System.out.println("object created for the " + var[k].variable_name + "of owner" + var[k].owner_name);
                                    var[k].display();
                                    fill_Item_table(sent_no, v_name, v_a_name, ownr, v_count);//fill the variable table
                                    k++;
                                } else {
                                    System.out.println("Already the variable object is created!");
                                }
                            }
                            flagvariable1 = 0;
                            flagvariable2 = 0;
                            ownr = null;
                        }//end variable object creation
                        V = v_name;
                    }
                }// end of if
                System.out.println("DONE FOR WORD <><><><>" + word);
            }//ens rs

            total_owner = i;
            total_variable = k;
            System.out.println("Total no of Owners are:" + total_owner);
            System.out.println("Total no of Variables are:" + total_variable);

            update_owner_table();//update owner table with all variable

             generate_result();// for emnlp paper to solve MWP

            /* int x = create_expression_node(var);//create list of all owners containing variable and equation addition subtraction
          
            
            File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/answer.txt"); //Your file
            FileOutputStream fos = new FileOutputStream(file);
            PrintStream ps1 = new PrintStream(fos);
            System.setOut(ps1);
          //  System.out.println("result=" + x);*/ //old paper
            // createJavaProgram(own, x);
            ///first paper process
            //evaluateMulDiv();
             int x1 = 0;//for new work
             createJavaProgram(own, x1);//for auto program this 2 line
          //  createJavaProgramall(own);//for auto program all category
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void evaluate_equation(String word, String v_name, String v_a_name, String replaceString) throws Exception {//in process
        int i = 1;
        int j = 1;
        String eq = null;
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for evaluation of equation ..");
        // Statement stmt = conn.createStatement();
        try {
            String sql = null;
            PreparedStatement ps1 = null;
            if (v_name == null) {
                //sql = "select owner_name, verb_lemma, pipeline_equation1,variable_name,item_specific_attribute, variable_count from sentence where owner_name= ? and variable_name is null and item_specific_attribute= ?";
                sql = "select owner_name, second_owner, verb_lemma, pipeline_equation1, pipeline_equation2, variable_name,item_specific_attribute, variable_count from sentence where ( owner_name= ? or second_owner = ? ) and variable_name is null and item_specific_attribute= ?";
                System.out.println(sql);
                ps1 = conn.prepareStatement(sql);
                ps1.setString(1, word);
                ps1.setString(2, word);
                // ps1.setString(2, v_name);
                ps1.setString(3, v_a_name);
            } else {
                // sql = "select owner_name, verb_lemma, pipeline_equation1,variable_name,item_specific_attribute, variable_count from sentence where owner_name= ? and variable_name= ? and item_specific_attribute= ?";
                sql = "select owner_name, second_owner, verb_lemma, pipeline_equation1, pipeline_equation2, variable_name,item_specific_attribute, variable_count from sentence where ( owner_name= ? or second_owner = ? ) and variable_name= ? and item_specific_attribute= ?";
                System.out.println(sql);
                ps1 = conn.prepareStatement(sql);
                ps1.setString(1, word);
                ps1.setString(2, word);
                ps1.setString(3, v_name);
                ps1.setString(4, v_a_name);
            }
            // ps1.setString(2, word);
            System.out.println("query is:" + ps1.toString());
            ResultSet rs1 = ps1.executeQuery();

            while (rs1.next()) {
                System.out.println("@@@@@");
                String owner_name1 = rs1.getString(1);
                String second_owner = rs1.getString(2);
                String verblemma = rs1.getString(3);
                String equation1 = rs1.getString(4);
                String equation2 = rs1.getString(5);
                String var_name = rs1.getString(6);
                String var_attribute = rs1.getString(7);
                int var_count = rs1.getInt(8);
                // String equation2 = rs1.getString(4);
                System.out.println("owner name=>" + owner_name1);
                System.out.println("second owner name ==>" + second_owner);
                System.out.println("equation1==>" + equation1);
                System.out.println("equation2==>" + equation2);

                if ((equation1 != null) && equation1.startsWith(owner_name1) && owner_name1.equals(word)) {
                    // eq = equation1.replaceFirst(owner_name1, replaceString);
                    eq = equation1.replaceAll(owner_name1, replaceString);
                    System.out.println("new equation is" + eq);
                    equationlist.add(eq);

                    fill_owner_table(j, eq, owner_name1, verblemma, var_name, var_attribute, var_count);
                    j++;
                    //update owner table
                }
                if (equation2 != null && (second_owner != null && equation2.startsWith(second_owner)) && second_owner.equals(word)) {
                    // eq = equation1.replaceFirst(owner_name1, replaceString);
                    eq = equation2.replaceAll(second_owner, replaceString);
                    System.out.println("new equation is" + eq);
                    equationlist.add(eq);
                    fill_owner_table(j, eq, second_owner, verblemma, var_name, var_attribute, var_count);
                    j++;
                    //update owner table
                }
                /*else if (equation2 != null && equation2.startsWith(second_owner)) {
                    // eq = equation1.replaceFirst(owner_name1, replaceString);
                    eq = equation2.replaceAll(second_owner, replaceString);
                    System.out.println("new equation is" + eq);
                    equationlist.add(eq);
                    fill_owner_table(j, eq, second_owner, verblemma, var_name, var_attribute, var_count);
                    //update owner table
                }*/

            }

            /*  sql = "select second_owner, verb_lemma, pipeline_equation2,variable_name, item_specific_attribute, variable_count from sentence where second_owner= ? and variable_name = ? and item_specific_attribute= ?";
            System.out.println(sql);
            PreparedStatement ps2 = conn.prepareStatement(sql);
            ps2.setString(1, word);
            ps2.setString(2, v_name);
            ps2.setString(3, v_a_name);
            // ps1.setString(2, word);
            System.out.println("query is" + ps2.toString());
            ResultSet rs2 = ps2.executeQuery();

            // String eq;
            while (rs2.next()) {
                System.out.println("####");
                // String owner_name1 = rs2.getString(1);
                String second_owner = rs2.getString(1);
                String verblemma = rs2.getString(2);
                //String equation1 = rs2.getString(2);
                String equation2 = rs2.getString(3);
                String var_name = rs2.getString(4);
                String var_attribute = rs2.getString(5);
                int var_count = rs2.getInt(6);
                // System.out.println("count=>");
                // System.out.println("owner name=>"+owner_name1);
                System.out.println("second owner name ==>" + second_owner);
                // System.out.println("equation1==>"+equation1);
                System.out.println("equation2==>" + equation2);

                if (equation2 != null && equation2.startsWith(second_owner)) {
                    // eq = equation1.replaceFirst(owner_name1, replaceString);
                    eq = equation2.replaceAll(second_owner, replaceString);
                    System.out.println("new equation is" + eq);
                    equationlist.add(eq);
                    fill_owner_table(j, eq, second_owner, verblemma, var_name, var_attribute, var_count);
                    //update owner table
                }

            }*/
            System.out.println("statement creation done-----*****");
            //update owner table
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        // 
        // return eq;
    }

    public void fill_owner_table(int j, String eq, String name_owner, String verbname, String var_name, String var_attribute, int var_count) throws Exception {

        Connection conn = DBconnect.getConnection();
        System.out.println("connection made ");
        System.out.println("Creating statement for filling owner table...");
        // Statement stmt = conn.createStatement();
        String sql;
        System.out.println(eq);
        System.out.println("j val is" + j);
        //int val = Integer.parseInt(eq);
        sql = "INSERT INTO owner ( state_no, owner_name, verb_lemma, variable_name,item_specific_attribute, variable_count, equation ) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, j);
            ps.setString(2, name_owner);
            ps.setString(3, verbname);
            ps.setString(4, var_name);
            ps.setString(5, var_attribute);

            ps.setInt(6, var_count);
            ps.setString(7, eq);
            ps.executeUpdate();
            System.out.println("done in owner table");
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void update_owner_table() throws SQLException, Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for updation of owner equation table...");
        // Statement stmt = conn.createStatement();

        // String sql = "select distinct owner.owner_name, owner.verb_lemma,operator1,operator2 from verblist,owner,sentence where verblist.verb_lemma=owner.verb_lemma and owner.owner_name=sentence.owner_name";
        String sql = "select distinct owner.owner_name, owner.verb_lemma,operator1 from verblist,owner,verbstable where owner.verb_lemma=verblist.verb_lemma and verbstable.owner_name=owner.owner_name and owner.verb_lemma=verbstable.verb_lemma";

        System.out.println(sql);
        PreparedStatement ps = conn.prepareStatement(sql);
        try {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String ownername = rs.getString(1);
                System.out.println("owner _name" + ownername);
                String verblemma = rs.getString(2);
                String op1 = rs.getString(3);
                //String op2 = rs.getString(4);
                sql = "UPDATE owner set operator= ? where verb_lemma= ? and owner_name=?";
                // System.out.println(sql);
                ps = conn.prepareStatement(sql);

                ps.setString(1, op1);
                ps.setString(2, verblemma);
                ps.setString(3, ownername);
                System.out.println("ps==>" + ps.toString());
                if (op1 != null) {
                    ps.executeUpdate();
                }

            }
            // sql = "select distinct owner.owner_name, owner.verb_lemma, operator2 from verblist,owner,sentence where verblist.verb_lemma=owner.verb_lemma and owner.owner_name=sentence.second_owner";
            sql = "select distinct owner.owner_name, owner.verb_lemma,operator2 from verblist,owner,verbstable where owner.verb_lemma=verblist.verb_lemma and verbstable.second_owner=owner.owner_name and owner.verb_lemma=verbstable.verb_lemma";
            PreparedStatement ps1 = conn.prepareStatement(sql);
            ResultSet rs1 = ps1.executeQuery();
            while (rs1.next()) {
                String ownername = rs1.getString(1);
                String verblemma = rs1.getString(2);
                // String op1 = rs1.getString(3);
                String op2 = rs1.getString(3);
                System.out.println("second owner name=>" + ownername);
                System.out.println("verb lemma is" + verblemma);
                System.out.println("op2 is" + op2);
                sql = "UPDATE owner set operator= ? where verb_lemma= ? and owner_name=?";

                ps1 = conn.prepareStatement(sql);
                ps1.setString(1, op2);
                ps1.setString(2, verblemma);
                ps1.setString(3, ownername);
                // System.out.println(sql);
                System.out.println("ps=>" + ps1.toString());
                if (op2 != null) {
                    ps1.executeUpdate();
                }
            }

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
    }

    public void fill_Item_table(int sent_sl_no, String var, String var_attribute, String ownr, int count) throws Exception {

        Connection conn = DBconnect.getConnection();
        System.out.println("connection made");
        System.out.println("Creating statement for ObjectItem table...");
        //Statement stmt = conn.createStatement();
        String sql;

        sql = "INSERT INTO objectitem ( sent_sl_no,variable_name, owner_name, item_specific_attribute, variable_count ) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sent_sl_no);
            ps.setString(2, var);
            ps.setString(3, ownr);
            ps.setString(4, var_attribute);
            ps.setInt(5, count);
            ps.executeUpdate();
            System.out.println("done in variable table");

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            //Handle errors for Class.forName
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void display() {

        System.out.println("display arraylist: " + equationlist);

    }

    public void createJavaProgram(Owner obj[], int x) throws Exception {

        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter out = null;
        boolean done = false;
        boolean attributematch = false;
        boolean itemmatch = false;
        try {
            String atr = null;
            String var = this.variable_name;
            atr = this.variable_attribute;
            isAddAll();
          //  System.out.println("variable=" + var);
          // System.out.println("attribute==" + atr);
          //  System.out.println("x(Result)==>" + x);
            fw = new FileWriter("/home/sourav/MyResearch/MathWordProbSolver/Evaluation.java");
            bw = new BufferedWriter(fw);
            out = new PrintWriter(bw);
            //class template
            out.println("class Owner1 {");
            out.println("public String owner_name;");
            out.println("public String variable_name;");
            out.println("public String variable_attribute;");
            out.println("public int variable_count = 0;");
            out.println("public void setname(String name, String var, String atr) {");
            out.println("owner_name = name;");
            out.println("variable_name = var;");
            out.println("variable_attribute = atr;");
            out.println('}');
            /*
            out.println("public String getitem() {");
            out.println("return owner_name;");
            out.println('}');
             out.println("public String getattribute() {");
            out.println("return owner_name;");
            out.println('}');
             out.println("public String getname() {");
            out.println("return owner_name;");
            out.println('}');
             */
            out.println(" public void display() {");
            out.println("System.out.println(\"Owner is:\" + owner_name);");
            out.println("System.out.println(\"Variable is:\" + variable_name);");
            out.println("System.out.println(\"Variable attribute is:\" + variable_attribute);");
            out.println("System.out.println(\"Count:\" + variable_count);");
            out.println('}');
            out.println('}');
            //main class
            out.println("public class Evaluation {");
            out.println(" public static void main(String args[]) {");
            out.println("int total_owner=" + total_owner + ";");
            // out.println("int x=0;");//for autoprogramming
            out.println("int x=" + x + ";");
           // out.println("System.out.println(\"Intermediate value=:\" + x);");//for first work
           // out.println("System.out.println(\"Result is:\" + x);");
            out.println("Owner1 obj[] = new Owner1[total_owner];");
            out.println("for (int i = 0; i < obj.length; i++) {");
            out.println("obj[i] = new Owner1();");
            out.println('}');
            for (int i = 0; i < equationlist.size(); i++) {
                out.println(equationlist.get(i));
            }
            for (int i = 0; i < total_owner; i++) {
                out.println("obj[" + i + "].setname(" + "\"" + obj[i].owner_name + "\"" + "," + "\"" + obj[i].variable_name + "\"" + "," + "\"" + obj[i].variable_attribute + "\"" + ");");
                // out.println("obj[" + i + "].setname(" + "\"" + obj[i].variable_name + "\"" + ");");
              //  out.println("obj[" + i + "].display();");
            }
            if (summing == true) {
                if (issumming == true) {
                    for (int i = 0; i < total_owner; i++) {
                        if (obj[i].variable_name == null || var == null || obj[i].variable_name.equals(var)) {
                          //  out.println("System.out.println(\"Heressss\");");

                            if ((obj[i].variable_attribute == null || obj[i].variable_attribute.equals("NULL") || atr == null || obj[i].variable_attribute.equals(atr))) {
                               // out.println("System.out.println(\"Here\");");
                                out.println("x=x+obj[" + i + "].variable_count;");
                                out.println("System.out.println(x);");
                            } else if (obj[i].owner_name.equals(this.owner_name) && this.owner_name != null && issinglesumming == false) {
                                //   out.println("System.out.println(\"Here2\");");
                                out.println("x=obj[" + i + "].variable_count;");
                                out.println("System.out.println(x);");
                            }
                        } else if (issinglesumming == true) {
                            // for (int j = 0; i < total_owner; i++) {
                            if (this.variable_attribute != null && obj[i].variable_attribute != null) {
                                if (obj[i].variable_attribute.equals(this.variable_attribute)) {

                                    attributematch = true;
                                }
                            }
                            if (this.variable_name != null && obj[i].variable_name != null) {
                                if (obj[i].variable_name.equals(this.variable_name)) {
                                    itemmatch = true;

                                }
                            }
                            if (attributematch == true && itemmatch == true) {
                                out.println("x=x+obj[" + i + "].variable_count;");
                                out.println("System.out.println(x);");
                            } else if ((this.variable_attribute == null || obj[i].variable_attribute == null) && itemmatch == true) {
                                out.println("x=x+obj[" + i + "].variable_count;");
                                out.println("System.out.println(x);");
                            } else if (attributematch == false && itemmatch == false) {
                                out.println("x=x+obj[" + i + "].variable_count;");
                                out.println("System.out.println(x);");
                            }
                            System.out.println("attributematch==" + attributematch + "  itemmatch==" + itemmatch);
                            attributematch = false;
                            itemmatch = false;

                        }
                    }

                    out.println("System.out.println(\"Total is\"+x+\" \" +obj[0].variable_attribute+\" \"+obj[0].variable_name);");
                }/* else if (issumming == false) {
                    out.println("System.out.println(\"Total is \"+obj[0].variable_count+\" \" +obj[0].variable_attribute+\" \"+obj[0].variable_name);");
                }*/ else if (issumming == false) {
                    if (issinglesumming == false) {
                        for (int i = 0; i < total_owner; i++) {
                            if (issummingowner.equalsIgnoreCase(obj[i].owner_name)) {
                                out.println("System.out.println(\"Total is \"+Math.abs(obj[" + i + "].variable_count)+\" \" +obj[" + i + "].variable_attribute+\" \"+obj[" + i + "].variable_name);");
                                done = true;
                                break;
                            }
                        }
                    } else if (issinglesumming = true) {
                        for (int i = 0; i < total_owner; i++) {
                            if (obj[i].variable_name == null || var == null || obj[i].variable_name.equals(var)) {
                                //  out.println("System.out.println(\"Heressss\");");

                                if ((obj[i].variable_attribute == null || obj[i].variable_attribute.equals("NULL") || atr.equals("null") || obj[i].variable_attribute.equals(atr))) {
                                    //  out.println("System.out.println(\"Here\");");
                                    out.println("x=x+obj[" + i + "].variable_count;");
                                    out.println("System.out.println(x);");
                                }
                            }

                        }
                        out.println("System.out.println(\"Total is\"+x+\" \" +obj[0].variable_attribute+\" \"+obj[0].variable_name);");
                    }

                }
                // out.println("System.out.println(\"Going out of summing\");");
            }
           // out.println("System.out.println(\"Going out of ##### summing\");");

            for (int i = 0; i < total_owner; i++) {

                if (obj[i].variable_name != null && obj[i].variable_attribute != null) {
                    if (obj[i].owner_name.equals(owner_name) && obj[i].variable_name.equals(variable_name) && obj[i].variable_attribute.equals(variable_attribute)) {
                        out.println("System.out.println(\"Final Result=:\" + Math.abs(obj[" + i + "].variable_count));");
                        out.println("obj[" + i + "].display();");
                        done = true;
                        break;
                    }
                }
            }
            // out.println("System.out.println(\" ##### for1\");");
            for (int i = 0; i < total_owner; i++) {
                if (obj[i].variable_name != null) {
                    if (obj[i].owner_name.equals(owner_name) && obj[i].variable_name.equals(variable_name) && (done == false) && issinglesumming == false) {
                        out.println("System.out.println(\"Final Result=:\" + obj[" + i + "].variable_count);");
                        out.println("obj[" + i + "].display();");
                        done = true;
                        break;
                    }
                }
            }
         //   out.println("System.out.println(\" ##### for1\");");
            for (int i = 0; i < total_owner; i++) {
             //   out.println("System.out.println(\"now in for 3\");");
                if (obj[i].variable_name != null) {

                    if (obj[i].owner_name.equals(owner_name) && (done == false) && issinglesumming == false) {
                        out.println("System.out.println(\"Final Result=:\" + Math.abs(obj[" + i + "].variable_count));");
                        out.println("obj[" + i + "].display();");
                        done = true;
                        break;

                    } else if (obj[i].variable_name.equals(variable_name) && (done == false) && issinglesumming == false) {
                        out.println("System.out.println(\"Final Result=:\" + Math.abs(obj[" + i + "].variable_count));");

                        out.println("obj[" + i + "].display();");
                        done = true;
                        break;

                    }
                }

            }
          //  out.println("System.out.println(\"end program\");");
            out.println('}');
            out.println('}');

            out.close();
           // System.out.println("done to create java prog");

        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        } finally {
            if (out != null) {
                out.close();
            }
            try {
                if (bw != null) {
                    bw.close();
                }
            } catch (IOException e) {
                //exception handling left as an exercise for the reader
            }
            try {
                if (fw != null) {
                    fw.close();
                }
            } catch (IOException e) {
                //exception handling left as an exercise for the reader
            }
        }
    }

    public void evaluate_result() throws IOException {

        TestScript testScript = new TestScript();
        testScript.runScript("/home/sourav/MyResearch/MathWordProbSolver/a.sh");
    }

    public int create_expression_node(ObjectItem var[]) throws Exception {

        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for creating of owner expression node ...");
        //Statement stmt = conn.createStatement();
        String previous_var_name = null;
        String previous_owner_name = null;
        String previous_var_atr = null;
        String var_name = null;
        String ownername = null;
        String var_atr = null;
        String lemma = null;
        int state = 0;
        int count = 0;

        String sql = "select distinct owner_name, variable_name, item_specific_attribute from owner";
        System.out.println(sql);
        int x = 0;
        PreparedStatement ps = conn.prepareStatement(sql);
        StringBuilder sb = new StringBuilder();
        StringBuilder sball = new StringBuilder();
        ExpNode e[] = new ExpNode[5];
        int countstates = 0;
        String op = null;
        try {
            ResultSet rs = ps.executeQuery();
            /*
            while (rs.next()) {
                ownername = rs.getString(1);
                var_name = rs.getString(2);
                var_atr = rs.getString(3);
                System.out.println("owner _name:**" + ownername);
                System.out.println("variable attribute:**" + var_atr);
                System.out.println("var_name:**" + var_name);
                String sql1 = null;
                PreparedStatement ps1 = null;
                if (var_atr != null && var_name != null) {
                    sql1 = "select state_no, variable_count, operator, verb_lemma from owner where owner_name=? and variable_name=? and item_specific_attribute=?";

                    ps1 = conn.prepareStatement(sql1);

                    ps1.setString(1, ownername);
                    ps1.setString(2, var_name);
                    ps1.setString(3, var_atr);

                } else if (var_atr != null && var_name == null) {
                    sql1 = "select state_no, variable_count, operator, verb_lemma from owner where owner_name=? and item_specific_attribute=?";

                    ps1 = conn.prepareStatement(sql1);

                    ps1.setString(1, ownername);
                    // ps1.setString(2, var_name);
                    ps1.setString(2, var_atr);

                } else if (var_name == null) {
                    sql1 = "select state_no, variable_count, operator , verb_lemmafrom owner where owner_name=? and variable_name is null";
                    ps1 = conn.prepareStatement(sql1);

                    ps1.setString(1, ownername);
                    // ps1.setString(2, var_name);
                } else {
                    sql1 = "select state_no, variable_count, operator, verb_lemma from owner where owner_name=? and variable_name=?";

                    ps1 = conn.prepareStatement(sql1);

                    ps1.setString(1, ownername);
                    ps1.setString(2, var_name);
                }
                System.out.println("SQL1 is:" + ps1.toString());
                ResultSet rs1 = ps1.executeQuery();
                int i = 0;
                countstates = 0;
                int countnulls = 0;
                int flag = 0;
                int A = 0;
                int B = 0;

                while (rs1.next()) {

                    System.out.println("i============>" + i);
                    state = rs1.getInt(1);
                    count = rs1.getInt(2);
                    lemma = rs1.getString(4);
                    //   operator = rs1.getString(3);
                    System.out.println("ownername=" + ownername + " count:" + count + " operator: " + rs1.getString(3) + " and verb lemma: " + lemma);
                    if (rs1.getString(3) == null) {
                        System.out.println("rs1.getString(3);==> is:" + rs1.getString(3));
                        flag = 1;
                        countnulls++;
                    }
                    if (flag == 1) {
                        e[i] = new ExpNode(state, count, "NULL", lemma);
                        // l.add(e[i]);
                        System.out.println("display operator" + e[i].operator);
                        e[i].display();

                    } else {
                        e[i] = new ExpNode(state, count, rs1.getString(3), lemma);
                        System.out.println("display operator" + e[i].operator);
                        // l.add(e[i]);
                        e[i].display();

                    }

                    i++;
                    flag = 0;

                }
                countstates = i;
                System.out.println("no of states are:" + countstates);
                System.out.println("no of null operators are:" + countnulls);
                
                System.out.println("sb is ####" + sb.toString());
                if (sb.toString().equals("x")) {
                    sb.deleteCharAt(0);
                }

                if (previous_var_name == null || previous_var_name.equals(var_name) || var_name == null || sball != null || summing == true || (previous_owner_name == null || previous_owner_name.equals(ownername) || var_name.equals(this.variable_name) || this.variable_name == null) || ownername.equals(this.owner_name) || this.owner_name == null) {
                    System.out.println("prev var==>" + previous_var_name + "present var:" + var_name);
                    System.out.println("prev own==>" + previous_owner_name + "present owner:" + ownername);
                    System.out.println("prev var atribute: " + previous_var_atr + "present attribute: " + var_atr);
                    if (previous_var_name != null && previous_owner_name != null) {
                        if (!previous_owner_name.trim().equalsIgnoreCase(ownername) && !previous_var_name.trim().equalsIgnoreCase(var_name) && var_name != null && !(var_name.equals(this.variable_name) || this.variable_name == null)) {

                            // int y= evaluate_X(sb.toString());
                            // System.out.println("Result is"+y);
                            System.out.println("sb is" + sb.toString());
                            if (sb.toString().contains("x")) {
                                sb.deleteCharAt(sb.length() - 1);
                            } else if (sb.length() > 0) {
                                int y = evaluate_X(sb.toString(), x);
                                System.out.println("Result is" + y);
                                sb.delete(0, sb.length() - 1);
                                sb.deleteCharAt(0);
                                update_item_val(previous_owner_name, previous_var_name, var_atr, y);
                            }
                            // System.out.println("sb all" + sball.toString());

                        } else if (previous_owner_name.equals(ownername) && !previous_var_name.equals(var_name) && var_name != null && (this.variable_name == null || var_name.equals(this.variable_name) || hasDoller == true)) {
                            String oper = null;
                            if (sb.toString().contains("x")) {
                                sb.deleteCharAt(sb.length() - 1);
                            }
                            oper = recognise_adverb_operation();
                            System.out.println("oper==?" + oper);
                            if (oper == null && countstates == 1) {
                                oper = find_operation();

                            }
                            if (oper == null) {
                                System.out.println("sb to delete" + sb.toString());
                                if (sb.length() > 0) {
                                    sb.delete(0, sb.length() - 1);
                                    sb.deleteCharAt(0);
                                }

                            }
                        } else if (!previous_owner_name.equals(ownername) && previous_var_name.equals(var_name) && var_name != null && (var_name.equals(this.variable_name) || this.variable_name == null)) {
                            if (sb.toString().contains("x")) {
                                sb.deleteCharAt(sb.length() - 1);
                            }
                            String oper = null;
                            oper = recognise_adverb_operation();
                            System.out.println("oper==?" + oper);
                            if (oper == null && (var_atr.equals("NULL") || var_atr.equals(previous_var_atr))) {
                                System.out.println("finding operation done by other");
                                oper = find_operation();//operation done by other user

                            }
                            if (oper == null) {
                                System.out.println("sb to delete" + sb.toString());
                                if (sb.length() > 0) {
                                    sb.delete(0, sb.length() - 1);
                                    sb.deleteCharAt(0);
                                }

                            }
                        } else if (previous_owner_name.equals(ownername) && previous_var_name.equals(var_name) && var_name != null && (var_name.equals(this.variable_name) || this.variable_name == null) && !var_atr.equals(previous_var_atr)) {
                            if (sb.toString().contains("x")) {
                                sb.deleteCharAt(sb.length() - 1);
                            }
                            String oper = null;
                            oper = recognise_adverb_operation();
                            System.out.println("oper==?" + oper);
                            if (oper == null && (var_atr.equals("NULL") || var_atr.equals(previous_var_atr))) {
                                System.out.println("finding operation done by other");
                                oper = find_operation();//operation done by other user

                            }
                            if (oper == null) {
                                System.out.println("sb to delete" + sb.toString());
                                if (sb.length() > 0) {
                                    sb.delete(0, sb.length() - 1);
                                    sb.deleteCharAt(0);
                                }

                            }
                        } else {
                            System.out.println("sb is::::" + sb.toString());
                            if(sb.toString().endsWith("NULL")){
                                sb.delete(sb.indexOf("NULL"), sb.length()-1);
                            }
                            if (sb.toString().contains("x")) {
                                sb.deleteCharAt(sb.length() - 1);
                            } else if (sb.length() > 0 && !var_name.equals("NULL") && var_name != null && (var_name.equals(this.variable_name) || this.variable_name == null)) {
                                int y = evaluate_X(sb.toString(), x);
                                System.out.println("Result is" + y + "  for " + this.owner_name + " and " + this.variable_name);
                                sb.delete(0, sb.length() - 1);
                                sb.deleteCharAt(0);
                            }

                        }
                    }

                    if (countnulls == countstates && (var_atr.equals("NULL") || var_name == null || var_atr.equals("null") || var_atr.equals(previous_var_atr) || previous_var_atr == null || this.variable_attribute == null || var_atr.equals(this.variable_attribute))) {
                        String AA = null;
                        System.out.println("All the operators are null, this owner equation is to be proceesed seperately");
                        //sb.append("0");

                        String opr = recognise_adverb_operation();
                        if (opr != null) {
                            System.out.println("adverbial operator is" + opr);
                            op = opr;
                        }
                        if (op == null) {
                            System.out.println("finding operation done by other");
                            op = find_operation();//operation done by other user

                        }
                        System.out.println("operation is :" + op);
                        //if no adverbs present in any of the sentences
                        //find other operators available in the other sentences and are releted or not the respective owner
                        for (i = 0; i < countstates; i++) {
                            int var_count = e[i].x;
                            lemma = e[i].verb_lemma;
                            // String op = e[i].operator;
                            System.out.println("i==" + i);
                            System.out.println("sb =====$$$$$=====>" + sb.toString());
                            if (sb.toString().contains("x")) {
                                sb.deleteCharAt(sb.length() - 1);
                            }
                            System.out.println("var_count:" + var_count);
                            if (var_count != 0 && hasPayment == true && hasDoller == true) {
                                A = var_count;
                                AA = Integer.toString(A);
                                System.out.println("A=" + A);
                                System.out.println("lemma======>" + lemma);

                                if (lemma.equals("purchase") || lemma.equals("buy") || lemma.equals("spend") || lemma.equals("cost")) {
                                    sb.append(AA).append(op);
                                }
                                // sball.append(AA).append(op);

                                System.out.println("sb is for no of states 1 and variable count 0:" + sb.toString());
                            } else if (hasDoller == false && var_count != 0 && (previous_var_name == null || previous_var_name.equals(var_name) || var_name.equals(this.variable_name) || this.variable_name == null)) {
                                A = var_count;
                                if (countstates == 3 && i == 0) {
                                    B = A;
                                }
                                AA = Integer.toString(A);
                                System.out.println("AA=" + AA);
                                System.out.println("op==" + op);
                                if (op != null) {
                                    System.out.println("sb is***" + sb.toString());
                                    sb.append(AA).append(op);
                                } else if (sb.length() > 0 && countstates != 3) {
                                    System.out.println("here" + sb.toString());
                                    sb.append(AA);
                                } else {
                                    if (op == null && summing == true && countstates == 3 && i == 0) {//q-61, 112 for DS2
                                        sb.append(AA);
                                    } else if (op == null && summing == true && A > B) {
                                        sb.append("-").append(AA);
                                    } else if (op == null && summing == true) {
                                        op = "+";
                                        sb.append(AA).append(op);
                                    } else if (op == null) {
                                        op = "-";
                                        sb.append(AA).append(op);
                                    }

                                    op = null;
                                }
                                System.out.println("sb for states 1 count 1 var_count not 0:" + sb.toString());
                            } else if (var_count != 0 && total_variable == 1 && hasDoller == false) {
                                A = var_count;
                                AA = Integer.toString(A);
                                sb.append(AA);
                            } else {
                                sb.append("x");
                            }
                        }
                        if (countstates == 1) {
                            if (op != null) {
                                sball = null;
                                //sball.delete(0, sb.length() - 1);
                                //sball.deleteCharAt(0);
                            } else {
                                // sb.delete(0, sb.length() - 1);
                                // sb.deleteCharAt(0);

                            }
                        } else if (sb.toString().endsWith("+") || sb.toString().endsWith("+") || sb.toString().endsWith("x")) {
                            sb.deleteCharAt(sb.length() - 1);
                        }
                    } else if ((var_atr.equals("NULL") || var_atr.equals(previous_var_atr) || previous_var_atr == null || this.variable_attribute == null || var_atr.equals(this.variable_attribute) || summing == true)) {
                        System.out.println("sb is%%%" + sb.toString());

                        for (i = 0; i < countstates; i++) {
                            if(sb.toString().equals("+")||sb.toString().equals("-")){
                                sb.deleteCharAt(0);
                            }
                            System.out.println("sb is@@@" + sb.toString());
                            int var_count = e[i].x;
                            lemma = e[i].verb_lemma;
                            op = e[i].operator;
                            System.out.println("i==" + i);
                            System.out.println("var_count:" + var_count);
                            System.out.println("operator:" + op);
                            if (countstates == 1) {

                                if (var_name == null || var_name.equals(this.variable_name) || this.variable_name == null) {
                                    String opr = recognise_adverb_operation();
                                    if (opr != null) {
                                        op = opr;
                                        System.out.println("adverbial operator is:" + op);
                                    }
                                }

                                if (op == null || op.equals("NULL")) {
                                    System.out.println("null operator");
                                    op = find_operation();//operation done by other user
                                    System.out.println("operator og other owner may affect is:" + op);

                                }

                                var_count = e[0].x;
                                System.out.println("haspayment=" + hasPayment + "has doller" + hasDoller);
                                System.out.println("var name length" + var_name.length() + " " + var_name);

                                if (var_name.equals("NULL") || var_name.equals(this.variable_name) || this.variable_name == null || ownername.equals(this.owner_name)) {
                                    if (var_count != 0 && hasPayment == true && hasDoller == true) {
                                        A = var_count;
                                        String AA = Integer.toString(A);
                                        System.out.println("A=" + A);
                                        System.out.println("lemma===here===>" + lemma);
                                        if (lemma.equals("purchase") || lemma.equals("buy") || lemma.equals("spend") || lemma.equals("cost") || lemma.equals("be")|| lemma.equals("pay")) {
                                            sb.append(AA).append(op);
                                        }

                                    } else if ((var_count != 0) && hasDoller == false) {
                                        System.out.println("here i am");
                                        System.out.println("var attribute=" + var_atr.toUpperCase());
                                        A = var_count;
                                        String AA = Integer.toString(A);
                                        System.out.println("A=" + A);
                                        if (var_atr.equals("null") || var_atr.equals(previous_var_atr) || previous_var_atr == null) {
                                            sb.append(AA).append(op);

                                            // sball.append(AA).append(op);
                                            System.out.println("sb is for no of states 1 and variable count 0:" + sb.toString());
                                        }
                                    } else {
                                        // sb.delete(0, sb.length() - 1);
                                        // sb.deleteCharAt(0);
                                        System.out.println("sb==>" + sb.toString());
                                        // System.out.println("X===>"+x);
                                        if (sb.toString().endsWith("+") || (sb.toString().endsWith("-"))) {
                                            String oper = recognise_adverb_operation();
                                            if (oper != null & var_count != 0) {
                                                A = var_count;
                                                String AA = Integer.toString(A);
                                                System.out.println("A=" + A);
                                                sb.append(AA).append(oper);
                                            } else {
                                                sb.append(x).append("x");
                                            }
                                        } else {
                                            String oper = recognise_adverb_operation();
                                            if (oper != null & var_count != 0) {
                                                A = var_count;
                                                String AA = Integer.toString(A);
                                                System.out.println("A=" + A);
                                                sb.append(AA).append(oper);
                                            } else {
                                                sb.append("x");
                                            }
                                        }
                                        System.out.println("sb is for no of states 1 and variable count 0 or not matching the variable:" + sb.toString());
                                    }
                                } else if (summing == true && hasDoller == true) {//q-123 of DS1
                                    if (sb.toString().equals("x")) {
                                        sb.deleteCharAt(0);
                                    }
                                    if (var_count != 0 && hasPayment == true) {
                                        A = var_count;
                                        String AA = Integer.toString(A);
                                        System.out.println("A=" + A);
                                        System.out.println("lemma======>" + lemma);
                                        if (lemma.equals("purchase") || lemma.equals("buy") || lemma.equals("spend") || lemma.equals("cost")) {
                                            sb.append(AA).append("+");
                                        }

                                    } else if (var_count != 0 && hasPayment == false) {
                                        A = var_count;
                                        String AA = Integer.toString(A);
                                        sb.append(AA).append("+");
                                    }
                                }

                            } else {
                                System.out.println("sb for countstates not equal 1:" + sb.toString());

                                if (op.equals("NULL")) {
                                    // countnulls++;
                                    if (var_count != 0) {
                                        if (sb.toString().startsWith("x")) {
                                            sb.deleteCharAt(0);
                                        }
                                        if (sb.toString().endsWith("x")) {
                                            sb.deleteCharAt(sb.toString().length() - 1);
                                        }
                                        A = var_count;
                                        String AA = Integer.toString(A);
                                        System.out.println("A=" + A);
                                        if (sb.toString().endsWith("+") || sb.toString().endsWith("-")) {
                                            sb.append(AA);
                                        } else if (sb.length() == 0) {
                                            sb.append(AA);
                                        } else if (sb.toString().contains("+")) {
                                            sb.append("+").append(AA);

                                        } else if (sb.toString().contains("-")) {
                                            sb.append("-").append(AA);
                                        } else {
                                            op = find_operation();
                                            sb.append(op).append(AA);
                                        }

                                    } else {
                                        sb.append("x");
                                    }

                                    System.out.println("sb for op null:" + sb.toString());

                                } else if (var_count != 0) {
                                    String op_opposite = null;
                                    String op_adverb = recognise_adverb_operation();
                                    A = var_count;
                                    String AA = Integer.toString(A);
                                    System.out.println("A is =" + A);
                                    System.out.println("NNNNNNN" + sb.toString());
                                    //if(sb.toString().endsWith(sql1))
                                    System.out.println("op adverb" + op_adverb);
                                    System.out.println("lemma==>" + lemma);
                                    if (op_adverb != null) {
                                        System.out.println("here inside");
                                        if (total_variable > 1) {
                                            if (!lemma.equals("miss")) {//q-74, 97, 101 of DS2
                                                sb.append(op).append(AA);
                                            }
                                        } else {
                                            // sb.append(AA).append(op_adverb);
                                            sb.append(op_adverb).append(AA);// q-83 of DS1
                                        }

                                    } else if (sb.toString().contains("x")) {
                                        if (sb.toString().endsWith("x")) {

                                            sb.deleteCharAt(sb.toString().length() - 1);
                                            //  System.out.println("NNNNNNN" + sb.toString());
                                            if (total_owner == 1 || !op.equals("NULL")) { //q113 of ds1
                                                System.out.println("within this condition");
                                                sb.append(op).append(AA);//q-100 of ds1

                                            } else if (op.equals("-")) {
                                                op_opposite = "+";
                                            } else if (op.equals("+")) {
                                                op_opposite = "-";
                                            } else if (total_variable > 1) {
                                                sb.append(op).append(AA);

                                            } else if (i == countstates - 1) {
                                                sb.append(op_opposite).append(AA);
                                            } else {
                                                sb.append(op_opposite).append(AA).append("x");
                                            }
                                            //sb.append(AA).append(op_opposite);

                                        } else if (sb.toString().startsWith("x")) {
                                            sb.deleteCharAt(0);
                                        }
                                    } else if (sb.toString().endsWith("+") || sb.toString().endsWith("-")) {
                                        //  String op_opposite = null;
                                        if (i != countstates - 1) {
                                            // sb.insert(0, 'x');
                                            if (op.equals("-")) {
                                                op_opposite = "+";
                                            }
                                            if (op.equals("+")) {
                                                op_opposite = "-";
                                            }
                                            if (sb.length() >= 2) {
                                                sb.append(AA).append(op);
                                            } else {
                                                sb.append(AA).append(op_opposite);
                                            }
                                        } else {
                                            sb.append(AA);
                                        }
                                    } else if (sb.length() == 0) {
                                        sb.append(AA).append("x");
                                    } else {

                                        sb.append(op).append(AA);
                                    }
                                } else if (var_count == 0) {
                                    String op_opposite = null;
                                    A = var_count;
                                    String AA = Integer.toString(A);
                                    if (i == 1 && countstates == 3 && op.equals("-")) {//q-1 in DS1 where middle val is unknown
                                        sb.append(op);
                                    } else if (i == 1 && countstates == 3 && op.equals("+")) {
                                        sb.append("-");//q-5 in DS1
                                    } else if (i == 1 && i < countstates - 1 && countstates != 3) {
                                        sb.append(op);
                                    } else if (i != countstates - 1 && !(sb.toString().endsWith("+") || sb.toString().endsWith("-"))) {
                                        // sb.insert(0, 'x');
                                        if (op.equals("-")) {
                                            op_opposite = "+";
                                        }
                                        if (op.equals("+")) {
                                            op_opposite = "-";
                                        }

                                        sb.append(op_opposite);

                                    } else if (!(sb.toString().endsWith("+") || sb.toString().endsWith("-"))) {
                                        if (sb.toString().contains("+")) {
                                            int q = sb.indexOf("+");
                                            System.out.println("q=" + q);
                                            sb.replace(q, q + 1, "-");
                                        }

                                    } else {
                                        sb.append(AA);
                                    }
                                } else if (A != 0) {
                                    sb.append(op);
                                } else if (x != 0) {
                                    sb.append(0).append(op).append(x);
                                } else {
                                    //  sb.append(0);
                                    System.out.println("equation can not be generated, required other owners");
                                }

                                System.out.println("equation string is:" + sb.toString() + "for the value of i is  " + i);

                            }
                        }
                    }

                    if (countstates != 1) {
                        String input = sb.toString();
                        x = evaluate_X(input, x);
                        // x = Math.abs(x);
                        System.out.println("value of x===>" + x);
                        System.out.println("done for the owner" + ownername);
                        sb.delete(0, sb.length() - 1);
                        sb.deleteCharAt(0);
                        System.out.println("sb after clear==>" + sb.toString());
                        update_item_val(ownername, var_name, var_atr, x);

                    }
                    System.out.println("Previous var name==>" + previous_var_name);
                    System.out.println("variable name==>" + var_name);

                    previous_var_name = var_name;
                    previous_owner_name = ownername;
                    previous_var_atr = var_atr;
                }
                System.out.println("present var name=" + previous_var_name);
                System.out.println("present owner name=" + previous_owner_name);
                System.out.println("present attribute=" + previous_var_atr);

            }*/

            sball = null;
        } catch (SQLException se) {
            System.out.println(se);

        } finally {
            DBconnect.closeConnection(conn);

        }
        /*
        System.out.println("sb is###%%%" + sb.toString());

        if (countstates == 1 && !e[0].operator.equals("NULL")) {
            if (sb.length() == 0) {
                System.out.println("sb is null");
                sb.append(count).append("x");

            }
            System.out.println("sb for countstates==1:" + sb.toString());
            if (sb.toString().endsWith("x") || sb.toString().endsWith("+") || sb.toString().endsWith("-")) {
                sb.deleteCharAt(sb.length() - 1);
            }
            if (sb.length() != 0) {
                String input = sb.toString();
                x = evaluate_X(input, x);
                update_item_val(ownername, var_name, var_atr, x);
                System.out.println("value of x===>" + x);
            }
        }
        if (countstates == 1 && e[0].operator.equals("NULL")) {
            if (sb.length() == 0) {
                System.out.println("sb is null");
                sb.append(count).append("x");

            }
            System.out.println("sb for countstates==1:" + sb.toString());
            System.out.println("length" + sb.length());
            if (sb.toString().endsWith("x") || sb.toString().endsWith("+") || sb.toString().endsWith("-")) {
                sb.deleteCharAt(sb.length() - 1);
            }
            String input = sb.toString();
            if (sb.toString().length() != 0) {
                x = evaluate_X(input, x);
                update_item_val(ownername, var_name, var_atr, x);
            }
            System.out.println("value of x===>" + x);
        }
         */
        //    System.out.println("return value of x is -->" + x);

        //   return x;
        return 0;

    }

    public int evaluate_X(String equationString, int x) throws ScriptException {
        ScriptEngineManager mgr = new ScriptEngineManager();
        ScriptEngine engine = mgr.getEngineByName("JavaScript");
        System.out.println("equation is" + equationString);
        // String foo = "40+2";
        if (equationString.endsWith("+") || equationString.endsWith("-")) {
            equationString = equationString.substring(0, equationString.length() - 1);
        }
        if (!equationString.equals("0")) {
            int res = (int) engine.eval(equationString);
            res = Math.abs(res);

            System.out.println("Result is---" + res);

            return res;
        } else {
            return x;
        }

    }

    public String recognise_adverb_operation() throws FileNotFoundException {
        String op = null;
        String q = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        if (q.contains("alltogether") || q.contains("together") || q.contains("overall") || q.contains("total") || q.contains("all")|| q.contains("in all") || q.contains("sum") || q.contains("more") || q.contains("longer") || q.contains("larger") || q.contains("taller") || q.contains("bigger")) {
            op = "+";
        } else if (q.contains("left") || q.contains("remain") || q.contains("difference") || q.contains("less")) {
            op = "-";
        } else if (q.contains("much") && q.contains("$")) {

            op = "+";

        }
        return op;
    }

    public String find_operation() throws Exception {
        Connection conn = DBconnect.getConnection();
        String op = null;
        System.out.println("Creating statement for finding opearation of other owner..");
        /// Statement stmt = conn.createStatement();
        String sql = "SELECT * FROM owner WHERE operator IS NOT NULL";
        // System.out.println(sql);
        PreparedStatement ps = conn.prepareStatement(sql);
        try {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int var = rs.getInt(8);

                System.out.println("op is &^%$$$$##" + op);
                if (var == 0 && op == null) {
                    op = rs.getString(5);
                    switch (op) {
                        case "-":
                            op = "+";
                            break;
                        case "+":
                            op = "-";
                            break;
                        case "null":
                            op = "+";
                            break;
                        default:
                            op = "+";
                            break;
                    }
                } else {
                    op = rs.getString(5);

                }
                System.out.println("op of others is" + op);

            }
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        return op;
    }

    public void update_item_val(String ownr, String var, String var_atr, int x) throws Exception {

        Connection conn = DBconnect.getConnection();
        System.out.println("Creating statement for updation of object item table...");
        System.out.println("summing:" + summing);
        PreparedStatement ps = null;
        String sql = null;
        System.out.println("variable is:" + var);
        //System.out.println("sabtracting:"+sabtracting);
        try {
            if (summing == false) {
                if (!var_atr.equals("null") && var != null) {
                    sql = "select * from objectitem where owner_name=? and variable_name=? and item_specific_attribute=?";
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    ps.setString(1, ownr);
                    ps.setString(2, var);
                    ps.setString(3, var_atr);
                    System.out.println("ps=>" + ps.toString());

                } else if (var != null) {
                    sql = "select * from objectitem where owner_name=? and variable_name=?";
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    ps.setString(1, ownr);
                    ps.setString(2, var);
                    System.out.println("ps=>" + ps.toString());
                } else {
                    sql = "select * from objectitem where owner_name=?";
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    ps.setString(1, ownr);
                    //  ps.setString(2, var);
                    System.out.println("ps=>" + ps.toString());

                }

                ResultSet rs = ps.executeQuery();
                System.out.println("Value is::" + x);

                while (rs.next()) {
                    if (!var_atr.equals("null") && var != null) {
                        sql = "UPDATE objectitem set variable_count= ? where owner_name= ? and variable_name= ? and item_specific_attribute=?";
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, x);
                        ps.setString(2, ownr);
                        ps.setString(3, var);
                        ps.setString(4, var_atr);
                        ps.executeUpdate();
                        if (ownr != null) {
                            sql = "UPDATE MWP set result= ? where owner_name= ? and variable_name= ?";
                            ps = conn.prepareStatement(sql);
                            ps.setInt(1, x);
                            ps.setString(2, ownr);
                            ps.setString(3, var);
                            ps.executeUpdate();
                        } else if (ownr == null) {
                            sql = "UPDATE MWP set result= ? where variable_name= ?";
                            ps = conn.prepareStatement(sql);
                            ps.setInt(1, x);
                            // ps.setString(2, ownr);
                            ps.setString(2, var);
                            ps.executeUpdate();

                        }

                    } else if (var == null) {
                        sql = "UPDATE objectitem set variable_count= ? where owner_name= ?";
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, x);
                        ps.setString(2, ownr);
                        // ps.setString(3, var);
                        ps.executeUpdate();

                        sql = "UPDATE MWP set result= ? where owner_name= ?";
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, x);
                        ps.setString(2, ownr);
                        //  ps.setString(3, var);
                        ps.executeUpdate();

                    } else {
                        sql = "UPDATE objectitem set variable_count= ? where owner_name= ? and variable_name= ?";
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, x);
                        ps.setString(2, ownr);
                        ps.setString(3, var);
                        ps.executeUpdate();
                        if (ownr != null) {
                            sql = "UPDATE MWP set result= ? where owner_name= ? and variable_name= ?";
                            ps = conn.prepareStatement(sql);
                            ps.setInt(1, x);
                            ps.setString(2, ownr);
                            ps.setString(3, var);
                            ps.executeUpdate();
                        } else if (ownr == null) {
                            sql = "UPDATE MWP set result= ? where variable_name= ?";
                            ps = conn.prepareStatement(sql);
                            ps.setInt(1, x);
                            // ps.setString(2, ownr);
                            ps.setString(2, var);
                            ps.executeUpdate();

                        }

                    }
                }
            } else {

                System.out.println("Value is==>" + x);

                sql = "UPDATE MWP set result= ? ";
                ps = conn.prepareStatement(sql);
                //ps = conn.prepareStatement(sql);
                ps.setInt(1, x);

                ps.executeUpdate();
                if (var == null) {
                    sql = "UPDATE objectitem set variable_count= ? where owner_name= ?";
                    // System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    ps.setInt(1, x);
                    ps.setString(2, ownr);
                    // ps.setString(3, var);
                    ps.executeUpdate();

                } else {
                    sql = "UPDATE objectitem set variable_count= ? where owner_name= ? and variable_name= ?";
                    // System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    ps.setInt(1, x);
                    ps.setString(2, ownr);
                    ps.setString(3, var);
                    ps.executeUpdate();

                }
                summing = false;
            }
        } // }
        catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void update_sent_owner() throws Exception {
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        int i = 0;
        try {
            sql = "select * from sentence where owner_name=\"any\" ";
            // System.out.println(sql);
            ps = conn.prepareStatement(sql);
            System.out.println("sql is" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                i = rs.getInt(1);
                System.out.println("i val====>0" + i);
                StringBuilder pipeline = new StringBuilder(rs.getString(12));
                System.out.println("pipeline=>" + pipeline);
                System.out.println("the table have null owner name ");
                // sql1 = "select * from sentence where owner_name!=\"any\"";
                sql1 = "select distinct owner_name from sentence where owner_name!=\"any\"";
                ps1 = conn.prepareStatement(sql1);
                ResultSet rs1 = ps1.executeQuery();
                while (rs1.next()) {

                    // String ow = rs1.getString(7);
                    String ow = rs1.getString(1);
                    String newpipeline = Pattern.compile("any").matcher(pipeline).replaceAll(ow);
                    System.out.println("new equation  :" + newpipeline);

                    // String newpipeline = pipeline.replace(0, 2, ow).toString();
                    sql = "UPDATE sentence SET owner_name = ? , pipeline_equation1 = ? where owner_name=\"any\" and sent_sl_no=" + i + "";
                    ps1 = conn.prepareStatement(sql);
                    ps1.setString(1, ow);
                    System.out.println(newpipeline + " to be put");
                    ps1.setString(2, newpipeline);
                    System.out.println("sql=" + ps1.toString());
                    ps1.executeUpdate();
                    System.out.println("update done for any");
                    sql = "UPDATE verbstable SET owner_name = ? where owner_name=\"any\"";
                    ps1 = conn.prepareStatement(sql);
                    ps1.setString(1, ow);
                    ps1.executeUpdate();
                    // break;
                }
            }

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
    }

    public void update_sent_var() throws Exception {
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        try {
            sql = "select * from sentence where variable_name is null ";
            // System.out.println(sql);
            ps = conn.prepareStatement(sql);
            System.out.println("sql is" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("the table have null variable name ");
                sql1 = "select * from sentence where variable_name is not null";
                ps1 = conn.prepareStatement(sql1);
                ResultSet rs1 = ps1.executeQuery();
                while (rs1.next()) {
                    String var = rs1.getString(9);
                    sql = "UPDATE sentence SET variable_name = ? where variable_name is null";
                    ps1 = conn.prepareStatement(sql);
                    ps1.setString(1, var);
                    ps1.executeUpdate();
                    break;
                }
            }

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
    }

    public String find_var_mwp() throws Exception {
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String v = null;
        String sql1 = null;
        try {
            sql = "select variable_name from sentence where verb_lemma=?";
            // System.out.println(sql);
            ps = conn.prepareStatement(sql);
            ps.setString(1, mwp_verb);
            System.out.println("sql is" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                v = rs.getString(1);
                System.out.println("the variable name " + v);

            }

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        return v;
    }

    public void update_var() throws Exception {
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        try {
            sql = "select * from sentence where variable_name is null";
            // System.out.println(sql);
            ps = conn.prepareStatement(sql);
            System.out.println("sql is:" + ps.toString());
            ResultSet rs = ps.executeQuery();
            String var = null;
            while (rs.next()) {
                String ownn = rs.getString(7);
                String v = rs.getString(6);
                System.out.println("the table have null variable name ");
                if (v.equals("give")) {
                    System.out.println("the variable name is needed to be updated");
                }
                sql1 = "select * from sentence where variable_name is not null and owner_name=? or second_owner=?";
                ps1 = conn.prepareStatement(sql1);
                ps1.setString(1, ownn);
                ps1.setString(2, ownn);
                // ps1.executeUpdate();
                System.out.println("sql is: " + ps1.toString());
                ResultSet rs1 = ps1.executeQuery();
                System.out.println("sql is: " + ps1.toString());
                while (rs1.next()) {
                    var = rs1.getString(9);
                    System.out.println("variables identified:" + var);
                    //transfer verbs
                    sql = "UPDATE sentence SET variable_name = ? where variable_name is null and owner_name=?";
                    ps1 = conn.prepareStatement(sql);
                    ps1.setString(1, var);
                    ps1.setString(2, ownn);
                    ps1.executeUpdate();
                    System.out.println("Updated variables with transfer verbs");
                    break;

                }
            }

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void update_sent_var_atr() throws Exception {
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        try {
            sql = "select * from sentence where item_specific_attribute=\"NULL\"";
            // System.out.println(sql);
            ps = conn.prepareStatement(sql);
            System.out.println("sql is" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("the table have null variable attribute name ");
                sql1 = "select * from sentence where item_specific_attribute!=\"NULL\"";
                ps1 = conn.prepareStatement(sql1);
                ResultSet rs1 = ps1.executeQuery();
                while (rs1.next()) {
                    String var_atr = rs1.getString(10);
                    System.out.println("var attribute=>" + var_atr);
                    sql = "UPDATE sentence SET item_specific_attribute = ? where item_specific_attribute=\"NULL\"";
                    ps1 = conn.prepareStatement(sql);
                    ps1.setString(1, var_atr);
                    ps1.executeUpdate();
                    break;
                }
            }

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
    }

    public void evaluateMulDiv() {
        System.out.println("For multiplication");
    }

    public void generate_result() throws FileNotFoundException, Exception {
        int caseoption = 0;
        String op = recognise_adverb_operation();
        boolean checkmissing = removeirrelevantsent.isnumberexist();
        System.out.println("op=>" + op);
        if (op != null) {
            if (hasDoller == true) {
                caseoption = 4;
                System.out.println("in case 4");
            } else {
                caseoption = 1;
                System.out.println("in case 1");
            }
        } else if (checkmissing == true) {
            System.out.println("&&&&&&here");
            if (hasDoller == true) {
                caseoption = 4;
                System.out.println("in case 4");
            } else {
                caseoption = 2;
                System.out.println("in case 2");
            }
        } else if (hasDoller == true) {
            caseoption = 4;
            System.out.println("in case 4");
        } else {
            caseoption = 3;
            System.out.println("in case 3");
        }

        switch (caseoption) {
            case 1:
                result_mod();
                break;
            case 2:
                result_missing();
                break;
            case 3:
                result_general();
                break;
            case 4:
                result_money();
                break;

        }
    }

    public void result_mod() throws Exception {
        //match attribute
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        int rowcount = 0;
        int resultval = 0;
        try {
            sql = "SELECT * FROM MWP";
            ps = conn.prepareStatement(sql);
           // System.out.println("sql is:" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String owner = rs.getString(4);
                String item = rs.getString(5);
                String attribute = rs.getString(6);
                String q_verb = rs.getString(7);
                System.out.println(owner);
                System.out.println(item);
                System.out.println(attribute);
                System.out.println(q_verb);
                if (attribute.equals("null")) {
                    attribute = null;
                }
                if (owner != null) {
                    if (owner.equals("they")) {
                        System.out.println("test");
                        owner = null;
                    }
                }

                System.out.println("test");
                if (attribute != null) {
                   // System.out.println("I am here");
                    System.out.println(attribute.toUpperCase());
                    if (q_verb.equals("be") && q_verb.equals("have")) {
                        sql1 = "SELECT variable_count FROM `owner` where item_specific_attribute=? ";
                        ps1 = conn.prepareStatement(sql1);
                        ps1.setString(1, attribute);

                    } else {
                        sql1 = "SELECT variable_count FROM `owner` where item_specific_attribute=? and verb_lemma=?";
                        ps1 = conn.prepareStatement(sql1);
                        ps1.setString(1, attribute);
                        ps1.setString(2, q_verb);
                    }
                    //ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        int count = rs1.getInt(1);
                        System.out.println(count);
                        resultval = resultval + count;

                    }
                    System.out.println("Result=" + resultval);
                    //   rs1.close();

                } else if (item != null) {
                    System.out.println("wihinhin this");
                    if (q_verb.equals("be") || q_verb.equals("attend")|| q_verb.equals("have")) {//55ds1
                        if (owner == null) {
                            sql1 = "SELECT distinct variable_count FROM `owner` where variable_name=? ";
                            ps1 = conn.prepareStatement(sql1);
                            ps1.setString(1, item);
                        } else {
                            sql1 = "SELECT distinct variable_count FROM `owner` where owner_name=? and variable_name=?";
                            ps1 = conn.prepareStatement(sql1);

                            ps1.setString(1, owner);
                            ps1.setString(2, item);
                            ResultSet rs1 = ps1.executeQuery();
                            System.out.println("sql:" + ps1.toString());
                            while (rs1.next()) {
                                rowcount++;
                            }

                            System.out.println("total rows are:" + rowcount);
                            if (rowcount == 1) {//56ds1
                                sql1 = "SELECT distinct variable_count, operator FROM `owner` where variable_name=?";
                                ps1 = conn.prepareStatement(sql1);
                                ps1.setString(1, item);
                                //  rs1 = ps1.executeQuery();
                                // System.out.println("sql:" + ps1.toString());
                            }

                        }

                    } else if (owner != null) {

                        sql1 = "SELECT variable_count FROM `owner` where owner_name=? and variable_name=? and verb_lemma=?";
                        ps1 = conn.prepareStatement(sql1);
                        ps1.setString(1, owner);
                        ps1.setString(2, item);
                        ps1.setString(3, q_verb);

                        //ps1.executeQuery();
                        // rs1 = ps1.executeQuery();
                    } else if (owner == null) {
                        sql1 = "SELECT distinct variable_count FROM `owner` where variable_name=? and verb_lemma=?";
                        ps1 = conn.prepareStatement(sql1);

                        ps1.setString(1, item);
                        ps1.setString(2, q_verb);

                    }
                    // ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        int count = rs1.getInt(1);
                        resultval = resultval + count;
                    }
                    System.out.println("Result=" + resultval);

                }

            }
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/answer.txt"); //Your file
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream psr = new PrintStream(fos);
        System.setOut(psr);
        System.out.println(resultval);
    }

    public void result_general() throws Exception {
        //match attribute
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        int resultval = 0;
        int loop = 0;
        try {
            sql = "SELECT * FROM MWP";
            ps = conn.prepareStatement(sql);
            System.out.println("sql is:" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String owner = rs.getString(4);
                String item = rs.getString(5);
                String attribute = rs.getString(6);
                String q_verb = rs.getString(7);
                System.out.println(owner);
                System.out.println(item);
                System.out.println(attribute);
                System.out.println(q_verb);
                if (attribute.equals("null")) {
                    attribute = null;
                }
                if (owner != null) {
                    if (owner.equals("they")) {
                        System.out.println("test");
                        owner = null;
                    }
                }

                // System.out.println("test");
                if (item != null && attribute != null && owner != null) {
                    System.out.println("wihinhin all");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=? and variable_name=? and item_specific_attribute=? ";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    ps1.setString(2, item);
                    ps1.setString(3, attribute);
                    //  ps1.setString(3, q_verb);
                    // ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        loop++;
                        int count = rs1.getInt(1);
                        String op = rs1.getString(2);

                        if (op == null && loop == 1) {
                            resultval = count;
                        } else if (op.equals("+")) {
                            resultval = resultval + count;
                        } else if (op.equals("-")) {
                            resultval = resultval - count;
                        }
                    }
                    System.out.println("Result=" + abs(resultval));

                } else if (item != null && owner != null) {
                    System.out.println("wihinhin item owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=? and variable_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    ps1.setString(2, item);
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        loop++;
                        int count = rs1.getInt(1);
                        String op = rs1.getString(2);
                        if (op == null && loop == 1) {
                            resultval = count;
                        } else if (op.equals("+")) {
                            resultval = resultval + count;
                        } else if (op.equals("-")) {
                            resultval = resultval - count;
                        }

                    }
                    if (loop == 1) {
                        resultval = 0;
                        loop = 0;
                        sql1 = "SELECT distinct variable_count, operator FROM `owner` where variable_name=?";
                        ps1 = conn.prepareStatement(sql1);
                        // ps1.setString(1, owner);
                        ps1.setString(1, item);
                        //ps.executeQuery();
                        System.out.println("sql:" + ps1.toString());
                        rs1 = ps1.executeQuery();
                        while (rs1.next()) {
                            loop++;
                            int count = rs1.getInt(1);
                            String op = rs1.getString(2);
                            System.out.println("count=" + count);
                            System.out.println("op=" + op);
                            if (op == null && loop == 1) {
                                resultval = count;
                            } else if (op.equals("+")) {
                                resultval = resultval + count;
                                // System.out.println("res intermediate="+resultval);
                            } else if (op.equals("-")) {
                                resultval = resultval - count;
                                // System.out.println("res intermediate="+resultval);
                            }
                            System.out.println(resultval);
                        }

                    }
                    System.out.println("Result=" + resultval);
                } else if (attribute != null && owner != null) {
                    System.out.println("wihinhin item atrribute");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=? and item_specific_attribute=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    ps1.setString(2, attribute);
                    //ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        loop++;
                        int count = rs1.getInt(1);
                        String op = rs1.getString(2);
                        if (op == null && loop == 1) {
                            resultval = count;
                        } else if (op.equals("+")) {
                            resultval = resultval + count;
                        } else if (op.equals("-")) {
                            resultval = resultval - count;
                        }
                    }
                    System.out.println("Result=" + resultval);
                } else if (item != null && attribute != null) {
                    System.out.println("wihinhin item owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where item_specific_attribute=? and variable_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, attribute);
                    ps1.setString(2, item);
                    //ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        loop++;
                        int count = rs1.getInt(1);
                        String op = rs1.getString(2);
                        System.out.println("count=" + count);
                        System.out.println("op=" + op);
                        if (op == null && loop == 1) {
                            resultval = count;
                        } else if (op.equals("+")) {
                            resultval = resultval + count;
                        } else if (op.equals("-")) {
                            resultval = resultval - count;
                        }
                    }
                    System.out.println("Result=" + resultval);
                } else if (item != null) {
                    System.out.println("wihinhin item owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where variable_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    // ps1.setString(1, owner);
                    ps1.setString(1, item);

                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        loop++;
                        int count = rs1.getInt(1);
                        String op = rs1.getString(2);
                        System.out.println("count=" + count);
                        System.out.println("op=" + op);
                        if (op == null && loop == 1) {
                            resultval = count;
                        } else if (op != null && loop == 1) {//111ds1
                            resultval = count;
                        } else if (op.equals("+")) {
                            resultval = resultval + count;
                        } else if (op.equals("-")) {
                            resultval = resultval - count;
                        }
                    }
                    System.out.println("Result=" + abs(resultval));
                } else if (attribute != null) {
                    System.out.println("wihinhin item owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where item_specific_attribute=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, attribute);

                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        loop++;
                        int count = rs1.getInt(1);
                        String op = rs1.getString(2);
                        if (op == null && loop == 1) {
                            resultval = count;
                        } else if (op.equals("+")) {
                            resultval = resultval + count;
                        } else if (op.equals("-")) {
                            resultval = resultval - count;
                        }
                    }
                    System.out.println("Result=" + abs(resultval));
                } else if (owner != null) {
                    System.out.println("wihinhin item owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    // ps1.setString(2, item);
                    // ps1.setString(3, attribute);
                    //  ps1.setString(3, q_verb);
                    // ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        loop++;
                        int count = rs1.getInt(1);
                        String op = rs1.getString(2);
                        if (op == null && loop == 1) {
                            resultval = count;
                        } else if (op.equals("+")) {
                            resultval = resultval + count;
                        } else if (op.equals("-")) {
                            resultval = resultval - count;
                        }
                    }
                    System.out.println("Result=" + resultval);
                }

            }
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/answer.txt"); //Your file
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream psr = new PrintStream(fos);
        System.setOut(psr);
        System.out.println(resultval);
    }

    public void result_missing() throws Exception {
        //match attribute
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        int resultval = 0;
        int pos = -1;
        int locx = 0;
        String op = null;
        int count = 0;
        int rowcount = 0;
        int A = 0, B = 0, C = 0;
        //int loop = 0;
        int flag = 0;
        try {
            sql = "SELECT * FROM MWP";
            ps = conn.prepareStatement(sql);
            System.out.println("sql is:" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String owner = rs.getString(4);
                String item = rs.getString(5);
                String attribute = rs.getString(6);
                String q_verb = rs.getString(7);
                System.out.println(owner);
                System.out.println(item);
                System.out.println(attribute);
                System.out.println(q_verb);
                if (attribute.equals("null")) {
                    attribute = null;
                }
                if (owner != null) {
                    if (owner.equals("they")) {
                        System.out.println("test");
                        owner = null;
                    }
                }

                // System.out.println("test");
                if (item != null && attribute != null && owner != null) {
                    System.out.println("wihinhin all");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=? and variable_name=? and item_specific_attribute=? ";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    ps1.setString(2, item);
                    ps1.setString(3, attribute);
                    //  ps1.setString(3, q_verb);
                    ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        System.out.println("count=" + count);
                        if (count == 0 && flag == 0) {
                            System.out.println("here");
                            op = rs1.getString(2);
                            System.out.println("op=" + op);
                            if (op != null) {
                                flag = 1;
                            }
                        } else if (A == 0) {
                            A = count;
                            System.out.println("A=" + A);
                        } else {
                            B = count;
                            System.out.println("B=" + B);
                        }

                    }
                    if (op != null) {
                        if (op.equals("+")) {
                            if (A > B) {
                                resultval = A + B;
                            } else {
                                resultval = B - A;
                            }
                        } else if (op.equals("-")) {
                            if (A > B) {
                                resultval = A - B;
                            } else {
                                resultval = A + B;
                            }
                        }
                    } else if (A > B) {
                        resultval = A + B;
                    } else {
                        resultval = B - A;
                    }
                    System.out.println("Result=" + abs(resultval));

                } else if (item != null && owner != null) {
                    System.out.println("wihinhin item --owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=? and variable_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    ps1.setString(2, item);
                    ResultSet rs1 = ps1.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    while (rs1.next()) {
                        rowcount++;
                    }

                    System.out.println("total rows are:" + rowcount);
                    if (rowcount == 1) {
                        sql1 = "SELECT distinct variable_count, operator FROM `owner` where variable_name=?";
                        ps1 = conn.prepareStatement(sql1);
                        ps1.setString(1, item);
                        rs1 = ps1.executeQuery();
                        System.out.println("sql:" + ps1.toString());
                    }
                    //ps1.executeQuery();
                    rs1 = ps1.executeQuery();
                    //System.out.println("MMMMM");
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        System.out.println("count=" + count);
                        System.out.println("position=" + pos);
                        if (count == 0) {
                            pos++;
                            System.out.println("missing position=" + pos);
                            locx = pos;
                            if (flag == 0) {
                                System.out.println("here count 0");
                                op = rs1.getString(2);
                                System.out.println("op=" + op);
                                if (op != null) {
                                    flag = 1;
                                }
                            }
                            /*
                            if (A == 0) {
                                A = count;
                                System.out.println("A=" + A);
                            } else if (B == 0) {
                                B = count;
                                System.out.println("B=" + B);
                            } else if (C == 0) {
                                C = count;
                                System.out.println("C=" + C);
                            }*/
                        } else if (count != 0) {
                            pos++;
                            if (flag == 0) {
                                System.out.println("here");
                                op = rs1.getString(2);
                                System.out.println("op=" + op);
                                if (op != null) {
                                    flag = 1;
                                }
                            }
                            if (A == 0) {
                                A = count;
                                System.out.println("A=" + A);
                            } else if (B == 0) {
                                B = count;
                                System.out.println("B=" + B);
                            } else if (C == 0) {
                                C = count;
                                System.out.println("C=" + C);
                            }
                        }
                    }
                    System.out.println("final position of missing: " + locx);
                    if (C == 0) {
                        if (op != null) {
                            if (op.equals("+")) {
                                if (A > B) {
                                    resultval = A + B;
                                } else {
                                    resultval = B - A;
                                }
                            } else if (op.equals("-")) {
                                if (A > B) {
                                    if (locx == 0) {
                                        resultval = A + B;//12ds1
                                    } else if (locx >= 1) {
                                        resultval = A - B;//59ds1 but problem in 120ds1 for this
                                    }
                                } else {
                                    resultval = A - B;
                                }
                            }
                        } else if (A > B) {
                            resultval = A + B;
                        } else {
                            resultval = B - A;
                        }
                    }
                    if (C != 0) {
                        resultval = A + B + C;
                    }

                    System.out.println("Result=" + resultval);

                } else if (attribute != null && owner != null) {
                    System.out.println("wihinhin item dfgdgdf owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=? and item_specific_attribute=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    ps1.setString(2, attribute);
                    ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        System.out.println("count=" + count);
                        if (count == 0 && flag == 0) {
                            System.out.println("here");
                            op = rs1.getString(2);
                            System.out.println("op=" + op);
                            if (op != null) {
                                flag = 1;
                            }
                        } else if (A == 0) {
                            A = count;
                            System.out.println("A=" + A);
                        } else {
                            B = count;
                            System.out.println("B=" + B);
                        }

                    }
                    if (op != null) {
                        if (op.equals("+")) {
                            if (A > B) {
                                resultval = A + B;
                            } else {
                                resultval = B - A;
                            }
                        } else if (op.equals("-")) {
                            if (A > B) {
                                resultval = A - B;
                            } else {
                                resultval = A + B;
                            }
                        }
                    }
                    System.out.println("Result=" + resultval);
                } else if (item != null && attribute != null) {
                    System.out.println("wihinhin itemxvcxvcx owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where item_specific_attribute=? and variable_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, attribute);
                    ps1.setString(2, item);
                    ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        System.out.println("count=" + count);
                        if (count == 0 && flag == 0) {
                            System.out.println("here");
                            op = rs1.getString(2);
                            System.out.println("op=" + op);
                            if (op != null) {
                                flag = 1;
                            }
                        } else if (A == 0) {
                            A = count;
                            System.out.println("A=" + A);
                        } else {
                            B = count;
                            System.out.println("B=" + B);
                        }

                    }
                    if (op != null) {
                        if (op.equals("+")) {
                            if (A > B) {
                                resultval = A + B;
                            } else {
                                resultval = B - A;
                            }
                        } else if (op.equals("-")) {
                            if (A > B) {
                                resultval = A - B;
                            } else {
                                resultval = A + B;
                            }
                        }
                    }

                    System.out.println("Result=" + resultval);
                } else if (item != null) {
                    System.out.println("wihinhin item vxcvxssowner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where variable_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, item);
                    ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        String opr = rs1.getString(2);
                        System.out.println("count=" + count);
                        System.out.println("op=" + opr);
                        if (count == 0 && flag == 0) {
                            System.out.println("here");
                            // op = rs1.getString(2);

                            if (opr != null) {
                                op = opr;
                                flag = 1;
                            }
                        } else if (A == 0) {
                            A = count;
                            System.out.println("A=" + A);
                        } else {

                            B = count;
                            System.out.println("B=" + B);
                            System.out.println("flag=" + flag);
                            if (count != 0 && flag == 1) {//4ds1
                                op = opr;
                            }
                            System.out.println("final op=" + op);
                        }
                    }

                    if (op != null) {
                        if (op.equals("+")) {
                            if (A > B) {
                                resultval = A + B;
                            } else {
                                resultval = B - A;
                            }
                        } else if (op.equals("-")) {
                            if (A > B) {
                                resultval = A - B;
                            } else {
                                resultval = A + B;
                            }
                        }
                    }

                    System.out.println("Result=" + abs(resultval));
                } else if (attribute != null) {
                    System.out.println("wihinhin item qqqq owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where item_specific_attribute=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, attribute);
                    // ps1.setString(2, item);
                    // ps1.setString(3, attribute);
                    //  ps1.setString(3, q_verb);
                    ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        System.out.println("count=" + count);
                        if (count == 0 && flag == 0) {
                            System.out.println("here");
                            op = rs1.getString(2);
                            System.out.println("op=" + op);
                            if (op != null) {
                                flag = 1;
                            }
                        } else if (A == 0) {
                            A = count;
                            System.out.println("A=" + A);
                        } else {
                            B = count;
                            System.out.println("B=" + B);
                        }

                    }
                    if (op != null) {
                        if (op.equals("+")) {
                            if (A > B) {
                                resultval = A + B;
                            } else {
                                resultval = B - A;
                            }
                        } else if (op.equals("-")) {
                            if (A > B) {
                                resultval = A - B;
                            } else {
                                resultval = A + B;
                            }
                        }
                    }
                    System.out.println("Result=" + abs(resultval));
                } else if (owner != null) {
                    System.out.println("wihinhin item aaa owner");
                    sql1 = "SELECT distinct variable_count, operator FROM `owner` where owner_name=?";
                    ps1 = conn.prepareStatement(sql1);
                    ps1.setString(1, owner);
                    // ps1.setString(2, item);
                    // ps1.setString(3, attribute);
                    //  ps1.setString(3, q_verb);
                    ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        System.out.println("count=" + count);
                        if (count == 0 && flag == 0) {
                            System.out.println("here");
                            op = rs1.getString(2);
                            System.out.println("op=" + op);
                            if (op != null) {
                                flag = 1;
                            }
                        } else if (A == 0) {
                            A = count;
                            System.out.println("A=" + A);
                        } else {
                            B = count;
                            System.out.println("B=" + B);
                        }

                    }
                    if (op != null) {
                        if (op.equals("+")) {
                            if (A > B) {
                                resultval = A + B;
                            } else {
                                resultval = B - A;
                            }
                        } else if (op.equals("-")) {
                            if (A > B) {
                                resultval = A - B;
                            } else {
                                resultval = A + B;
                            }
                        }
                    } else if (A > B) {
                        resultval = A + B;
                    } else {
                        resultval = B - A;
                    }
                    System.out.println("Result=" + resultval);
                }

            }
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/answer.txt"); //Your file
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream psr = new PrintStream(fos);
        System.setOut(psr);
        System.out.println(resultval);
    }

    public void result_money() throws Exception {
        //match attribute
        Connection conn = DBconnect.getConnection();
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        String sql = null;
        String sql1 = null;
        int resultval = 0;
        String op = null;
        int count = 0;
        //int A = 0, B = 0, X = 0;
        //int loop = 0;
        int flag = 0;
        try {
            sql = "SELECT * FROM MWP";
            ps = conn.prepareStatement(sql);
            System.out.println("sql is:" + ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String owner = rs.getString(4);
                String item = rs.getString(5);
                String attribute = rs.getString(6);
                String q_verb = rs.getString(7);
                System.out.println(owner);
                System.out.println(item);
                System.out.println(attribute);
                System.out.println(q_verb);
                if (attribute.equals("null")) {
                    attribute = null;
                }
                if (owner != null) {
                    if (owner.equals("they")) {
                        System.out.println("test");
                        owner = null;
                    }
                }

                // System.out.println("test");
                if (q_verb != null) {
                    System.out.println("wihinhin money all");
                    sql1 = "SELECT variable_count, verb_lemma, operator FROM `owner` where verb_lemma=\"be\" or verb_lemma=\"buy\" or verb_lemma=\"spend\" or verb_lemma=\"purchase\" or verb_lemma=\"pay\" or verb_lemma=\"cost\" or verb_lemma=\"get\" or verb_lemma=\"have\"";
                    ps1 = conn.prepareStatement(sql1);
                    ps.executeQuery();
                    System.out.println("sql:" + ps1.toString());
                    ResultSet rs1 = ps1.executeQuery();
                    while (rs1.next()) {
                        count = rs1.getInt(1);
                        System.out.println(count);
                        resultval = resultval + count;

                    }

                    System.out.println("Result=" + abs(resultval));

                }

            }
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/answer.txt"); //Your file
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream psr = new PrintStream(fos);
        System.setOut(psr);
        System.out.println(resultval);
    }

    public void createJavaProgramall(Owner obj[]) throws Exception {

        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter out = null;
        boolean done = false;
        boolean attributematch = false;
        boolean itemmatch = false;
        try {
            String atr = null;
            String var = this.variable_name;
            atr = this.variable_attribute;
            isAddAll();
            System.out.println("variable=" + var);
            System.out.println("attribute==" + atr);
            fw = new FileWriter("/home/sourav/MyResearch/MathWordProbSolver/Evaluation.java");
            bw = new BufferedWriter(fw);
            out = new PrintWriter(bw);
            //class template
            out.println("import java.lang.Math;");
            out.println("class Owner1 {");
            out.println("public String owner_name;");
            out.println("public String variable_name;");
            out.println("public String variable_attribute;");
            out.println("public int variable_count = 0;");
            out.println("public void setname(String name, String var, String atr) {");
            out.println("owner_name = name;");
            out.println("variable_name = var;");
            out.println("variable_attribute = atr;");
            out.println('}');
            out.println(" public void display() {");
            out.println("System.out.println(\"Owner is:\" + owner_name);");
            out.println("System.out.println(\"Variable is:\" + variable_name);");
            out.println("System.out.println(\"Variable attribute is:\" + variable_attribute);");
            out.println("System.out.println(\"Count:\" + variable_count);");
            out.println('}');
            out.println('}');
            //main class
            out.println("public class Evaluation {");
            out.println(" public static void main(String args[]) {");
            out.println("int total_owner=" + total_owner + ";");
            out.println("int x=0;");//for autoprogramming
            // out.println("int x=" + x + ";");
         //   out.println("System.out.println(\"Intermediate value=:\" + x);");//for first work
          //  out.println("System.out.println(\"Result is:\" + x);");
            out.println("Owner1 obj[] = new Owner1[total_owner];");
            out.println("for (int i = 0; i < obj.length; i++) {");
            out.println("obj[i] = new Owner1();");
            out.println('}');
            for (int i = 0; i < equationlist.size(); i++) {
                out.println(equationlist.get(i));
            }
            int caseoption = 0;
            String op = recognise_adverb_operation();
            boolean checkmissing = removeirrelevantsent.isnumberexist();
            System.out.println("op=>" + op);
            if (op != null) {
                if (hasDoller == true) {
                    caseoption = 4;
                    System.out.println("in case 4");
                } else {
                    caseoption = 1;
                    System.out.println("in case 1");
                }
            } else if (checkmissing == true) {
                System.out.println("&&&&&&here");
                if (hasDoller == true) {
                    caseoption = 4;
                    System.out.println("in case 4");
                } else {
                    caseoption = 2;
                    System.out.println("in case 2");
                }
            } else if (hasDoller == true) {
                caseoption = 4;
                System.out.println("in case 4");
            } else {
                caseoption = 3;
                System.out.println("in case 3");
            }

            switch (caseoption) {
                case 1:
                    out.println(" result_mod(obj);");
                    //result_mod();
                    break;
                case 2:
                    out.println(" result_missing(obj);");
                    break;
                case 3:
                    out.println(" result_general(obj);");
                    break;
                case 4:
                    out.println(" result_money(obj);");
                    // result_money();
                    break;

            }

            for (int i = 0; i < total_owner; i++) {
                out.println("obj[" + i + "].setname(" + "\"" + obj[i].owner_name + "\"" + "," + "\"" + obj[i].variable_name + "\"" + "," + "\"" + obj[i].variable_attribute + "\"" + ");");
                // out.println("obj[" + i + "].setname(" + "\"" + obj[i].variable_name + "\"" + ");");
                out.println("obj[" + i + "].display();");
            }

            out.println("System.out.println(\"end main program\");");
            out.println('}');//end main method 

            //category 1 for adverbial modifier--case 1
            if (caseoption == 1) {
                out.println(" public static void result_mod(Owner1 obj[]) {");
                out.println("int x=0;");
                if (summing == true) {
                    if (issumming == true) {
                        for (int i = 0; i < total_owner; i++) {
                            if (obj[i].variable_name == null || var == null || obj[i].variable_name.equals(var)) {
                                // out.println("System.out.println(\"Here3ssss\");");

                                if ((obj[i].variable_attribute == null || obj[i].variable_attribute.equals("NULL") || atr == null || atr.equalsIgnoreCase("null") || obj[i].variable_attribute.equals(atr))) {

                                    //  out.println("System.out.println(\"Here\");");
                                    out.println("x=x+obj[" + i + "].variable_count;");
                                    out.println("System.out.println(x);");
                                } else if (obj[i].owner_name.equals(this.owner_name) && this.owner_name != null && issinglesumming == false) {
                                    //   out.println("System.out.println(\"Here2\");");
                                    out.println("x=obj[" + i + "].variable_count;");
                                    out.println("System.out.println(x);");
                                }
                            } else if (issinglesumming == true) {
                                // for (int j = 0; i < total_owner; i++) {
                                if (this.variable_attribute != null && obj[i].variable_attribute != null) {
                                    if (obj[i].variable_attribute.equals(this.variable_attribute)) {

                                        attributematch = true;
                                    }
                                }
                                if (this.variable_name != null && obj[i].variable_name != null) {
                                    if (obj[i].variable_name.equals(this.variable_name)) {
                                        itemmatch = true;

                                    }
                                }
                                if (attributematch == true && itemmatch == true) {
                                    out.println("x=x+obj[" + i + "].variable_count;");
                                    out.println("System.out.println(x);");
                                } else if ((this.variable_attribute == null || obj[i].variable_attribute == null) && itemmatch == true) {
                                    out.println("x=x+obj[" + i + "].variable_count;");
                                    out.println("System.out.println(x);");
                                } else if (attributematch == false && itemmatch == false) {
                                    out.println("x=x+obj[" + i + "].variable_count;");
                                    out.println("System.out.println(x);");
                                }
                                System.out.println("attributematch==" + attributematch + "  itemmatch==" + itemmatch);
                                attributematch = false;
                                itemmatch = false;

                            }
                        }

                        out.println("System.out.println(\"Total is: \"+x+\" \" +obj[" + 0 + "].variable_attribute+\" \"+obj[" + 0 + "].variable_name);");
                    } else if (issumming == false) {
                        if (issinglesumming == false) {
                            for (int i = 0; i < total_owner; i++) {
                                if (issummingowner.equalsIgnoreCase(obj[i].owner_name)) {
                                    out.println("System.out.println(\"Total is \"+Math.abs(obj[" + i + "].variable_count)+\" \" +obj[" + i + "].variable_attribute+\" \"+obj[" + i + "].variable_name);");
                                    done = true;
                                    break;
                                }
                            }
                        } else if (issinglesumming = true) {
                            for (int i = 0; i < total_owner; i++) {
                                if (obj[i].variable_name == null || var == null || obj[i].variable_name.equals(var)) {
                                    //  out.println("System.out.println(\"Heressss\");");

                                    if ((obj[i].variable_attribute == null || obj[i].variable_attribute.equals("NULL") || atr.equals("null") || obj[i].variable_attribute.equals(atr))) {
                                        //  out.println("System.out.println(\"Here\");");
                                        out.println("x=x+obj[" + i + "].variable_count;");
                                        out.println("System.out.println(x);");
                                    }
                                }

                            }
                            out.println("System.out.println(\"Total is: \"+x+\" \" +obj[" + 0 + "].variable_attribute+\" \"+obj[" + 0 + "].variable_name);");
                        }

                    }
                    // out.println("System.out.println(\"Going out of summing\");");
                }
                out.println('}');//end case 1
            }

            //category 3 Simple type- case--3
            if (caseoption == 3) {
                out.println(" public static void result_general(Owner1 obj[]) {");
                out.println("int x=0;");

                for (int i = 0; i < total_owner; i++) {

                    if (obj[i].variable_name != null && obj[i].variable_attribute != null) {
                        if (obj[i].owner_name.equals(owner_name) && obj[i].variable_name.equals(variable_name) && obj[i].variable_attribute.equals(variable_attribute)) {
                            out.println("System.out.println(\"Final Result=:\" + Math.abs(obj[" + i + "].variable_count));");
                            out.println("obj[" + i + "].display();");
                            done = true;
                            break;
                        }
                    }
                }
                // out.println("System.out.println(\" ##### for1\");");
                for (int i = 0; i < total_owner; i++) {
                    if (obj[i].variable_name != null) {
                        if (obj[i].owner_name.equals(owner_name) && obj[i].variable_name.equals(variable_name) && (done == false) && issinglesumming == false) {
                            out.println("System.out.println(\"Final Result=:\" + obj[" + i + "].variable_count);");
                            out.println("obj[" + i + "].display();");
                            done = true;
                            break;
                        }
                    }
                }
              //  out.println("System.out.println(\" ##### for1\");");
                for (int i = 0; i < total_owner; i++) {
                 //   out.println("System.out.println(\"now in for 3\");");
                    if (obj[i].variable_name != null) {

                        if (obj[i].owner_name.equals(owner_name) && (done == false) && issinglesumming == false) {
                            out.println("System.out.println(\"Final Result=:\" + Math.abs(obj[" + i + "].variable_count));");
                            out.println("obj[" + i + "].display();");
                            done = true;
                            break;

                        } else if (obj[i].variable_name.equals(variable_name) && (done == false) && issinglesumming == false) {
                            out.println("System.out.println(\"Final Result=:\" + Math.abs(obj[" + i + "].variable_count));");

                            out.println("obj[" + i + "].display();");
                            done = true;
                            break;

                        }
                    }
                }
                out.println('}');//end case3

            }//case mony problem
            if (caseoption == 5) {
                Connection conn = DBconnect.getConnection();
                PreparedStatement ps = null;
                PreparedStatement ps1 = null;
                String sql = null;
                String sql1 = null;
                //int resultval = 0;
                op = null;
                int count = 0;

                int flag = 0;
                out.println(" public static void result_money(Owner1 obj[]) {");
                out.println("int x=0;");

                try {
                    sql = "SELECT * FROM MWP";
                    ps = conn.prepareStatement(sql);
                    // System.out.println("sql is:" + ps.toString());
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        String owner = rs.getString(4);
                        String item = rs.getString(5);
                        String attribute = rs.getString(6);
                        String q_verb = rs.getString(7);
                        System.out.println(owner);
                        System.out.println(item);
                        System.out.println(attribute);
                        System.out.println(q_verb);
                        if (attribute.equals("null")) {
                            attribute = null;
                        }
                        if (owner != null) {
                            if (owner.equals("they")) {
                                //  System.out.println("test");
                                owner = null;
                            }
                        }

                        // System.out.println("test");
                        if (q_verb != null) {
                            //System.out.println("wihinhin money all");

                            sql1 = "SELECT variable_count, verb_lemma, operator FROM `owner` where verb_lemma=\"be\" or verb_lemma=\"buy\" or verb_lemma=\"spend\" or verb_lemma=\"purchase\" or verb_lemma=\"pay\" or verb_lemma=\"cost\" or verb_lemma=\"get\" or verb_lemma=\"have\"";
                            ps1 = conn.prepareStatement(sql1);
                            ps.executeQuery();
                            // System.out.println("sql:" + ps1.toString());
                            ResultSet rs1 = ps1.executeQuery();

                            while (rs1.next()) {
                                count = abs(rs1.getInt(1));
                                // System.out.println(count);
                                out.println("x=x+" + count + ";");

                                // resultval = resultval + count;
                            }
                            out.println("System.out.println(\"Anser is: \"+x) ;");

                            //  System.out.println("Result=" + abs(resultval));
                        }

                    }
                } catch (SQLException se) {
                    System.out.println(se);

                } catch (Exception e) {
                    System.out.println(e);
                } finally {
                    DBconnect.closeConnection(conn);

                }

                out.println('}');//end case5

            }
            if (caseoption == 4) {
                Connection conn = DBconnect.getConnection();
                PreparedStatement ps = null;
                PreparedStatement ps1 = null;
                String sql = null;
                String sql1 = null;
                // int resultval = 0;
                String eqn;
                String o;
                StringBuilder neweqn = new StringBuilder("0");
                op = null;
                int count = 0;

                //int flag = 0;
                out.println(" public static void result_money(Owner1 obj[]) {");
                out.println("int x=0;");

                try {
                    sql = "SELECT * FROM MWP";
                    ps = conn.prepareStatement(sql);
                    // System.out.println("sql is:" + ps.toString());
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        String owner = rs.getString(4);
                        String item = rs.getString(5);
                        String attribute = rs.getString(6);
                        String q_verb = rs.getString(7);
                        System.out.println(owner);
                        System.out.println(item);
                        System.out.println(attribute);
                        System.out.println(q_verb);
                        if (attribute.equals("null")) {
                            attribute = null;
                        }
                        if (owner != null) {
                            if (owner.equals("they")) {
                                //  System.out.println("test");
                                owner = null;
                            }
                        }

                        // System.out.println("test");
                        if (q_verb != null) {
                            //System.out.println("wihinhin money all");

                            sql1 = "SELECT equation, variable_count, owner_name, verb_lemma, operator FROM `owner` where verb_lemma=\"be\" or verb_lemma=\"buy\" or verb_lemma=\"spend\" or verb_lemma=\"purchase\" or verb_lemma=\"pay\" or verb_lemma=\"cost\" or verb_lemma=\"get\" or verb_lemma=\"have\"";
                            ps1 = conn.prepareStatement(sql1);
                            ps.executeQuery();
                            out.println("Owner1 oMoney= new Owner1();");
                            out.println("oMoney.variable_count=x;");
                            ResultSet rs1 = ps1.executeQuery();

                            while (rs1.next()) {
                                count = abs(rs1.getInt(2));
                                eqn = rs1.getString(1);
                                o = rs1.getString(3);
                                System.out.println("equation is=" + eqn);
                                if (eqn.contains("obj[0]")) {
                                    eqn = "obj[0].variable_count=" + count+";";
                                   // eqn = eqn.replaceAll("obj\\[0]", "oMoney");
                                     out.println(eqn);
                                    // System.out.println("new equation for money: " + neweqn);
                                    neweqn = neweqn.append("-").append("obj[0].variable_count");
                                } else if (eqn.contains("obj[1]")) {
                                    //System.out.println("obj[1]");

                                  //  eqn = eqn.replaceAll("obj\\[1]", "oMoney");
                                    eqn = "obj[1].variable_count=" + count+";";
                                    out.println(eqn);
                                    // System.out.println("new equation for money: " + eqn);
                                    neweqn = neweqn.append("-obj[1].variable_count");
                                } else if (eqn.contains("obj[2]")) {
                                   // eqn = eqn.replaceAll("obj\\[2]", "oMoney");
                                    // System.out.println("new equation for money: " + neweqn);
                                    eqn = "obj[2].variable_count=" + count+";";
                                    out.println(eqn);
                                   neweqn = neweqn.append("-").append("obj[2].variable_count");
                                } else if (eqn.contains("obj[3]")) {
                                   // eqn = eqn.replaceAll("obj[3]", "oMoney");
                                    // System.out.println("new equation for money: " + neweqn);
                                    eqn = "obj[3].variable_count=" + count+";";
                                    out.println(eqn);
                                    neweqn = neweqn.append("-").append("obj[3].variable_count");
                                }else if (eqn.contains("obj[4]")) {
                                   // eqn = eqn.replaceAll("obj[3]", "oMoney");
                                    // System.out.println("new equation for money: " + neweqn);
                                    eqn = "obj[4].variable_count=" + count+";";
                                    out.println(eqn);
                                    neweqn = neweqn.append("-").append("obj[4].variable_count");
                                }

                            }
                            out.println("int result="+neweqn.toString()+";");
                            out.println("System.out.println(\"Answer is: \"+result) ;");
                            /*
                            out.println("ScriptEngineManager mgr = new ScriptEngineManager();");
                            out.println(" ScriptEngine engine = mgr.getEngineByName(\"JavaScript\");");
                            out.println(" int res = (int) engine.eval("+neweqn.toString()+");");
                            out.println(" res = Math.abs(res);");*/
                           // out.println("System.out.println(\"Anser is: \"+x) ;");

                            //  System.out.println("Result=" + abs(resultval));
                        }

                    }
                } catch (SQLException se) {
                    System.out.println(se);

                } catch (Exception e) {
                    System.out.println(e);
                } finally {
                    DBconnect.closeConnection(conn);

                }

                out.println('}');//end case4

            }
            //case option 2 for missing information
            if (caseoption == 2) {
                System.out.println("I am in case 2..missing");
                String str = null;
                String op_missing = null;
                int start, last = 0;
                int location_x = 0;
                int count = 0;

                out.println(" public static void result_missing(Owner1 obj[]) {");
                out.println("int x=0;");
                StringBuilder equation = new StringBuilder();
                for (int i = 0; i < equationlist.size(); i++) {
                    if (equationlist.get(i).toString().contains("x")) {
                        // System.out.println("index of x is:"+equationlist.get(i).toString().indexOf("x"));
                        str = equationlist.get(i).toString().substring(0, 6);
                        System.out.println("identified object is" + str);
                        break;
                    }
                }
                for (int i = 0; i < equationlist.size(); i++) {
                    if (equationlist.get(i).toString().contains(str)) {
                        count++;
                        if (equationlist.get(i).toString().contains("+")) {
                            op_missing = "+";
                        } else if (equationlist.get(i).toString().contains("-")) {
                            op_missing = "-";
                        } else if (equationlist.get(i).toString().contains("=")) {
                            op_missing = "-";
                        }
                    }
                }
                if (count == 1 && total_owner == 2) {
                    for (int i = 0; i < equationlist.size(); i++) {
                        if (!equationlist.get(i).toString().contains("x")) {
                            // System.out.println("index of x is:"+equationlist.get(i).toString().indexOf("x"));
                            str = equationlist.get(i).toString().substring(0, 6);
                            System.out.println("identified object is" + str);
                            break;
                        }
                    }

                    for (int i = 0; i < equationlist.size(); i++) {
                        if (equationlist.get(i).toString().contains(str)) {
                            count++;

                            String s = equationlist.get(i).toString();
                            last = s.indexOf(";");
                            System.out.println(s);

                            if (s.contains("=") && s.contains("+")) {
                                start = s.indexOf("+");
                                equation.append(s.substring((start + 1), last));
                                equation.append("*");

                            } else if (s.contains("=") && s.contains("-")) {
                                start = s.indexOf("-");
                                equation.append(s.substring((start + 1), last));
                                equation.append("*");

                            } else if (s.contains("=")) {
                                start = s.indexOf("=");
                                equation.append(s.substring((start + 1), last));
                                equation.append("*");

                            }

                        }
                        System.out.println("equation creating==>" + equation.toString());
                    }
                    equation.replace(equation.toString().indexOf("*"), equation.toString().indexOf("*") + 1, op_missing);
                    equation.deleteCharAt(equation.toString().length() - 1);

                } else {
                    count = 0;
                    for (int i = 0; i < equationlist.size(); i++) {
                        if (equationlist.get(i).toString().contains(str)) {
                            count++;

                            String s = equationlist.get(i).toString();
                            last = s.indexOf(";");
                            System.out.println(s);
                            if (s.contains("=") && s.contains("+") && s.contains("x")) {

                                op_missing = "+";
                                equation.append("+x=");
                                location_x = count;
                            } else if (s.contains("=") && s.contains("-") && s.contains("x")) {
                                op_missing = "-";
                                equation.append("-x=");
                                location_x = count;
                            } else if (s.contains("=") && s.contains("x")) {
                                equation.append("x");
                                location_x = count;
                            }
                            if (location_x != 1) {
                                if (s.contains("=") && s.contains("+") && !s.contains("x")) {
                                    start = s.indexOf("+");
                                    equation.append(s.substring((start + 1), last));

                                } else if (s.contains("=") && s.contains("-") && !s.contains("x")) {
                                    start = s.indexOf("-");
                                    equation.append(s.substring((start + 1), last));

                                } else if (s.contains("=") && !s.contains("x")) {
                                    start = s.indexOf("=");
                                    equation.append(s.substring((start + 1), last));

                                }
                            } else if (s.contains("=") && s.contains("+") && !s.contains("x")) {
                                start = s.indexOf("+");
                                equation.append("+");
                                equation.append(s.substring((start + 1), last));

                            } else if (s.contains("=") && s.contains("-") && !s.contains("x")) {
                                start = s.indexOf("-");
                                equation.append("-");
                                equation.append(s.substring((start + 1), last));

                            } else if (s.contains("=") && !s.contains("x")) {
                                start = s.indexOf("=");
                                equation.append("=");
                                equation.append(s.substring((start + 1), last));

                            }
                        }
                        System.out.println("equation creating==>" + equation.toString());
                    }
                    System.out.println("location of x is=" + location_x);

                    String finalequation = equation.toString();
                    String eq[] = finalequation.split("=");
                    String left = eq[0];
                    System.out.println("left string : " + left);
                    if (left.contains("-")) {
                        String leftn[] = left.split("\\-");
                        System.out.println("left_1 : " + leftn[0] + "left_2 : " + leftn[1]);
                        if (location_x == 1) {
                            equation.replace(equation.toString().indexOf("="), equation.toString().indexOf("=") + 1, "+");
                            System.out.println("eq: " + equation.toString());
                            equation.replace(equation.toString().indexOf("-"), equation.toString().indexOf("-") + 1, "+");
                            System.out.println("eq: " + equation.toString());
                            if (equation.toString().contains("-")) {
                                equation.replace(equation.toString().indexOf("-"), equation.toString().indexOf("-") + 1, "+");
                                System.out.println("eq: " + equation.toString());
                            }
                            equation.delete(0, 1);
                            System.out.println("eq: " + equation.toString());
                        } else {

                            // equation.replace(equation.toString().indexOf("="), equation.toString().indexOf("=")+1, "+");
                            equation.delete(equation.toString().indexOf("-") + 1, equation.toString().indexOf("=") + 1);
                        }
                    } else if (left.contains("+")) {

                        String leftn[] = eq[0].split("\\+");
                        System.out.println("left_1" + leftn[0] + "left_2" + leftn[1]);
                        if (location_x == 1) {
                            equation.replace(equation.toString().indexOf("="), equation.toString().indexOf("=") + 1, "-");
                            equation.delete(0, 1);
                        } else {
                            // equation.replace(equation.toString().indexOf("="), equation.toString().indexOf("=")+1, "+");
                            equation.insert(equation.toString().indexOf("+"), "-");
                            equation.delete(equation.toString().indexOf("+"), equation.toString().indexOf("=") + 1);
                        }
                    }
                }

                ScriptEngineManager mgr = new ScriptEngineManager();
                ScriptEngine engine = mgr.getEngineByName("JavaScript");
                int res = (int) engine.eval(equation.toString());
                res = Math.abs(res);

                System.out.println("Result is---" + res);
                out.println('}');//end case2

            }

            out.println('}');//end of main class
            out.close();
            System.out.println("done to create java prog");

        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        } finally {
            if (out != null) {
                out.close();
            }
            try {
                if (bw != null) {
                    bw.close();
                }
            } catch (IOException e) {
                //exception handling left as an exercise for the reader
            }
            try {
                if (fw != null) {
                    fw.close();
                }
            } catch (IOException e) {
                //exception handling left as an exercise for the reader
            }
        }
    }

}
