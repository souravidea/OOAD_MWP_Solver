/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

/**
 *
 * @author Sourav
 */
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.process.CoreLabelTokenFactory;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.process.PTBTokenizer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

//import static java.lang.System.out;
public class TokenizerDemo {

    public void invoke() throws IOException {
        String arg1[] = new String[1];
        arg1[0] = "/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt";

        for (String arg : arg1) {
            // option #1: By sentence.
            DocumentPreprocessor dp = new DocumentPreprocessor(arg);
            //out.println("Displaying the sentences");
            File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/sentence.txt"); //Your file
            FileOutputStream fos = new FileOutputStream(file);
            PrintStream ps = new PrintStream(fos);
            System.setOut(ps);

            for (List<HasWord> sentence : dp) {

                System.out.println(sentence);

            }

            // option #2: By token
            PTBTokenizer<CoreLabel> ptbt = new PTBTokenizer<>(new FileReader(arg), new CoreLabelTokenFactory(), "");
            //out.println("Displaying the tokens"); 
            File file2 = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/tokens.txt"); //Your file
            FileOutputStream fos2 = new FileOutputStream(file2);
            PrintStream ps2 = new PrintStream(fos2);
            System.setOut(ps2);

            while (ptbt.hasNext()) {
                CoreLabel label = ptbt.next();

                System.out.println(label);

            }

        }
    }
}
