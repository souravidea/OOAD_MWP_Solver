/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

/**
 *
 * @author sourav
 */
public class rep {
    public static void main(String[] args) {
        String s="sourav mand[0]al mand[0]al";
        System.out.println(s.replaceAll("and\\[0]", "vgjkhj"));
    }
    
}
