/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import static mwproblem.DBconnect.USER;
import com.ibatis.common.jdbc.ScriptRunner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;

/**
 *
 * @author sourav
 */
public class LoadSRL {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/MWPDB";
    static final String USER = "root";
    static final String PASS = "password";

   
    public static void runScript(String source) throws ClassNotFoundException,SQLException, Exception {

		String aSQLScriptFilePath = source;
                System.out.println("Source="+source);
		// Create MySql Connection
		//Class.forName("com.mysql.jdbc.Driver");
		Connection con = DBconnect.getConnection();
		
               // Statement stmt = null;

		try {
			// Initialize object for ScripRunner
			ScriptRunner sr = new ScriptRunner(con, false, false);

			// Give the input file to Reader
			Reader reader = new BufferedReader(new FileReader(aSQLScriptFilePath));

			// Exctute script
			sr.runScript(reader);
                        System.out.println("done");

		} catch (Exception e) {
			System.err.println("Failed to Execute" + aSQLScriptFilePath
					+ " The error is " + e.getMessage());
		}
	}

}
