/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sourav
 */
public class start {

    public static void main(String[] args) throws FileNotFoundException, IOException, Exception {

        RunnableDemo1 R1 = new RunnableDemo1("Thread-1");
        // RunnableDemo1 obj1=new RunnableDemo1("thread1");
        Thread t1=new Thread(R1);
        t1.start();
        t1.join();
       // R1.start();
       if(t1.isAlive()){
           
       }
        
        RunnableDemo2 R2 = new RunnableDemo2("Thread-2");
        Thread t2=new Thread(R2);
        t2.start();
        t2.join();
        
        //R2.start();
        RunnableDemo3 R3 = new RunnableDemo3("Thread-3");
        Thread t3=new Thread(R3);
        t3.start();
        t3.join();
       // R3.start();

    }
}

class RunnableDemo1 implements Runnable {

    private Thread t;
    private final String threadName;

    RunnableDemo1(String name) {
        threadName = name;
        System.out.println("Creating " + threadName);
    }

    @Override
    public void run() {
        System.out.println("Running " + threadName);
        System.out.println("input");
        try {
            // input();
            String text = "There were 28 bales of hay in the barn. Tim stacked bales in the barn today. There are now 54 bales of hay in the barn. How many bales did he store in the barn?";
            File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"); //Your file
            System.out.println("input text: " + text);
            FileOutputStream fos = new FileOutputStream(file);
            PrintStream psr = new PrintStream(fos);
            System.setOut(psr);
            System.out.println(text);
            System.out.println();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(start.class.getName()).log(Level.SEVERE, null, ex);
        }
       // System.out.println("input done");
      //  System.out.println("Thread " + threadName + " exiting.");
    }

    public void start() {
      //  System.out.println("Starting " + threadName);
        if(t == null) {
            t = new Thread(this, threadName);
            t.start();
        }
    }
}

class RunnableDemo2 implements Runnable {

    private Thread t;
    private final String threadName;

    RunnableDemo2(String name) {
        threadName = name;
      //  System.out.println("Creating " + threadName);
    }

    @Override
    public void run() {
      //  System.out.println("Running " + threadName);
      //  System.out.println("input");
        try {
            // preprocess();
            Thread.sleep(5000);
           // System.out.println("conjuction");
            ConjunctionResolver resolve = new ConjunctionResolver();
            resolve.invoke();
           // System.out.println("coreference");
            CorefSubstitution subs = new CorefSubstitution();
          //  subs.invoke();
           // System.out.println("tokenization");
            TokenizerDemo token = new TokenizerDemo();
            token.invoke();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(start.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(start.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(start.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

    public void start() {
      //  System.out.println("Starting " + threadName);
        if (t == null) {
            t = new Thread(this, threadName);
            t.start();
        }
    }
}

class RunnableDemo3 implements Runnable {

    private Thread t;
    private final String threadName;

    RunnableDemo3(String name) {
        threadName = name;
       // System.out.println("Creating " + threadName);
    }

    @Override
    public void run() {
       // System.out.println("Running " + threadName);
       // System.out.println("input");
        try {
            // preprocess();
            Thread.sleep(70000);
            System.out.println("processing");
          //  MWProblem.processing_result();

        } catch (Exception ex) {
            Logger.getLogger(start.class.getName()).log(Level.SEVERE, null, ex);
        }
       // System.out.println("input done");
       // System.out.println("Thread " + threadName + " exiting.");
    }

    public void start() {
        //System.out.println("Starting " + threadName);
        if (t == null) {
            t = new Thread(this, threadName);
            t.start();
        }
    }
}
/*

    public static void input() throws FileNotFoundException {
        String text = "There were 28 bales of hay in the barn. Tim stacked bales in the barn today. There are now 54 bales of hay in the barn. How many bales did he store in the barn?";
        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"); //Your file
        System.out.println("input text: " + text);
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream psr = new PrintStream(fos);
        System.setOut(psr);
        System.out.println(text);
        System.out.println();
    }

    public static void preprocess() throws ClassCastException, FileNotFoundException, IOException, Exception {
        System.out.println("conjuction");
        ConjunctionResolver resolve = new ConjunctionResolver();
        resolve.invoke();
        System.out.println("coreference");
        CorefSubstitution subs = new CorefSubstitution();
        subs.invoke();
        System.out.println("tokenization");
        TokenizerDemo token = new TokenizerDemo();
        token.invoke();
        System.out.println("start processing");

    }

}*/
