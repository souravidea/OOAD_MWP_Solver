/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

class Owner1 {

    public String owner_name;
    public String variable_name = "apples";
    public int variable_count;

    public void setname(String name) {
        owner_name = name;
    }

    public String getname() {
        return owner_name;
    }

    public void display() {
        System.out.println("Owner is:" + owner_name);
        System.out.println("Variable is:" + variable_name);
        System.out.println("Count:" + variable_count);

    }

}

public class Eval {

    public static void main(String args[]) {
       

            Owner obj[] = new Owner[4];
            for (int i = 0; i < obj.length; i++) {
                obj[i] = new Owner();
            }
            obj[0].variable_count = 3;
            obj[0].variable_count = obj[0].variable_count + 2;
            for (int i = 0; i < obj.length; i++) {
                obj[i].display();
            }
        }
    }



