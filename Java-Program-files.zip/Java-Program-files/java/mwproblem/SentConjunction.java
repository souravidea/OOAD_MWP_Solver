/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.CoreLabelTokenFactory;
import edu.stanford.nlp.process.Morphology;
import edu.stanford.nlp.process.PTBTokenizer;
import edu.stanford.nlp.process.TokenizerFactory;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import edu.stanford.nlp.trees.GrammaticalStructure;
import edu.stanford.nlp.trees.GrammaticalStructureFactory;
import edu.stanford.nlp.trees.PennTreebankLanguagePack;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreebankLanguagePack;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author sourav
 */
public class SentConjunction {

    public String sentenceline;
    public String sent_type;
    public int sent_sl_no;
    public int no_of_tokens;
    // public int no_of_name_entities;
    // public String verb_name;
    // public String verb_lemma;

    public String taggedString;
    public String depString;
    boolean isVB = false;

    public boolean tagging() {
        boolean checkpoint = false;
        boolean isNN = false;

        MaxentTagger tagger = new MaxentTagger("edu/stanford/nlp/models/pos-tagger/english-left3words/english-left3words-distsim.tagger");
        taggedString = tagger.tagString(sentenceline);

        // String[] tokens = taggedString.split(", and");
        //  String sentline=sentenceline.substring(sentenceline.indexOf("and")+4);
        //System.out.println(sentline);
        String[] tokens = taggedString.split(" ");

        for (String tok : tokens) {
            String[] taggedTokens = tok.split("_");
            for (String taggedToken : taggedTokens) {
                // System.out.println(taggedToken);
            }

            String name = taggedTokens[0];
           // System.out.println("@@@@@" + name);
            if (name.equals("and")) {
                checkpoint = true;
            }
            if (checkpoint == true && taggedTokens[1].startsWith("VB") && isNN == false) {
                isVB = true;
                break;

            }
            if (checkpoint == true && taggedTokens[1].equals("NNP")) {
                //isVB=true;
                break;

            } else if (checkpoint == true && (taggedTokens[1].equals("NN") || taggedTokens[1].equals("NNS"))) {
                isNN = true;
                // break;

            }
            if (checkpoint == true && isNN == true && taggedTokens[1].startsWith("VB")) {
                break;
            }

        }//end tok for
        if (checkpoint == true && isNN == true && isVB != true) {
            isVB = true;
        }

        // System.out.println();
        System.out.println();
        return isVB;

    }
    

}
