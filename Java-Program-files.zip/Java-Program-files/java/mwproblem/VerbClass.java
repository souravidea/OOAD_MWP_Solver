/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Sourav
 */
public class VerbClass {

    public int sent_sl_no;
    public String verb_name;
    public String verb_lemma;
    public String owner_name;
    public String second_owner;
    public String variable_name;
    public int variable_count;
    public String verb_category;

    public void display() {
        System.out.println("sent sl no:" + sent_sl_no);
        System.out.println("verb_name:" + verb_name);
        System.out.println("verb_lemma:" + verb_lemma);
        System.out.println("owner_name:" + owner_name);
        System.out.println("variable_name:" + variable_name);
        System.out.println("variable_count:" + variable_count);
    }

    public void fill_table() throws Exception {
        Connection conn = DBconnect.getConnection();
        System.out.println("connection made ");
        System.out.println("Creating statement for verb table...");
        //Statement stmt = conn.createStatement();
        String sql;

        sql = "INSERT INTO verbstable ( sent_sl_no, verb_name, verb_lemma, owner_name, second_owner, variable_name, variable_count) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, sent_sl_no);
            // ps.setInt(2, sent_sl_no);
            if(verb_name==null){
                verb_name="are";
            }
            ps.setString(2, verb_name);
            ps.setString(3, verb_lemma);
            ps.setString(4, owner_name);
            ps.setString(5, second_owner);
            ps.setString(6, variable_name);
            ps.setInt(7, variable_count);
            System.out.println("ps:" + ps.toString());
            ps.executeUpdate();
            System.out.println("done in verb table");

        } catch (SQLException se) {
            System.out.println("not working");

        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

    public void select_fill_verbs(int i) throws Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for specific verb table table...");
        Statement stmt = conn.createStatement();
        String sql;

        
        try {
            
            if ("have".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO have (sent_sl_no, owner_name, second_owner, variable_name, variable_count) SELECT sent_sl_no, owner_name,second_owner, variable_name, variable_count from verbstable where verb_lemma='have' and sent_sl_no=" + i;
                stmt.executeUpdate(sql);
                System.out.println("done in have table");
            }
            if ("give".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO give (sent_sl_no, doner, recipient, variable_name, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='give' and sent_sl_no=" + i;
                System.out.println("sql give:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in give table");
            }
            if ("find".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO find (sent_sl_no, perceiver, sought_entity, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='find' and sent_sl_no=" + i;
                System.out.println("sql find:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in find table");
            }
            if ("play".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO play (sent_sl_no, owner, variable_name, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='play' and sent_sl_no=" + i;
                System.out.println("sql play:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in play table");
            }
            if ("cut".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO cut (sent_sl_no, agent, source, item, pieces) SELECT sent_sl_no, owner_name,second_owner, variable_name, variable_count from verbstable where verb_lemma='cut' and sent_sl_no=" + i;
                System.out.println("sql cut:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in cut table");
            }
            /////
            if ("have".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO have (sent_sl_no, owner_name, second_owner, variable_name, variable_count) SELECT sent_sl_no, owner_name,second_owner, variable_name, variable_count from verbstable where verb_lemma='have' and sent_sl_no=" + i;
                stmt.executeUpdate(sql);
                System.out.println("done in have table");
            }
            if ("give".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO give (sent_sl_no, doner, recipient, variable_name, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='give' and sent_sl_no=" + i;
                System.out.println("sql give:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in give table");
            }
            if ("find".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO find (sent_sl_no, perceiver, sought_entity, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='find' and sent_sl_no=" + i;
                System.out.println("sql find:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in find table");
            }
            if ("play".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO play (sent_sl_no, owner, variable_name, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='play' and sent_sl_no=" + i;
                System.out.println("sql play:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in play table");
            }
            if ("cut".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO cut (sent_sl_no, agent, source, item, pieces) SELECT sent_sl_no, owner_name,second_owner, variable_name, variable_count from verbstable where verb_lemma='cut' and sent_sl_no=" + i;
                System.out.println("sql cut:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in cut table");
            }
            if ("be".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO be (sent_sl_no, owner_name, variable_name, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='be' and sent_sl_no=" + i;
                System.out.println("sql be:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in be table");
            }
            if ("plant".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO plant (sent_sl_no, agent, location, theme, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='plant' and sent_sl_no=" + i;
                System.out.println("sql plant:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in plant table");
            }
            if ("serve".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO serve (sent_sl_no, server, recipient, theme, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='serve' and sent_sl_no=" + i;
                System.out.println("sql serve:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in serve table");
            }
            if ("grow".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO grow (sent_sl_no, agent, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='grow' and sent_sl_no=" + i;
                System.out.println("sql grow:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in grow table");
            }
            if ("pick".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO pick (sent_sl_no, cognizer, second_owner, item, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='pick' and sent_sl_no=" + i;
                System.out.println("sql pick:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in pick table");
            }
            if ("place".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO place (sent_sl_no, agent, second_owner, theme, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='place' and sent_sl_no=" + i;
                System.out.println("sql place:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in place table");
            }
            if ("go".equals(verb_lemma) || "clean".equals(verb_lemma)) {
                if (verb_lemma.equals("clean")) {
                    verb_lemma = "go";

                }
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO go (sent_sl_no, agent, event, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='go' and sent_sl_no=" + i;
                System.out.println("sql go:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in go table");
            }
            if ("buy".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO buy (sent_sl_no, buyer, seller, goods, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='buy' and sent_sl_no=" + i;
                System.out.println("sql buy:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in buy table");
            }
            if ("finish".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO finish (sent_sl_no, agent, location, activity, result) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='finish' and sent_sl_no=" + i;
                System.out.println("sql finish:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in finish table");
            }
            if ("receive".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO receive (sent_sl_no, recipient, doner, theme, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='receive' and sent_sl_no=" + i;
                System.out.println("sql receive:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in receive table");
            }
            if ("spend".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO spend (sent_sl_no, agent, resource, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='spend' and sent_sl_no=" + i;
                System.out.println("sql spend:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in spend table");
            }
            if ("attend".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO attend (sent_sl_no, agent, phenomena, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='attend' and sent_sl_no=" + i;
                System.out.println("sql attend:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in attend table");
            }
            if ("wash".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO wash (sent_sl_no, agent, theme, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='wash' and sent_sl_no=" + i;
                System.out.println("sql wash:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in wash table");
            }
            if ("stack".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO stack (sent_sl_no, agent, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='stack' and sent_sl_no=" + i;
                System.out.println("sql wash:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in stack table");
            }
            if ("store".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO store (sent_sl_no, agent, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='store' and sent_sl_no=" + i;
                System.out.println("sql store:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in store table");
            }
            if ("lose".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO lose (sent_sl_no, owner, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='lose' and sent_sl_no=" + i;
                System.out.println("sql lose:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in lose table");
            }
            if ("break".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO break (sent_sl_no, owner, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='break' and sent_sl_no=" + i;
                System.out.println("sql break:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in break table");
            }
            if ("borrow".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO borrow (sent_sl_no, borrower, lender, theme, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='borrow' and sent_sl_no=" + i;
                System.out.println("sql borrow:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in borrow table");
            }
            if ("eat".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO eat (sent_sl_no, agent, food, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='eat' and sent_sl_no=" + i;
                System.out.println("sql eat:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in eat table");
            }

            if ("make".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO make (sent_sl_no, creator, product, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='make' and sent_sl_no=" + i;
                System.out.println("sql make:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in make table");
            }
            if ("take".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO take (sent_sl_no, receiver, doner, item, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='take' and sent_sl_no=" + i;
                System.out.println("sql take:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in take table");
            }
            if ("decide".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO decide (sent_sl_no, owner, variable_name, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='decide' and sent_sl_no=" + i;
                stmt.executeUpdate(sql);
                System.out.println("done in decide table");
            }
            if ("sell".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO sell (sent_sl_no, seller, buyer, item, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='sell' and sent_sl_no=" + i;
                System.out.println("sql sell:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in sell table");
            }
            if ("purchase".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO purchase (sent_sl_no, buyer,seller,  goods, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='purchase' and sent_sl_no=" + i;
                System.out.println("sql purchase:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in purchase table");
            }

            if ("get".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO get (sent_sl_no, receiver, doner, theme, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='get' and sent_sl_no=" + i;
                System.out.println("sql get:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in get table");
            }
            if ("pay".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO pay (sent_sl_no,buyer, seller, goods, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='pay' and sent_sl_no=" + i;
                System.out.println("sql pay:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in pay table");
            }
            if ("own".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO own (sent_sl_no, owner, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='own' and sent_sl_no=" + i;
                System.out.println("sql own:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in own table");
            }
            if ("gather".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO gather (sent_sl_no, person, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='gather' and sent_sl_no=" + i;
                System.out.println("sql gather:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in gather table");
            }
            if ("tear".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO tear (sent_sl_no, owner, theme, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='tear' and sent_sl_no=" + i;
                System.out.println("sql tear:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in tear table");
            }
            if ("miss".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO miss (sent_sl_no, owner, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='miss' and sent_sl_no=" + i;
                System.out.println("sql miss:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in miss table");
            }
            if ("plan".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO plan (sent_sl_no, owner, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='plan' and sent_sl_no=" + i;
                System.out.println("sql plan:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in plan table");
            }
            if ("crack".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO crack (sent_sl_no, owner, item, variable_count) SELECT sent_sl_no, owner_name, variable_name, variable_count from verbstable where verb_lemma='crack' and sent_sl_no=" + i;
                System.out.println("sql crack:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in crack table");
            }
            if ("cost".equals(verb_lemma)) {
                System.out.println("verb lemma is" + verb_lemma);
                sql = "INSERT INTO cost (sent_sl_no, owner,second_owner, item, variable_count) SELECT sent_sl_no, owner_name, second_owner, variable_name, variable_count from verbstable where verb_lemma='cost' and sent_sl_no=" + i;
                System.out.println("sql cost:" + sql);
                stmt.executeUpdate(sql);
                System.out.println("done in cost table");
            }

        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }

    }

}
