/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import java.util.*;
import edu.stanford.nlp.ling.*;
import edu.stanford.nlp.trees.*;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.DocumentPreprocessor;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 *
 * @author Sourav
 */
public class ParserDemo {

   // public void invokeparse() throws FileNotFoundException {
          public static void main(String[] args) throws FileNotFoundException {
        
    
        LexicalizedParser lp = LexicalizedParser
                .loadModel("edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz");
        lp.setOptionFlags(new String[]{"-maxLength", "80",
            "-retainTmpSubcategories"});
        String arg1[] = new String[1];
        arg1[0] = "/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt";
        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/parse.txt"); //Your file
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream ps = new PrintStream(fos);
        System.setOut(ps);
        for (String arg : arg1) {
            // option #1: By sentence.
         
            DocumentPreprocessor dp = new DocumentPreprocessor(arg);
            int count=0;
            for (List<HasWord> sentence : dp) {
                count++;
                System.out.println("sentence serial no===>"+count);
                // String[] sent = {"This", "is", "an", "easy", "sentence", "."};
                List<CoreLabel> rawWords = Sentence.toCoreLabelList(sentence);
                Tree parse = lp.apply(rawWords);

                parse.pennPrint();
                System.out.println();

                TreebankLanguagePack tlp = new PennTreebankLanguagePack();
                GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
                GrammaticalStructure gs = gsf.newGrammaticalStructure(parse);
                List<TypedDependency> tdl = gs.typedDependenciesCCprocessed();
                System.out.println(tdl);
                TreePrint tp = new TreePrint("penn,typedDependenciesCollapsed");
                tp.printTree(parse);
            }
        }
    }
    
    
}

