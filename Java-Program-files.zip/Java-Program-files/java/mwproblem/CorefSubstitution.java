/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import edu.stanford.nlp.hcoref.CorefCoreAnnotations;
import edu.stanford.nlp.hcoref.CorefCoreAnnotations.CorefChainAnnotation;
import edu.stanford.nlp.hcoref.data.CorefChain;
import edu.stanford.nlp.hcoref.data.CorefChain.CorefMention;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreAnnotations.TokensAnnotation;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
//import edu.stanford.nlp.util.CoreMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

/**
 *
 * @author sourav
 */
public class CorefSubstitution {

    private static void doTest(String text, StanfordCoreNLP pipeline) {
        Annotation doc = new Annotation(text);
        // pipeline.annotate(doc);
        //AnnotationPipeline pipeline = new AnnotationPipeline();
        // Annotation doc =  = new Annotation();
       // Properties props = new Properties();
        //props.setProperty("annotators", "tokenize,ssplit,pos,lemma,ner,parse,mention,coref");
        //StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        pipeline.annotate(doc);

        // pipeline.process(text);
        try {
            Map<Integer, CorefChain> corefs = doc.get(CorefChainAnnotation.class);
            List<CoreMap> sentences = doc.get(CoreAnnotations.SentencesAnnotation.class);

            List<String> resolved = new ArrayList<String>();
            //  System.out.println("I am here");

            if (corefs != null) {
                for (CoreMap sentence : sentences) {

                    List<CoreLabel> tokens = sentence.get(CoreAnnotations.TokensAnnotation.class);

                    for (CoreLabel token : tokens) {

                        Integer corefClustId = token.get(CorefCoreAnnotations.CorefClusterIdAnnotation.class);

                        CorefChain chain = corefs.get(corefClustId);

                        if (chain == null || chain.getMentionsInTextualOrder().size() == 1) {
                            //  System.out.println("true in if");
                            //  System.out.println("token word is" + token.word());
                            resolved.add(token.word());
                        } else {
                            //    System.out.println("false in if(chain == null || chain.getMentionsInTextualOrder().size() == 1)");
                            //  System.out.println("token word is:" + token.word());

                            int sentINdx = chain.getRepresentativeMention().sentNum - 1;
                            CoreMap corefSentence = sentences.get(sentINdx);
                            List<CoreLabel> corefSentenceTokens = corefSentence.get(TokensAnnotation.class);

                            String newwords = "";
                            CorefMention reprMent = chain.getRepresentativeMention();
                           // System.out.println(reprMent);
                           // System.out.println("token word index is:" + token.index());
                            String word = token.word();
                           // System.out.println("word is" + word);

                            String ref = reprMent.toString();
                           // System.out.println("ref word is" + ref);

                            if (!word.equals(ref) && (word.equals("He") || word.equals("he") || word.equals("She") || word.equals("she") || word.equals("It") || word.equals("it") || word.equals("His")|| word.equals("Her")|| word.equals("him")|| word.equals("her")|| word.equals("his") )) {
                                // if (token.index() < reprMent.startIndex || token.index() > reprMent.endIndex) {
                                //   System.out.println("true in if (token.index() < reprMent.startIndex || token.index() > reprMent.endIndex)");
                                //  System.out.println("true in if(!word.equals(ref))");

                              //  System.out.println("starts is" + reprMent.startIndex);
                               // System.out.println("end index is" + reprMent.endIndex);
                                int start = reprMent.startIndex;
                                int end = reprMent.endIndex;
                                if (ref.contains("'s")) {
                                    end = end - 1;
                                }
                                for (int i = start; i < end; i++) {

                                    // for(int i=ref.)
                                    CoreLabel matchedLabel = corefSentenceTokens.get(i - 1);
                                    // resolved.add(matchedLabel.word());

                                    if (word.equals("His") || word.equals("Her")||word.equals("his") || word.equals("her")) {
                                        newwords += matchedLabel.word() + "'s";
                                       // System.out.println("new words" + newwords);

                                    } else {
                                        newwords += matchedLabel.word();
                                    }

                                    resolved.add(newwords);

                                }
                            } else {
                                //  System.out.println("false in if (token.index() < reprMent.startIndex || token.index() > reprMent.endIndex)");
                                resolved.add(token.word());

                            }

                        }

                    }

                }

                String resolvedStr = "";

                for (String str : resolved) {
                    resolvedStr += str + " ";
                }
                System.out.println(resolvedStr);
            }
        } catch (Exception e) {
            System.out.println(e);

        }

    }

    // public void invoke() throws FileNotFoundException {
    public static void main(String[] args) throws FileNotFoundException {
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize,ssplit,pos,lemma,ner,parse,mention,coref");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);

       // CorefSubstitution c = new CorefSubstitution();
       // String text = "Tim cat had kittens. He gave 3 to Jessica and 6 to Sara. He now has 9 kittens. How many kittens did he have to start with?";
       // c.doTest(text);
       // String entireFileText = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
       // File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"); //Your file
       // File file = new File("/home/sourav/weka data file/MWPSets/SOChangeProblemsWithOPCOrefSubstitute"); 
         //File file = new File("/home/sourav/weka data file/MWPSets/ASChangeProblemsWithOPCOrefSubstitute"); 
          File file = new File("/home/sourav/weka data file/MWPSetsNew/Final problems/AddSub/ASChangeProblemsCorefSubstituteWithOp"); 
       FileOutputStream fos = new FileOutputStream(file);
        PrintStream ps = new PrintStream(fos);
        System.setOut(ps);
        // try (Scanner scanner = new Scanner(new File("/home/sourav/weka data file/MWPSets/SOChangeProblemsWithOP"))) {
             //try (Scanner scanner = new Scanner(new File("/home/sourav/weka data file/MWPSets/ASChangeProblemsWithOP"))) {
       try (Scanner scanner = new Scanner(new File("/home/sourav/weka data file/MWPSetsNew/Final problems/AddSub/ASChangeProblemsWithOPFinal"))) {
            while (scanner.hasNextLine()) {
       String entireFileText = scanner.nextLine();
       
        //System.out.println("resolving coreference....");
        doTest(entireFileText, pipeline);
            }
    }catch (FileNotFoundException e) {
            e.printStackTrace();
        }
}
}
