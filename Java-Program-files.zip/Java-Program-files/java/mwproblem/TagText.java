/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

/**
 *
 * @author Sourav
 */
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.process.DocumentPreprocessor;
import java.io.IOException;

import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.List;

public class TagText {

    public void invoketag() throws IOException, ClassNotFoundException {

        // Initialize the tagger
        MaxentTagger tagger = new MaxentTagger("edu/stanford/nlp/models/pos-tagger/english-left3words/english-left3words-distsim.tagger");
        String arg1[] = new String[1];
        arg1[0] = "/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt";
        // The sample string
        // String sample = "This is a sample text";

        // The tagged string
        for (String arg : arg1) {
            DocumentPreprocessor dp = new DocumentPreprocessor(arg);
            File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/tagset.txt"); //Your file
            FileOutputStream fos = new FileOutputStream(file);
            PrintStream ps = new PrintStream(fos);
            System.setOut(ps);
            for (List<HasWord> sentence : dp) {
                //sentence s=sentence.
                String sent = sentence.toString();

                String tagged = tagger.tagString(sent);

                // Output the result
                System.out.println(tagged);
            }
        }
    }
}
