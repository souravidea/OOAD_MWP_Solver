/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import static java.lang.System.exit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author sourav
 */
public class DBconnect {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/MWPDB";
    static final String USER = "root";
    static final String PASS = "password";

    public static Connection getConnection() throws Exception {
        Connection conn = null;

        try {
            Class.forName(JDBC_DRIVER).newInstance();
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("connaction done in DB");

        } catch (SQLException se) {
            System.out.println("Some problem for establishment of connection");
            exit(0);

        }
        return conn;
    }

    public static void closeConnection(Connection conn) {

        try {

            conn.close();

        } catch (SQLException e) {
            System.out.println("connection not closed");

        }

    }

   

}
