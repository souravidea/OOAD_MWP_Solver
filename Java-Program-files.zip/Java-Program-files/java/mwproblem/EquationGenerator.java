/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mwproblem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sourav
 */
public class EquationGenerator {

    String equation;
    String verb_category;

    void generator(int i) throws SQLException, Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for generation of equation table...");
        String sql = "select * from verbstable where sent_sl_no=" + i;
        System.out.println(sql);
        PreparedStatement ps = conn.prepareStatement(sql);
        try {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String owner_name = rs.getString("owner_name");
                String second_owner = rs.getString("second_owner");
                int variable_count = rs.getInt("variable_count");
                String verb_lemma = rs.getString(3);
                //similerity verbs
                System.out.println("verb lemma is now===>" + verb_lemma);
                System.out.println("owner name==>" + owner_name);
                if (verb_lemma.equals("find") || verb_lemma.equals("be") || verb_lemma.equals("clean") || verb_lemma.equals("") || verb_lemma.equals("decide") || verb_lemma.equals("finish") || verb_lemma.equals("cost") || verb_lemma.equals("get") || verb_lemma.equals("bake") || verb_lemma.equals("want") || verb_lemma.equals("put") || verb_lemma.equals("call") || verb_lemma.equals("discover") || verb_lemma.equals("start")) {
                    verb_category = "observation";
                }
                if (verb_lemma.equals("finish") || verb_lemma.equals("stock") || verb_lemma.equals("have") || verb_lemma.equals("play")) {
                    System.out.println("bothobservation category");
                    verb_category = "bothobservation";
                }
                if (verb_lemma.equals("make") || verb_lemma.equals("gather") || verb_lemma.equals("go") || verb_lemma.equals("grow") || verb_lemma.equals("pick") || verb_lemma.equals("") || verb_lemma.equals("join") || verb_lemma.equals("plan") || verb_lemma.equals("read") || verb_lemma.equals("attend") || verb_lemma.equals("") || verb_lemma.equals("wash") || verb_lemma.equals("collect") || verb_lemma.equals("win") || verb_lemma.equals("add")) {
                    verb_category = "increment";
                }
                if (verb_lemma.equals("lose") || verb_lemma.equals("crack") || verb_lemma.equals("spend") || verb_lemma.equals("serve") || verb_lemma.equals("miss") || verb_lemma.equals("break") || verb_lemma.equals("eat") || verb_lemma.equals("defeat") || verb_lemma.equals("put")) {
                    verb_category = "decrement";
                }
                if (verb_lemma.equals("give") || verb_lemma.equals("pay") || verb_lemma.equals("place") || verb_lemma.equals("sell")) {
                    verb_category = "negtranfer";
                }
                if (verb_lemma.equals("purchase") || verb_lemma.equals("buy") || verb_lemma.equals("take") || verb_lemma.equals("receive") || verb_lemma.equals("borrow")) {
                    verb_category = "postransfer";
                }
                if (verb_lemma.equals("plant") || verb_lemma.equals("stack") || verb_lemma.equals("")) {
                    verb_category = "bothincrement";
                }
                if (verb_lemma.equals("cut") || verb_lemma.equals("damage") || verb_lemma.equals("")) {
                    verb_category = "bothdecrement";
                }
                if (verb_category.equals("observation")) {

                    System.out.println("owner name: isv" + owner_name);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    //ResultSet rs2 = ps.executeQuery();
                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=x;";
                    } else {
                        equation = owner_name + ".variable_count=" + variable_count + ";";
                    }
                    System.out.println("equation is" + equation);
                    ps.setString(1, equation);

                    ps.executeUpdate();

                }
                if (verb_category.equals("bothobservation")) {

                    System.out.println("owner name:" + owner_name);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    //ResultSet rs2 = ps.executeQuery();
                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=x;";
                    } else {
                        equation = owner_name + ".variable_count=" + variable_count + ";";
                    }
                    System.out.println("equation is:" + equation);
                    ps.setString(1, equation);
                    System.out.println("done in " + equation);
                    ps.executeUpdate();
                    if (second_owner != null) {
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);

                        if (variable_count == 0) {
                            equation = second_owner + ".variable_count=x;";
                        } else {
                            equation = second_owner + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                }
                if (verb_category.equals("increment")) {

                    System.out.println("Agent name:" + owner_name);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    //ResultSet rs2 = ps.executeQuery();
                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count+x;";
                    } else {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                    }
                    System.out.println("equation is" + equation);
                    ps.setString(1, equation);

                    ps.executeUpdate();
                    /*
                    if (second_owner != null) {
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count+x;";
                        } else {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count+" + variable_count + ";";
                        }

                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    
                    }*/
                }
                if (verb_category.equals("bothincrement")) {

                    System.out.println("Agent name:" + owner_name);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    //ResultSet rs2 = ps.executeQuery();
                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count+x;";
                    } else {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                    }
                    System.out.println("equation is" + equation);
                    ps.setString(1, equation);

                    ps.executeUpdate();

                    if (second_owner != null) {
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (second_owner != null) {
                            if (variable_count == 0) {
                                equation = second_owner + ".variable_count=" + second_owner + ".variable_count+x;";
                            } else {
                                equation = second_owner + ".variable_count=" + second_owner + ".variable_count+" + variable_count + ";";
                            }
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();

                    }
                }
                if (verb_category.equals("decrement")) {

                    System.out.println("Owner name:" + owner_name);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    //ResultSet rs2 = ps.executeQuery();

                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                    } else {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                    }
                    System.out.println("equation is" + equation);
                    ps.setString(1, equation);

                    ps.executeUpdate();
                }
                if (verb_category.equals("bothdecrement")) {

                    System.out.println("Agent name:" + owner_name);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    //ResultSet rs2 = ps.executeQuery();
                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";
                    } else {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                    }
                    System.out.println("equation is" + equation);
                    ps.setString(1, equation);

                    ps.executeUpdate();

                    if (second_owner != null) {
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (second_owner != null) {
                            if (variable_count == 0) {
                                equation = second_owner + ".variable_count=" + second_owner + ".variable_count-x;";
                            } else {
                                equation = second_owner + ".variable_count=" + second_owner + ".variable_count-" + variable_count + ";";
                            }
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();

                    }
                }
                if (verb_category.equals("postransfer")) {

                    System.out.println("Agent name:" + owner_name);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    //ResultSet rs2 = ps.executeQuery();
                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count+x;";
                    } else {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                    }
                    System.out.println("equation is" + equation);
                    ps.setString(1, equation);

                    ps.executeUpdate();
                    sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                    // System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    if (second_owner != null) {
                        if (variable_count == 0 && owner_name != null) {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count-x;";
                        } else {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count-" + variable_count + ";";
                        }
                    }
                    System.out.println("equation is" + equation);
                    ps.setString(1, equation);

                    ps.executeUpdate();
                }
                if (verb_category.equals("negtranfer")) {

                    // System.out.println("Purchaser name name:" + recipient);
                    sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                    System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    if (variable_count == 0) {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                    } else {
                        equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                    }
                    //System.out.println("quation is" + equation);
                    ps.setString(1, equation);
                    ps.executeUpdate();
                    sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                    // System.out.println(sql);
                    ps = conn.prepareStatement(sql);
                    if (second_owner != null) {
                        if (variable_count == 0) {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count+x;";
                        } else {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count+" + variable_count + ";";
                        }

                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                }

            }
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
    }
    /*
    void generator(int i) throws SQLException, Exception {
        Connection conn = DBconnect.getConnection();
        // System.out.println("connection made ");
        System.out.println("Creating statement for generation of equation table...");
        //pla Statement stmt = conn.createStatement();
        // String sql;
//insert in the table that matches verb_lemma.
        String sql = "select * from verbstable where sent_sl_no=" + i;
        System.out.println(sql);
        PreparedStatement ps = conn.prepareStatement(sql);
        try {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String verb_lemma = rs.getString(3);
                //similerity verbs
                System.out.println("verb lemma" + verb_lemma);
                if (verb_lemma.equals("clean")) {
                    verb_lemma = "go";
                }
                System.out.println("verb lemma" + verb_lemma);
                sql = "select * from " + verb_lemma + " where sent_sl_no=" + i;
                System.out.println(sql);
                ps = conn.prepareStatement(sql);
                ResultSet rs1 = ps.executeQuery();
                while (rs1.next()) {
                    if (verb_lemma.equals("have")) {
                        String owner_name = rs1.getString("owner_name");
                        String second_owner = rs1.getString("second_owner");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (second_owner != null) {
                            if (variable_count == 0) {
                                equation = second_owner + ".variable_count=x;";
                            } else {
                                equation = second_owner + ".variable_count=" + variable_count + ";";
                            }
                            System.out.println("equation is" + equation);
                            ps.setString(1, equation);

                            ps.executeUpdate();
                        }
                    }
                    if (verb_lemma.equals("give")) {
                        String doner = rs1.getString("doner");
                        String recipient = rs1.getString("recipient");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("doner name:" + doner);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = doner + ".variable_count=" + doner + ".variable_count-x;";

                        } else {
                            equation = doner + ".variable_count=" + doner + ".variable_count-" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+x;";
                        } else {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("find")) {
                        String owner_name = rs1.getString("perceiver");
                        // String variable_name = rs1.getString("sought_entity");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("perceiver name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("play")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("sought_entity");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }

                    if (verb_lemma.equals("cut")) {
                        String owner_name = rs1.getString("agent");
                        String source = rs1.getString("source");
                        // String variable_name = rs1.getString("item");
                        int variable_count = rs1.getInt("pieces");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count+x;";
                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && owner_name != null) {
                            equation = source + ".variable_count=" + source + ".variable_count-x;";
                        } else {
                            equation = source + ".variable_count=" + source + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("be")) {
                        String owner_name = rs1.getString("owner_name");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("plant")) {
                        String owner_name = rs1.getString("agent");
                        String location = rs1.getString("location");
                        // String variable_name = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count+x;";
                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = location + ".variable_count=" + location + ".variable_count+x;";
                        } else {
                            equation = location + ".variable_count=" + location + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("serve")) {
                        String server = rs1.getString("server");
                        String recipient = rs1.getString("recipient");
                        // String variable_name = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("server name:" + server);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = server + ".variable_count=" + server + ".variable_count-x;";

                        } else {
                            equation = server + ".variable_count=" + server + ".variable_count-" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        System.out.println("recipient is" + recipient);
                        if (recipient != null) {
                            if (variable_count == 0) {
                                equation = recipient + ".variable_count=" + recipient + ".variable_count+x;";
                            } else {
                                equation = recipient + ".variable_count=" + recipient + ".variable_count+" + variable_count + ";";
                            }

                            System.out.println("equation is" + equation);
                            ps.setString(1, equation);

                            ps.executeUpdate();
                        }
                    }

                    if (verb_lemma.equals("grow")) {
                        String owner_name = rs1.getString("agent");
                        String variable_name = rs1.getString("item");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("pick")) {
                        String cognizer = rs1.getString("cognizer");
                        String second_owner = rs1.getString("second_owner");
                        String variable_name = rs1.getString("item");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("cognizer name:" + cognizer);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = cognizer + ".variable_count=" + cognizer + ".variable_count+x;";

                        } else {
                            equation = cognizer + ".variable_count=" + cognizer + ".variable_count+" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        /*
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && second_owner != null) {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count-x;";
                        } else {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();*/
 /* }
                    if (verb_lemma.equals("place")) {
                        String owner_name = rs1.getString("agent");
                        String second_owner = rs1.getString("second_owner");
                        //String variable_name = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (second_owner != null) {
                            if (variable_count == 0) {
                                equation = second_owner + ".variable_count=x;";
                            } else {
                                equation = equation = second_owner + ".variable_count=" + second_owner + ".variable_count+" + variable_count + ";";
                            }
                            System.out.println("equation is" + equation);
                            ps.setString(1, equation);

                            ps.executeUpdate();
                        }
                    }
                    if (verb_lemma.equals("go") || verb_lemma.equals("clean")) {
                        String owner_name = rs1.getString("agent");
                        String variable_name = rs1.getString("event");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                            //equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }

                    if (verb_lemma.equals("buy")) {
                        String buyer = rs1.getString("buyer");
                        String seller = rs1.getString("seller");
                        String goods = rs1.getString("goods");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("buyer name:" + buyer);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = buyer + ".variable_count=" + buyer + ".variable_count+x;";

                        } else {
                            equation = buyer + ".variable_count=" + buyer + ".variable_count+" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        //second owner to be closed for dataset 1
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && seller != null) {
                            equation = seller + ".variable_count=" + seller + ".variable_count-x;";
                        } else {
                            equation = seller + ".variable_count=" + seller + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("finish")) {
                        String owner_name = rs1.getString("agent");
                        String location = rs1.getString("location");
                        String variable_name = rs1.getString("activity");
                        int variable_count = rs1.getInt("result");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = location + ".variable_count=x;";
                        } else {
                            equation = location + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("receive")) {
                        String recipient = rs1.getString("recipient");
                        String doner = rs1.getString("doner");
                        // String goods = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("buyer name:" + recipient);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+x;";

                        } else {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && doner != null) {
                            equation = doner + ".variable_count=" + doner + ".variable_count-x;";
                        } else {
                            equation = doner + ".variable_count=" + doner + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("spend")) {
                        String owner_name = rs1.getString("agent");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }

                    if (verb_lemma.equals("attend")) {
                        String owner_name = rs1.getString("agent");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("wash")) {
                        String owner_name = rs1.getString("agent");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("stack")) {
                        String owner_name = rs1.getString("agent");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("store")) {
                        String owner_name = rs1.getString("agent");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("lose")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("break")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }

                    if (verb_lemma.equals("borrow")) {
                        String borrower = rs1.getString("borrower");
                        String lender = rs1.getString("lender");
                        // String goods = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("borrower name:" + borrower);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = borrower + ".variable_count=" + borrower + ".variable_count+x;";

                        } else {
                            equation = borrower + ".variable_count=" + borrower + ".variable_count+" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && lender != null) {
                            equation = lender + ".variable_count=" + lender + ".variable_count-x;";
                        } else {
                            equation = lender + ".variable_count=" + lender + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }

                    if (verb_lemma.equals("eat")) {
                        String owner_name = rs1.getString("agent");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Agent name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }

                    if (verb_lemma.equals("make")) {
                        String owner_name = rs1.getString("creator");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("creator name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("take")) {
                        String recipient = rs1.getString("receiver");
                        String doner = rs1.getString("doner");
                        // String goods = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("Taker name name:" + recipient);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+x;";

                        } else {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && doner != null) {
                            equation = doner + ".variable_count=" + doner + ".variable_count-x;";
                        } else {
                            equation = doner + ".variable_count=" + doner + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("decide")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("sell")) {
                        String seller = rs1.getString("seller");
                        String buyer = rs1.getString("buyer");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("seller name:" + seller);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = seller + ".variable_count=" + seller + ".variable_count-x;";

                        } else {
                            equation = seller + ".variable_count=" + seller + ".variable_count-" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = buyer + ".variable_count=" + buyer + ".variable_count+x;";
                        } else {
                            equation = buyer + ".variable_count=" + buyer + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("purchase")) {
                        String recipient = rs1.getString("buyer");
                        String doner = rs1.getString("seller");
                        // String goods = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("Purchaser name name:" + recipient);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+x;";

                        } else {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && doner != null) {
                            equation = doner + ".variable_count=" + doner + ".variable_count-x;";
                        } else {
                            equation = doner + ".variable_count=" + doner + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("get")) {
                        String recipient = rs1.getString("receiver");
                        String doner = rs1.getString("doner");
                        // String goods = rs1.getString("theme");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("Taker name name:" + recipient);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+x;";

                        } else {
                            equation = recipient + ".variable_count=" + recipient + ".variable_count+" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0 && doner != null) {
                            equation = doner + ".variable_count=" + doner + ".variable_count-x;";
                        } else {
                            equation = doner + ".variable_count=" + doner + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("pay")) {
                        String buyer = rs1.getString("buyer");
                        String seller = rs1.getString("seller");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("buyer name:" + buyer);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = buyer + ".variable_count=" + buyer + ".variable_count-x;";

                        } else {
                            equation = buyer + ".variable_count=" + buyer + ".variable_count-" + variable_count + ";";
                        }
                        //System.out.println("quation is" + equation);
                        ps.setString(1, equation);
                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = seller + ".variable_count=" + seller + ".variable_count+x;";
                        } else {
                            equation = seller + ".variable_count=" + seller + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("own")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("gather")) {
                        String owner_name = rs1.getString("person");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=x;";
                        } else {
                            equation = owner_name + ".variable_count=" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("tear")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("miss")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("crack")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("plan")) {
                        String owner_name = rs1.getString("owner");
                        // String variable_name = rs1.getString("resource");
                        int variable_count = rs1.getInt("variable_count");

                        System.out.println("Owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();

                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count+x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count+" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                    if (verb_lemma.equals("cost")) {
                        String owner_name = rs1.getString("owner");
                        String second_owner = rs1.getString("second_owner");
                        // String variable_name = rs1.getString("variable_name");
                        int variable_count = rs1.getInt("variable_count");
                        System.out.println("owner name:" + owner_name);
                        sql = "UPDATE sentence set pipeline_equation1= ? where sent_sl_no=" + i;
                        System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        //ResultSet rs2 = ps.executeQuery();
                        if (variable_count == 0) {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-x;";

                        } else {
                            equation = owner_name + ".variable_count=" + owner_name + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                        sql = "UPDATE sentence set pipeline_equation2= ? where sent_sl_no=" + i;
                        // System.out.println(sql);
                        ps = conn.prepareStatement(sql);
                        if (variable_count == 0) {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count+x;";
                        } else {
                            equation = second_owner + ".variable_count=" + second_owner + ".variable_count-" + variable_count + ";";
                        }
                        System.out.println("equation is" + equation);
                        ps.setString(1, equation);

                        ps.executeUpdate();
                    }
                }

            }
        } catch (SQLException se) {
            System.out.println(se);

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DBconnect.closeConnection(conn);

        }
    }*/
}
