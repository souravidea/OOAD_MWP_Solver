package mwproblem;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.CoreAnnotations.PartOfSpeechAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TokensAnnotation;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;
import static mwproblem.MWP.SENTENCE;

public class ConjunctionResolver {

    static boolean isVBCheck;
    static boolean commaQues;

    public static boolean containsVerb(List<CoreLabel> tokens) {
        int index = 1;
        for (CoreLabel token : tokens) {
            String pos = token.get(PartOfSpeechAnnotation.class);
            //System.out.println(pos+token);
            if (pos.contains("VB") && tokens.indexOf(token) != 0 && !tokens.get(tokens.indexOf(token) - 1).tag().contains("TO") && index < tokens.size() && !containsVerb(tokens.subList(index, tokens.size() - 1))) {
                return true;
            }
            if (pos.contains("VB") && tokens.indexOf(token) == 0) {
                if (tokens.size() > 1 && index < tokens.size() && !containsVerb(tokens.subList(index, tokens.size() - 1))) {
                    return true;
                }
                if (tokens.size() == 1) {
                    return true;
                }
            }
            index++;
        }
        return false;
    }

    public static boolean containsPrep(List<CoreLabel> tokens) {
        //  boolean afterVerb = false;
        // if (!containsVerb(text,pipeline))
        //afterVerb = true;
        // for (CoreMap sentence: sentences) {
        for (CoreLabel token : tokens) {
            String pos = token.get(PartOfSpeechAnnotation.class);
            //	if (pos.contains("VB") && containsVerb(text,pipeline))
            //afterVerb = true;
            if ((pos.contains("IN") || pos.contains("TO"))) {
                return true;
            }
        }
        //}
        return false;
    }

    public static String getVerbPhrase(List<CoreLabel> tokens) {
        String verbPhrase = "";
        int index = 1;
        for (CoreLabel token : tokens) {
            String pos = token.get(PartOfSpeechAnnotation.class);
            if (!verbPhrase.isEmpty() && !verbPhrase.endsWith(" ")) {
                verbPhrase = verbPhrase + " ";
            }
            if (pos.equals("$") || pos.equals(",")) {
                verbPhrase = verbPhrase + token.originalText();
            } else {
                verbPhrase = verbPhrase + token.originalText() + " ";
            }
            //System.out.println("vvvvv"+verbPhrase+pos);
            if ((pos.contains("VB") && !containsVerb(tokens.subList(index, tokens.size() - 1))) || token.originalText().startsWith("ha")) {
                return verbPhrase.replace(" '", "'").replace(" ,", ",").trim();
            }
            if ((pos.contains("VB") && containsPrep(tokens.subList(index, tokens.size() - 1))) || token.originalText().startsWith("ha")) {
                return verbPhrase.replace(" '", "'").replace(" ,", ",").trim();
            }
            index++;
        }
        return verbPhrase.trim();
    }

    public static String getPrepPhrase(String text, List<CoreLabel> tokens) {
        boolean crossPrep = false, crossVerb = false;
        String prepPhrase = "";
        //boolean begin = false;
        for (CoreLabel token : tokens) {
            String pos = token.get(PartOfSpeechAnnotation.class);
            //System.out.println(token.originalText()+pos);
            if (pos.contains("VB")) {
                crossVerb = true;
            }
            if (containsVerb(tokens) && !crossVerb) {
                continue;
            }
            /*if (!prepPhrase.isEmpty() && !prepPhrase.endsWith(" ") && !prepPhrase.endsWith("$"))
	    		prepPhrase = prepPhrase + " ";*/
            if (!crossPrep && pos.contains("IN") && !token.originalText().equals("by") || pos.contains("TO")) {
                crossPrep = true;
                prepPhrase = prepPhrase + token.originalText() + " ";
                continue;
            }
            if (crossPrep && (pos.contains("IN") && !token.originalText().equals("by") || pos.contains("TO"))) {
                prepPhrase = "";
                // System.out.println("\twaka" + prepPhrase);
                prepPhrase = prepPhrase + token.originalText() + " ";
                continue;
            }
            if (crossPrep && !pos.equals("$")) {
                prepPhrase = prepPhrase + token.originalText() + " ";
            } else if (crossPrep) {
                prepPhrase = prepPhrase + token.originalText();
            }

        }
        prepPhrase = prepPhrase.replace(" .", ".");
        prepPhrase = prepPhrase.replace(" ,", ",");

        // System.out.println("prepPhrase:" + prepPhrase);
        return prepPhrase.replace(" '", "'").trim();
    }

    public static String parse(String input, StanfordCoreNLP pipeline) {
        String ans = "";
        input = input.replace(" .", ". ");
        input = input.replace(" ,", ", ");
        input = input.replace("$ ", "$").replace(" '", "'").trim();
        input = input.replaceAll("\\s+", " ").trim();
        input = input.trim();
        // System.out.println(input);
        int countand = 0;
        int countbut = 0;
        int countif = 0;
        int countthen = 0;

        Annotation document = new Annotation(input);
        pipeline.annotate(document);
        List<CoreMap> sentences = document.get(SentencesAnnotation.class);

        for (CoreMap sentence : sentences) {
            boolean condition1 = sentence.toString().contains(" and ");
            boolean condition2 = sentence.toString().contains(" but ");
            boolean condition3 = sentence.toString().contains(" if ");
            boolean condition4 = sentence.toString().contains(" then ");
            String sent = sentence.toString();
            // System.out.println("sentence is :" + sent);
            if (sent.contains("and")) {
                countand = sent.split(" and ").length - 1;
                // System.out.println("count and=>" + countand);

            }
            if (sent.contains("but")) {
                countbut = sent.split(" but ").length - 1;
                // System.out.println("count and=>" + countand);

            }
            if (sent.contains("if")) {
                countif = sent.split(" if ").length - 1;
                // System.out.println("count and=>" + countand);

            }
            if (sent.contains("then")) {
                countthen = sent.split(" then ").length - 1;
                // System.out.println("count and=>" + countand);

            }

            String splitString = "";
            if (condition1) {
                splitString = " and ";
            } else if (condition2) {
                splitString = " but ";
            } else if (condition3) {
                splitString = " if ";
            } else if (condition4) {
                splitString = " then ";

            }

            if (condition1 || condition2 || condition3 || condition4) {
                String firstPart = sentence.toString().split(splitString)[0];
                String secondPart = sentence.toString().split(splitString)[1];

                //   System.out.println("first part=>" + firstPart);
                //   System.out.println("second part=>" + secondPart);
                String VP1 = "", VP2 = "", VP3 = "", PrP1 = "", PrP2 = "", PrP3 = "", L1 = "", L2 = "", L3 = "", P1 = "", P2 = "", P3 = "";
                //  System.out.println(firstPart + "|" + secondPart);
                List<CoreLabel> firstPartTokens = new ArrayList<>();
                List<CoreLabel> secondPartTokens = new ArrayList<>();

                if (countand == 1 || countbut == 1 || countif == 1 || countthen == 1) {
                    boolean endFirst = false;
                    for (CoreLabel token : sentence.get(TokensAnnotation.class)) {
                        if (token.originalText().equals(splitString.trim())) {
                            endFirst = true;
                            continue;
                        }
                        if (endFirst) {
                            secondPartTokens.add(token);
                        } else {
                            firstPartTokens.add(token);
                        }
                    }
                    // System.out.println(firstPart + "|" + secondPart);
                    if (!containsVerb(firstPartTokens)) {
                        ans = ans + sentence.toString() + " ";
                        continue;
                    }
                    VP1 = getVerbPhrase(firstPartTokens);
                    //System.out.println("vp1"+VP1);
                    String[] words = VP1.split(" ");
                    String verb1 = words[words.length - 1], verb2 = "";
                    P1 = VP1.substring(0, VP1.length() - verb1.length()).trim();
                    if (containsVerb(secondPartTokens)) {
                        VP2 = getVerbPhrase(secondPartTokens);
                        words = VP2.split(" ");
                        verb2 = words[words.length - 1];
                        P2 = VP2.substring(0, VP2.length() - verb2.length()).trim();
                    }
                    if (containsPrep(firstPartTokens)) {
                        PrP1 = getPrepPhrase(firstPart, firstPartTokens);
                    }
                    if (containsPrep(secondPartTokens)) {
                        PrP2 = getPrepPhrase(secondPart, secondPartTokens);
                    }

                    if (verb2.isEmpty()) {
                        verb2 = verb1;
                    }
                    if (VP2.isEmpty()) {
                        VP2 = P2 + " " + verb2;
                    }
                    if (P2.trim().isEmpty()) {
                        P2 = P1;
                    }
                    if (PrP1.isEmpty() && !PrP2.startsWith("for")) {
                        PrP1 = PrP2;
                    }
                    //System.out.println(VP1+"|"+VP2);
                    L1 = firstPart.replace(VP1, "");
                    L1 = L1.trim();
                    L1 = L1.replace(PrP1, "");
                    L1 = L1.trim();
                    L2 = secondPart.replace(VP2, "");
                    L2 = L2.trim();
                    L2 = L2.replace(PrP2, "");
                    L2 = L2.trim();

                    if ((L1 + PrP1).trim().endsWith(",") || (L1 + PrP1).endsWith(".")) {
                        ans = ans + (P1 + " " + verb1 + " " + (L1 + " " + PrP1).substring(0, (L1 + " " + PrP1).length())) + "  " + (P2 + " " + verb2 + " " + L2 + " " + PrP2) + " ";
                    } else {
                        ans = ans + (P1 + " " + verb1 + " " + L1 + " " + PrP1) + ". " + (P2 + " " + verb2 + " " + L2 + " " + PrP2) + " ";
                    }
                    if (!(L2 + PrP2).trim().endsWith(",") && !(L2 + PrP2).endsWith(".")) {
                        ans = ans + ". ";
                    }
                }
                if (countand >= 2 || countbut == 2 || countif == 2 || countthen == 2) {
                    String thirdPart = sentence.toString().split(splitString)[2];
                    // System.out.println("third part==>" + thirdPart);
                    List<CoreLabel> thirdPartTokens = new ArrayList<>();
                    boolean endFirst = false;
                    boolean endSecond = false;
                    int count = 0;
                    for (CoreLabel token : sentence.get(TokensAnnotation.class)) {
                        if (token.originalText().equals(splitString.trim())) {
                            count++;
                            if (count == 1) {
                                endFirst = true;
                            }
                            if (count == 2) {
                                endSecond = true;
                            }
                            //  System.out.println("tokens are" + token.originalText());
                            continue;
                        }
                        if (endSecond && count == 2) {
                            thirdPartTokens.add(token);
                        } else if (endFirst && count == 1) {
                            secondPartTokens.add(token);
                            // endFirst=false;

                        } else {
                            firstPartTokens.add(token);
                        }
                    }
                    /*
                    for (int i = 0; i < firstPartTokens.size(); i++) {
                        System.out.println("first part tokens:" + firstPartTokens.get(i));
                    }
                    for (int i = 0; i < secondPartTokens.size(); i++) {
                        System.out.println("second part tokens" + secondPartTokens.get(i));
                    }
                    for (int i = 0; i < thirdPartTokens.size(); i++) {
                        System.out.println("Third part tokens" + thirdPartTokens.get(i));

                    }*/
                    // System.out.println(firstPart + "|" + secondPart);
                    if (!containsVerb(firstPartTokens)) {
                        ans = ans + sentence.toString() + " ";

                        continue;
                    }
                    VP1 = getVerbPhrase(firstPartTokens);
                    // System.out.println("vp1" + VP1);
                    String[] words = VP1.split(" ");
                    String verb1 = words[words.length - 1], verb2 = "", verb3 = "";
                    P1 = VP1.substring(0, VP1.length() - verb1.length()).trim();
                    if (containsVerb(secondPartTokens)) {
                        VP2 = getVerbPhrase(secondPartTokens);
                        // System.out.println("vp2=>" + VP2);
                        words = VP2.split(" ");
                        verb2 = words[words.length - 1];
                        P2 = VP2.substring(0, VP2.length() - verb2.length()).trim();
                    }
                    if (containsVerb(thirdPartTokens)) {
                        VP3 = getVerbPhrase(thirdPartTokens);
                        //  System.out.println("VP3=>" + VP3);
                        words = VP3.split(" ");
                        verb3 = words[words.length - 1];
                        P3 = VP3.substring(0, VP3.length() - verb3.length()).trim();
                    }
                    if (containsPrep(firstPartTokens)) {
                        PrP1 = getPrepPhrase(firstPart, firstPartTokens);
                    }
                    if (containsPrep(secondPartTokens)) {
                        PrP2 = getPrepPhrase(secondPart, secondPartTokens);
                    }
                    if (containsPrep(thirdPartTokens)) {
                        PrP3 = getPrepPhrase(thirdPart, thirdPartTokens);
                    }

                    if (verb2.isEmpty()) {
                        verb2 = verb1;
                    }
                    if (verb3.isEmpty()) {
                        verb3 = verb1;
                    }
                    if (VP2.isEmpty()) {
                        VP2 = P2 + " " + verb2;
                    }
                    if (VP3.isEmpty()) {
                        VP3 = P3 + " " + verb3;
                    }
                    if (P2.trim().isEmpty()) {
                        P2 = P1;
                    }
                    if (P3.trim().isEmpty()) {
                        P3 = P1;
                    }

                    if (PrP1.isEmpty() && PrP2.isEmpty() && !PrP3.startsWith("for")) {
                        PrP1 = PrP2 = PrP3;
                    }
                    if (PrP2.isEmpty() && PrP3.isEmpty() && !PrP1.startsWith("for")) {
                        PrP2 = PrP3 = PrP1;
                    }
                    if (PrP3.isEmpty() && PrP1.isEmpty() && !PrP2.startsWith("for")) {
                        PrP1 = PrP2 = PrP1;
                    }
                    //System.out.println(VP1+"|"+VP2);
                    L1 = firstPart.replace(VP1, "");
                    L1 = L1.trim();
                    L1 = L1.replace(PrP1, "");
                    L1 = L1.trim();
                    // System.out.println("L1=>" + L1);
                    L2 = secondPart.replace(VP2, "");
                    L2 = L2.trim();
                    L2 = L2.replace(PrP2, "");
                    L2 = L2.trim();
                    // System.out.println("L2=>" + L2);
                    L3 = thirdPart.replace(VP3, "");
                    L3 = L3.trim();
                    L3 = L3.replace(PrP3, "");
                    L3 = L3.trim();
                    /*
                    System.out.println("L3=>" + L3);
                    System.out.println("P1=>" + P1);
                    System.out.println("P2=>" + P2);
                    System.out.println("P3=>" + P3);
                    System.out.println("PRP1=>" + PrP1);
                    System.out.println("PRP2=>" + PrP2);*/
                    //System.out.println("PRP3=>" + PrP3);
                    // System.out.println("ans=>" + ans);
                    if ((L1 + PrP1).endsWith(".")) {
                        // System.out.println("i am here 1");
                        ans = ans + (P1 + " " + verb1 + " " + (L1 + " " + PrP1).substring(0, (L1 + " " + PrP1).length())) + " " + (P2 + " " + verb2 + " " + L2 + " " + PrP2) + " " + (P3 + " " + verb3 + " " + L3 + " " + PrP3) + " ";
                    } else {
                        // System.out.println("i am here 2");
                        ans = ans + (P1 + " " + verb1 + " " + L1 + " " + PrP1) + ". " + (P2 + " " + verb2 + " " + L2 + " " + PrP2) + ". " + (P3 + " " + verb3 + " " + L3 + " " + PrP3) + " ";
                    }
                    /* if (!(L2 + PrP2).endsWith(".")) {
                    System.out.println("i am here 3");
                    ans = ans + ". ";
                }
                if (!(L3 + PrP3).endsWith(".")) {
                    System.out.println("i am here 4");
                    ans = ans + ". ";
                }*/
                }
                if (sentence.toString().startsWith("her")) {
                    ans = ans.replace("her", "Her");
                }
            } else if (sentence.toString().startsWith("her")) {
                String s = sentence.toString().replace("her", "Her");
                ans = ans + s + " ";
            } else {
                ans = ans + sentence.toString() + " ";
            }
            //  System.out.println("ans=>" + ans);
        }
        if (ans.contains(". her")) {
            String str = ans.replace(". her", ". Her");
            ans = str;
        }
        return ans;
    }

     public void invoke() throws FileNotFoundException, ClassCastException, ClassNotFoundException, Exception {
  //  public static void main(String[] args) throws FileNotFoundException, ClassCastException, ClassNotFoundException, Exception {

        Properties props = new Properties();
        props.put("annotators", "tokenize, ssplit, pos, lemma, ner,parse,dcoref");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        String entireFileText1 = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        String s2 = entireFileText1.replaceAll(", but", ". But");
        String s1 = null;
        /*
        s1 = s2.replaceAll(", and", ".");*/// for paper 2
        processing_sentence();
        if (isVBCheck == false) {
            s1 = s2.replaceAll(", and", ".");//for paper 1
        } else {
            s1 = s2.replaceAll(", and", "and");
        }
        // System.out.println("s1=>" + s1);
        // s1 = s2;
        String entireFileText = null;
        if (commaQues != true) {
            entireFileText = s1.replaceAll(",", "and");
        } else {
            entireFileText = s1.replaceFirst(",", "and");
        }

        // System.out.println("sentence before process" + entireFileText);

        File file = new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"); //Your file
        FileOutputStream fos = new FileOutputStream(file);
        PrintStream ps = new PrintStream(fos);
        System.setOut(ps);
        // System.out.println("resolving conjunction....");*/
        System.out.println(parse(entireFileText, pipeline));
    }

    public static void processing_sentence() throws FileNotFoundException, IOException, ClassCastException, ClassNotFoundException, Exception {

        int i = 0;
        int no_of_sentences = 0;

        String entireFileText = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt")).useDelimiter("\\A").next();
        System.out.println("full question:" + entireFileText);
        ArrayList<String> sentenceList;
        try (Scanner sentence = new Scanner(new File("/home/sourav/MyResearch/MathWordProbSolver/build/web/ques.txt"))) {
            sentenceList = new ArrayList<>();
            while (sentence.hasNextLine()) {

                sentenceList.add(sentence.nextLine());

            }
        }

        String[] sentenceArray = sentenceList.toArray(new String[0]);

        for (String sentenceArray1 : sentenceArray) {
            if (!entireFileText.contains("$")) {

                SENTENCE = sentenceArray1.split("(?<=[.!?])\\s*"); //split sentences and store in array 
            } else {
                // SENTENCE = sentenceArray1.split("(?<=\\s*[.!?])\\s*");
                SENTENCE = sentenceArray1.split("[\\s . ]\\s");

            }

        }
        no_of_sentences = SENTENCE.length;
        // System.out.println("total no of sentence is:  " + no_of_sentences);
        SentConjunction sentc[] = new SentConjunction[no_of_sentences];

        for (i = 0; i < no_of_sentences; i++) {
            // System.out.println("Sentence " + (i + 1) + ": " + SENTENCE[i]);
            sentc[i] = new SentConjunction();
            if (!SENTENCE[i].endsWith(" ?")) {
                sentc[i].sentenceline = SENTENCE[i];
            } else {
                sentc[i].sentenceline = SENTENCE[i];
            }
            sentc[i].sent_sl_no = i + 1;
            // sentc[i].count_tokens();
        }

        i = 0;
        while (i < no_of_sentences) {

            // System.out.println("sentence " + (i + 1) + " : " + sentc[i].sentenceline);
            if (sentc[i].sentenceline.contains(", and")) {
                isVBCheck = sentc[i].tagging();
              //  System.out.println("VB check=" + isVBCheck);
               // System.out.println("sentence  " + (i + 1) + " :tagged string:" + sentc[i].taggedString);

            }
            if (sentc[i].sentenceline.contains(" ?") && sentc[i].sentenceline.contains(",")) {

                commaQues = true;
               // System.out.println("commaQues"+commaQues);

            }
            i++;
        }

    }

}
