JAVA=/opt/jdk/jdk1.8.0_77/bin/java

# directory to which fndata-1.5 was extracted
FRAMENETDIR=/home/sourav/mateplus-master/scratch/framenet/fndata-1.5

# directory in which glove10a was extracted
# (please also modify processtmp.sh in glove dir accordingly!)
GLOVEDIR=/home/sourav/mateplus-master/scratch/glove

$JAVA -Xmx8g -cp /home/sourav/mateplus-master/lib/*:mateplus.jar se.lth.cs.srl.CompletePipeline eng -lemma /home/sourav/NetBeansProjects/models/CoNLL2009-ST-English-ALL.anna-3.3.lemmatizer.model -parser /home/sourav/NetBeansProjects/test/src/models/CoNLL2009-ST-English-ALL.anna-3.3.parser.model -tagger /home/sourav/NetBeansProjects/test/src/models/CoNLL2009-ST-English-ALL.anna-3.3.postagger.model -srl /home/sourav/NetBeansProjects/test/src/models/srl-TACL15-eng.model -glove $GLOVEDIR -reranker -globalFeats -semafor "127.0.0.1 8043" -mst "127.0.0.1 12345" -framenet $FRAMENETDIR -test $1
